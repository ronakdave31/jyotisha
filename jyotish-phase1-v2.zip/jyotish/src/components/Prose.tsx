export function Prose({ children }: { children: React.ReactNode }) {
  return <div className="container max-w-3xl space-y-4 py-10 text-[17px] leading-relaxed text-ink-soft [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:font-semibold [&_h2]:text-maroon [&_li]:ml-5 [&_li]:list-disc [&_strong]:text-ink">{children}</div>;
}
