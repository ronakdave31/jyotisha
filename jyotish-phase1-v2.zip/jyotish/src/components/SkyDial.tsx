import { NAKSHATRAS, PLANET_ABBR, RASHIS, ZODIAC_GLYPH, type Planet } from "@/lib/astro/constants";

/**
 * The live sky: 27 nakshatras and 12 rashis with the grahas at their computed
 * sidereal longitudes. 0° Mesha sits at the left (the eastern horizon convention),
 * longitudes increase counter-clockwise.
 */
export function SkyDial({ positions, moonNakshatra }: { positions: { planet: Planet; lon: number }[]; moonNakshatra: number }) {
  const R = 200, cx = 210, cy = 210;
  const pt = (lon: number, r: number) => {
    const a = Math.PI - (lon * Math.PI) / 180; // 0° at left, counter-clockwise
    return [cx + r * Math.cos(a), cy - r * Math.sin(a)] as const;
  };
  const arc = (a0: number, a1: number, r0: number, r1: number) => {
    const [x0, y0] = pt(a0, r1), [x1, y1] = pt(a1, r1), [x2, y2] = pt(a1, r0), [x3, y3] = pt(a0, r0);
    return `M${x0} ${y0} A${r1} ${r1} 0 0 0 ${x1} ${y1} L${x2} ${y2} A${r0} ${r0} 0 0 1 ${x3} ${y3}Z`;
  };
  const sun = positions.find((p) => p.planet === "Sun")!;
  const moon = positions.find((p) => p.planet === "Moon")!;
  const others = positions.filter((p) => !["Sun", "Moon"].includes(p.planet));
  return (
    <svg viewBox="0 0 420 420" className="h-auto w-full" role="img"
      aria-label={`Current sky: Sun in ${RASHIS[Math.floor(sun.lon / 30)].en}, Moon in ${RASHIS[Math.floor(moon.lon / 30)].en}, nakshatra ${NAKSHATRAS[moonNakshatra].en}.`}>
      <g>
        {NAKSHATRAS.map((n, i) => {
          const a0 = (i * 360) / 27, a1 = ((i + 1) * 360) / 27;
          const [tx, ty] = pt(a0 + 360 / 54, R - 14);
          return (
            <g key={n.en}>
              <path className="sky-seg" d={arc(a0, a1, R - 28, R)} fill={i === moonNakshatra ? "rgba(224,122,31,.55)" : i % 2 ? "rgba(239,221,176,.06)" : "rgba(239,221,176,.12)"} stroke="rgba(217,180,100,.35)" strokeWidth=".6" />
              <text x={tx} y={ty} fontSize="7.5" fill="rgba(251,246,236,.7)" textAnchor="middle" dominantBaseline="middle">{n.en.replace("Purva ", "P.").replace("Uttara ", "U.").slice(0, 6)}<title>{n.en}</title></text>
            </g>
          );
        })}
      </g>
      {RASHIS.map((r, i) => {
        const [tx, ty] = pt(i * 30 + 15, R - 48);
        const [lx, ly] = pt(i * 30, R - 28), [lx2, ly2] = pt(i * 30, R - 66);
        return (
          <g key={r.en}>
            <line x1={lx} y1={ly} x2={lx2} y2={ly2} stroke="rgba(217,180,100,.4)" strokeWidth=".8" />
            <text x={tx} y={ty} fontSize="15" fill="#D9B464" textAnchor="middle" dominantBaseline="middle">{ZODIAC_GLYPH[i]}<title>{r.en}</title></text>
          </g>
        );
      })}
      <circle cx={cx} cy={cy} r={R - 66} fill="none" stroke="rgba(217,180,100,.3)" />
      <circle cx={cx} cy={cy} r={R - 120} fill="none" stroke="rgba(217,180,100,.15)" strokeDasharray="2 4" />
      {others.map((p, i) => {
        const [x, y] = pt(p.lon, R - 88 - (i % 2) * 18);
        return (
          <g key={p.planet} className="sky-planet">
            <circle cx={x} cy={y} r="9" fill="#1F2A4D" stroke="rgba(217,180,100,.6)" />
            <text x={x} y={y + 0.5} fontSize="7.5" fill="#EFDDB0" textAnchor="middle" dominantBaseline="middle">{PLANET_ABBR[p.planet]}</text>
            <title>{`${p.planet} ${(p.lon % 30).toFixed(1)}° ${RASHIS[Math.floor(p.lon / 30)].en}`}</title>
          </g>
        );
      })}
      {(() => { const [x, y] = pt(sun.lon, R - 88); return <g className="sky-planet"><circle cx={x} cy={y} r="13" fill="#E07A1F" /><circle cx={x} cy={y} r="18" fill="none" stroke="#E07A1F" strokeOpacity=".5" strokeDasharray="4 4" style={{ animation: "sun-sweep 3s linear infinite" }} /><title>{`Sun ${(sun.lon % 30).toFixed(1)}° ${RASHIS[Math.floor(sun.lon / 30)].en}`}</title></g>; })()}
      {(() => { const [x, y] = pt(moon.lon, R - 88); return <g className="sky-planet moon-glow"><circle cx={x} cy={y} r="11" fill="#FBF6EC" /><circle cx={x + 4} cy={y - 2} r="9" fill="#141B33" opacity=".85" /><title>{`Moon ${(moon.lon % 30).toFixed(1)}° ${RASHIS[Math.floor(moon.lon / 30)].en}`}</title></g>; })()}
      <text x={cx} y={cy - 8} textAnchor="middle" fontSize="13" fill="#EFDDB0" fontFamily="Cormorant Garamond, serif">Moon in</text>
      <text x={cx} y={cy + 14} textAnchor="middle" fontSize="21" fill="#FBF6EC" fontFamily="Cormorant Garamond, serif" fontWeight="600">{NAKSHATRAS[moonNakshatra].en}</text>
    </svg>
  );
}
