import Link from "next/link";
import { DISCLAIMER, SITE } from "@/lib/site";
import { CITIES } from "@/lib/cities";

const COLS = [
  { title: "Panchang", links: [["Today's Panchang", "/panchang"], ["Monthly calendar", "/panchang/month"], ["Festival calendar", "/festivals"], ["Choghadiya & Hora", "/panchang#choghadiya"]] },
  { title: "Astrology", links: [["Kundli", "/kundli"], ["Kundli matching", "/matching"], ["Daily horoscope", "/horoscope"], ["Planet transits", "/transits"], ["All tools", "/astrology"]] },
  { title: "Spiritual", links: [["Mantras", "/mantras"], ["Shlokas", "/shlokas"], ["Vedas", "/vedas"], ["Karmakand", "/karmkand"], ["Puja vidhi", "/vidhi"]] },
  { title: "More", links: [["Numerology", "/numerology"], ["Muhurat", "/muhurat"], ["Blog", "/blog"]] },
  { title: "About", links: [["How we calculate", "/methodology"], ["Disclaimer", "/disclaimer"], ["Privacy policy", "/privacy"], ["Terms of use", "/terms"]] },
];

export function Footer() {
  return (
    <footer className="mt-24 bg-midnight text-ivory/80">
      <div className="container grid gap-10 py-14 md:grid-cols-3 lg:grid-cols-[1.3fr_repeat(5,1fr)]">
        <div>
          <p className="font-display text-3xl font-bold text-gold-light">{SITE.name}</p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed">{SITE.tagline}.</p>
          <p className="mt-4 text-sm">Contact: <a className="underline decoration-gold/50" href={`mailto:${SITE.email}`}>{SITE.email}</a></p>
        </div>
        {COLS.map((c) => (
          <div key={c.title}>
            <h2 className="font-display text-lg font-semibold text-ivory">{c.title}</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {c.links.map(([l, h]) => <li key={h + l}><Link className="hover:text-gold-light" href={h}>{l}</Link></li>)}
            </ul>
          </div>
        ))}
      </div>
      <div className="container border-t border-ivory/10 py-6 text-xs">
        <p className="mb-3">Panchang by city: {CITIES.filter((c) => c.featured).map((c, i) => (
          <span key={c.slug}>{i > 0 && ", "}<Link className="hover:text-gold-light" href={`/panchang/${c.slug}`}>{c.name}</Link></span>
        ))}</p>
        <p className="max-w-4xl leading-relaxed text-ivory/60">{DISCLAIMER}</p>
        <p className="mt-3 text-ivory/50">© {new Date().getFullYear()} {SITE.name}. A {SITE.publisher} product.</p>
      </div>
    </footer>
  );
}
