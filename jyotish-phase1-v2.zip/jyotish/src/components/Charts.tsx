import { PLANET_ABBR, RASHIS } from "@/lib/astro/constants";

export interface Placement { label: string; sign: number; title?: string }

const NORTH_CENTERS: [number, number][] = [
  [150, 78], [75, 34], [34, 75], [78, 150], [34, 225], [75, 266], [150, 222], [225, 266], [266, 225], [222, 150], [266, 75], [225, 34],
];
const NORTH_SIGN_POS: [number, number][] = [
  [150, 128], [75, 62], [62, 75], [128, 150], [62, 225], [75, 238], [150, 172], [225, 238], [238, 225], [172, 150], [238, 75], [225, 62],
];

/** North Indian (diamond) chart — houses fixed, signs rotate with the Lagna. */
export function NorthChart({ ascSign, placements, title }: { ascSign: number; placements: Placement[]; title: string }) {
  return (
    <svg viewBox="0 0 300 300" role="img" aria-label={`${title}, North Indian style. Lagna ${RASHIS[ascSign].en}.`} className="h-auto w-full max-w-[360px]">
      <rect x="1" y="1" width="298" height="298" fill="#FFFDF7" stroke="#B8892E" strokeWidth="1.5" />
      <path d="M1 1 299 299M299 1 1 299M150 1 299 150 150 299 1 150Z" fill="none" stroke="#B8892E" strokeWidth="1.2" />
      {NORTH_CENTERS.map(([x, y], h) => {
        const sign = (ascSign + h) % 12;
        const items = placements.filter((p) => p.sign === sign);
        const [sx, sy] = NORTH_SIGN_POS[h];
        return (
          <g key={h}>
            <text x={sx} y={sy} textAnchor="middle" dominantBaseline="middle" fontSize="10" fill="#8A7D72">{sign + 1}</text>
            {items.map((p, i) => (
              <text key={p.label} x={x} y={y + (i - (items.length - 1) / 2) * 13} textAnchor="middle" dominantBaseline="middle"
                fontSize="12" fontWeight={p.label.startsWith("As") ? 700 : 500} fill={p.label.startsWith("As") ? "#B85E0E" : "#6B1E2A"}>
                <title>{p.title ?? p.label}</title>{p.label}
              </text>
            ))}
          </g>
        );
      })}
    </svg>
  );
}

const SOUTH_CELLS: [number, number][] = [[1, 0], [2, 0], [3, 0], [3, 1], [3, 2], [3, 3], [2, 3], [1, 3], [0, 3], [0, 2], [0, 1], [0, 0]];

/** South Indian chart — signs fixed (Pisces top-left), Lagna marked with a diagonal. */
export function SouthChart({ ascSign, placements, title }: { ascSign: number; placements: Placement[]; title: string }) {
  const c = 75;
  return (
    <svg viewBox="0 0 300 300" role="img" aria-label={`${title}, South Indian style. Lagna ${RASHIS[ascSign].en}.`} className="h-auto w-full max-w-[360px]">
      <rect x="1" y="1" width="298" height="298" fill="#FFFDF7" stroke="#B8892E" strokeWidth="1.5" />
      {SOUTH_CELLS.map(([cx, cy], sign) => {
        const items = placements.filter((p) => p.sign === sign && !p.label.startsWith("As"));
        return (
          <g key={sign} transform={`translate(${cx * c} ${cy * c})`}>
            <rect width={c} height={c} fill="none" stroke="#B8892E" strokeWidth="1" />
            {sign === ascSign && <path d={`M0 18 18 0`} stroke="#B85E0E" strokeWidth="2" />}
            <text x={c - 5} y={12} textAnchor="end" fontSize="9" fill="#8A7D72">{RASHIS[sign].en.slice(0, 3)}</text>
            {items.map((p, i) => (
              <text key={p.label} x={8 + (i % 2) * 32} y={30 + Math.floor(i / 2) * 15} fontSize="12" fontWeight={500} fill="#6B1E2A"><title>{p.title ?? p.label}</title>{p.label}</text>
            ))}
          </g>
        );
      })}
      <text x="150" y="146" textAnchor="middle" fontSize="15" fill="#6B1E2A" fontFamily="Cormorant Garamond, serif" fontWeight="600">{title}</text>
      <text x="150" y="164" textAnchor="middle" fontSize="10" fill="#8A7D72">Lagna: {RASHIS[ascSign].en}</text>
    </svg>
  );
}

export function placementsFrom(planets: { planet: string; sign: number; retrograde?: boolean; degree?: number }[], ascSign: number): Placement[] {
  return [
    { label: "Asc", sign: ascSign, title: "Ascendant (Lagna)" },
    ...planets.map((p) => ({
      label: PLANET_ABBR[p.planet as keyof typeof PLANET_ABBR] + (p.retrograde && !["Rahu", "Ketu"].includes(p.planet) ? "ᴿ" : ""),
      sign: p.sign,
      title: `${p.planet}${p.degree !== undefined ? ` ${p.degree.toFixed(1)}°` : ""}${p.retrograde ? " (retrograde)" : ""}`,
    })),
  ];
}
