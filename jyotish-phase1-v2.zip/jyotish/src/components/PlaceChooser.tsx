"use client";
import { useRouter } from "next/navigation";
import { PlaceSearch, saveLocationCookie } from "./LocationPicker";

/** Change the page's location: navigates with the place in the URL and remembers it. */
export function PlaceChooser({ basePath, date }: { basePath: string; date?: string }) {
  const router = useRouter();
  return (
    <PlaceSearch
      placeholder="Change city, or use your location"
      onPick={(l) => {
        saveLocationCookie(l);
        const qs = new URLSearchParams(l.slug ? { city: l.slug } : { lat: String(l.lat), lon: String(l.lon), tz: l.tz, name: l.name });
        if (date) qs.set("date", date);
        router.push(`${basePath}?${qs}`);
      }}
    />
  );
}
