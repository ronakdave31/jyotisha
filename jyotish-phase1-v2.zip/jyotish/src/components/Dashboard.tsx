"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { BirthFields, emptyBirth, type BirthValue } from "./forms/BirthFields";
import { createClient } from "@/lib/supabase/client";

interface Profile { id: string; label: string; relation: string | null; full_name: string; birth_date: string; birth_time: string; place_name: string | null; lat: number; lon: number; tz: string; is_primary: boolean }
interface Saved { id: string; title: string; summary: { lagna: string; rashi: string; nakshatra: string }; created_at: string }

export function Dashboard({ profiles, kundlis, email }: { profiles: Profile[]; kundlis: Saved[]; email: string }) {
  const router = useRouter();
  const [adding, setAdding] = useState(profiles.length === 0);
  const [b, setB] = useState<BirthValue>(emptyBirth);
  const [label, setLabel] = useState("Me");
  const [err, setErr] = useState("");

  const add = async () => {
    setErr("");
    if (!b.place) { setErr("Choose a birthplace."); return; }
    const r = await fetch("/api/profiles", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({
      label, full_name: b.name || label, gender: b.gender || undefined, birth_date: b.date, birth_time: b.time.slice(0, 5),
      place_name: b.place.name, lat: b.place.lat, lon: b.place.lon, tz: b.place.tz, is_primary: profiles.length === 0,
    }) });
    const j = await r.json();
    if (!r.ok) { setErr(j.error); return; }
    setAdding(false); setB(emptyBirth); router.refresh();
  };
  const del = async (path: string) => { if (confirm("Delete permanently?")) { await fetch(path, { method: "DELETE" }); router.refresh(); } };
  const kundliLink = (p: Profile) => `/kundli?${new URLSearchParams({ name: p.full_name, date: p.birth_date, time: p.birth_time.slice(0, 5), lat: String(p.lat), lon: String(p.lon), tz: p.tz, place: p.place_name ?? "", go: "1" })}`;

  return (
    <div className="container grid gap-8 py-10 lg:grid-cols-[1.3fr_1fr]">
      <section>
        <div className="flex items-end justify-between"><h2 className="section-title">Birth profiles</h2><button className="btn-ghost !py-1.5 text-sm" onClick={() => setAdding((a) => !a)}>{adding ? "Cancel" : "Add a family member"}</button></div>
        {adding && (
          <form className="leaf mt-4 space-y-3 p-5" onSubmit={(e) => { e.preventDefault(); add(); }}>
            <div><label className="label" htmlFor="pl">Label</label><input id="pl" className="input" value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Me, Mother, Son…" required /></div>
            <BirthFields idPrefix="p" value={b} onChange={setB} />
            <button className="btn-primary">Save profile</button>{err && <p role="alert" className="text-sm text-maroon">{err}</p>}
          </form>
        )}
        <ul className="mt-4 space-y-3">
          {profiles.map((p) => (
            <li key={p.id} className="leaf flex flex-wrap items-center justify-between gap-3 p-4">
              <div><p className="font-medium">{p.label}{p.is_primary && <span className="ml-2 rounded bg-saffron/15 px-1.5 text-xs text-saffron-dark">primary</span>}</p><p className="text-sm text-ink-faint">{p.full_name} · {p.birth_date} {p.birth_time.slice(0, 5)} · {p.place_name}</p></div>
              <div className="flex gap-2"><Link className="btn-primary !py-1.5 text-sm" href={kundliLink(p)}>Kundli</Link><button className="btn-ghost !py-1.5 text-sm" onClick={() => del(`/api/profiles/${p.id}`)}>Delete</button></div>
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h2 className="section-title">Saved Kundlis</h2>
        {kundlis.length === 0 ? <p className="mt-4 text-ink-soft">Charts you save from the Kundli page appear here. <Link href="/kundli" className="text-maroon underline">Generate one</Link>.</p> : (
          <ul className="mt-4 space-y-3">{kundlis.map((k) => (
            <li key={k.id} className="leaf flex items-center justify-between gap-3 p-4">
              <div><p className="font-medium">{k.title}</p><p className="text-sm text-ink-faint">{k.summary.lagna} Lagna · {k.summary.rashi} Rashi · {k.summary.nakshatra}</p></div>
              <button className="text-sm text-maroon underline" onClick={() => del(`/api/kundlis/${k.id}`)}>Delete</button>
            </li>
          ))}</ul>
        )}
        <div className="mt-8 rounded-2xl bg-midnight p-5 text-sm text-ivory/80">
          Signed in as {email}.{" "}
          <button className="text-gold-light underline" onClick={async () => { await createClient()?.auth.signOut(); router.push("/"); router.refresh(); }}>Sign out</button>
        </div>
      </section>
    </div>
  );
}
