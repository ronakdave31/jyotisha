"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export function LoginForm({ next }: { next: string }) {
  const sb = createClient();
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  if (!sb) return <p className="text-ink-soft">Accounts are not configured on this deployment yet. All calculators work without signing in.</p>;
  const redirectTo = `${location.origin}/auth/callback?next=${encodeURIComponent(next)}`;
  return (
    <div className="space-y-5">
      <button className="btn-ghost w-full" onClick={() => sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo } })}>Continue with Google</button>
      <div className="flex items-center gap-3 text-sm text-ink-faint"><span className="rule-gold flex-1" />or<span className="rule-gold flex-1" /></div>
      <form className="space-y-3" onSubmit={async (e) => {
        e.preventDefault(); setBusy(true); setMsg("");
        const { error } = await sb.auth.signInWithOtp({ email, options: { emailRedirectTo: redirectTo } });
        setBusy(false);
        setMsg(error ? error.message : `We sent a sign-in link to ${email}. Open it on this device.`);
      }}>
        <label className="label" htmlFor="email">Email</label>
        <input id="email" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Sending…" : "Email me a sign-in link"}</button>
      </form>
      {msg && <p role="status" className="text-sm text-ink-soft">{msg}</p>}
    </div>
  );
}
