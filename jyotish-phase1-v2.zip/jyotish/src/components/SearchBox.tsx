"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { CITIES } from "@/lib/cities";
import { RASHIS } from "@/lib/astro/constants";
import { MANTRAS } from "@/content/mantras";
import { VIDHIS } from "@/content/karmkand";

const PAGES = [
  { label: "Today's Panchang", href: "/panchang", k: "panchang tithi nakshatra rahu kaal choghadiya hora sunrise" },
  { label: "Monthly Panchang calendar", href: "/panchang/month", k: "calendar month tithi" },
  { label: "Generate Kundli (birth chart)", href: "/kundli", k: "kundli janam kundali birth chart lagna dasha navamsa" },
  { label: "Manglik Dosha check", href: "/kundli", k: "manglik mangal dosha" },
  { label: "Sade Sati & Kaal Sarp check", href: "/kundli", k: "sade sati shani kaal sarp" },
  { label: "Kundli matching (Gun Milan)", href: "/matching", k: "matching gun milan marriage compatibility ashtakoota" },
  { label: "Numerology calculator", href: "/numerology", k: "numerology life path name number chaldean" },
  { label: "Festival & vrat calendar", href: "/festivals", k: "festival diwali holi ekadashi pradosh purnima amavasya" },
  { label: "Daily horoscope", href: "/horoscope", k: "rashifal horoscope daily" },
  { label: "Planetary transits (Gochar)", href: "/transits", k: "transit gochar planets" },
  { label: "Shlokas with meaning", href: "/shlokas", k: "shloka sloka gita bhagavad upanishad verse" },
  { label: "The four Vedas", href: "/vedas", k: "veda vedas rigveda samaveda yajurveda atharvaveda upanishad vedanga" },
  { label: "Karmakand and 16 samskaras", href: "/karmkand", k: "karmkand karmakand karma kand samskar sanskar upanayana mundan namkaran vivah" },
  ...MANTRAS.map((m) => ({ label: `${m.title} mantra`, href: `/mantras/${m.slug}`, k: `${m.category} ${m.deity} mantra` })),
  ...VIDHIS.map((v) => ({ label: `${v.title} vidhi`, href: `/vidhi/${v.slug}`, k: `puja vidhi ${v.deity} ${v.occasion}` })),
];

export function SearchBox() {
  const [q, setQ] = useState("");
  const router = useRouter();
  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (s.length < 2) return [];
    const pages = PAGES.filter((p) => (p.label + " " + p.k).toLowerCase().includes(s));
    const cities = CITIES.filter((c) => c.name.toLowerCase().includes(s)).slice(0, 4).map((c) => ({ label: `Panchang for ${c.name}`, href: `/panchang/${c.slug}` }));
    const signs = RASHIS.map((r, i) => ({ r, i })).filter(({ r }) => r.en.toLowerCase().includes(s) || r.western.toLowerCase().includes(s))
      .map(({ r, i }) => ({ label: `${r.en} (${r.western}) horoscope`, href: `/horoscope/${i}` }));
    return [...pages, ...signs, ...cities].slice(0, 8);
  }, [q]);

  return (
    <form role="search" className="relative w-full max-w-xs" onSubmit={(e) => { e.preventDefault(); if (results[0]) { router.push(results[0].href); setQ(""); } }}>
      <label className="sr-only" htmlFor="site-search">Search</label>
      <input id="site-search" className="input !rounded-full !py-1.5 pl-9 text-[15px]" placeholder="Search tools, cities, rashis" value={q} onChange={(e) => setQ(e.target.value)} />
      <svg className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-faint" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
      {results.length > 0 && (
        <ul className="absolute z-50 mt-1 w-full rounded-lg border border-ink/10 bg-white py-1 shadow-card">
          {results.map((r) => (
            <li key={r.href + r.label}><button type="button" className="block w-full px-3 py-2 text-left text-sm hover:bg-ivory-deep" onClick={() => { router.push(r.href); setQ(""); }}>{r.label}</button></li>
          ))}
        </ul>
      )}
    </form>
  );
}
