import Link from "next/link";
import { PageHeader } from "./ui";

/** Honest holding page for sections scheduled in the next build phase. */
export function Upcoming({ title, href, intro, planned, meanwhile }: { title: string; href: string; intro: string; planned: string[]; meanwhile: { label: string; href: string }[] }) {
  return (
    <>
      <PageHeader title={title} intro={intro} crumbs={[{ name: title, href }]} />
      <div className="container grid gap-8 py-10 md:grid-cols-[1.4fr_1fr]">
        <section className="leaf p-6">
          <h2 className="font-display text-2xl font-semibold text-maroon">Being prepared</h2>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-ink-soft">{planned.map((p) => <li key={p}>{p}</li>)}</ul>
        </section>
        <aside className="rounded-2xl bg-midnight p-6 text-ivory">
          <h2 className="font-display text-xl font-semibold text-gold-pale">Available now</h2>
          <ul className="mt-3 space-y-2">{meanwhile.map((m) => <li key={m.href}><Link className="text-gold-light underline" href={m.href}>{m.label}</Link></li>)}</ul>
        </aside>
      </div>
    </>
  );
}
