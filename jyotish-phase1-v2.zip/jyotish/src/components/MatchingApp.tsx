"use client";
import { useState } from "react";
import type { matchProfiles } from "@/lib/astro/matching";
import { BirthFields, emptyBirth, toBirthPayload, type BirthValue } from "./forms/BirthFields";

type Result = ReturnType<typeof matchProfiles>;

export function MatchingApp() {
  const [boy, setBoy] = useState<BirthValue>(emptyBirth);
  const [girl, setGirl] = useState<BirthValue>(emptyBirth);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [r, setR] = useState<Result | null>(null);

  const submit = async () => {
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/matching", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ boy: toBirthPayload(boy), girl: toBirthPayload(girl) }) });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error);
      setR(j);
      requestAnimationFrame(() => document.getElementById("match-result")?.scrollIntoView({ behavior: "smooth" }));
    } catch (e) { setError((e as Error).message || "Matching failed"); } finally { setBusy(false); }
  };

  const pct = r ? (r.total / 36) * 100 : 0;
  return (
    <div className="container py-10">
      <form className="no-print" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="leaf p-5"><BirthFields idPrefix="boy" legend="Boy's details" value={boy} onChange={setBoy} showGender={false} /></div>
          <div className="leaf p-5"><BirthFields idPrefix="girl" legend="Girl's details" value={girl} onChange={setGirl} showGender={false} /></div>
        </div>
        <div className="mt-5 flex items-center gap-4">
          <button className="btn-primary" disabled={busy}>{busy ? "Matching…" : "Match Kundlis"}</button>
          {error && <p role="alert" className="text-sm text-maroon">{error}</p>}
        </div>
      </form>

      {r && (
        <section id="match-result" className="mt-10 scroll-mt-28" aria-live="polite">
          <div className="grid items-center gap-8 rounded-2xl bg-midnight p-6 text-ivory md:grid-cols-[auto_1fr]">
            <div className="relative mx-auto h-40 w-40">
              <svg viewBox="0 0 100 100" className="h-full w-full" aria-hidden>
                <circle cx="50" cy="50" r="44" fill="none" stroke="rgba(239,221,176,.2)" strokeWidth="7" />
                <circle cx="50" cy="50" r="44" fill="none" stroke={r.total >= 18 ? "#D9B464" : "#E07A1F"} strokeWidth="7" strokeLinecap="round" strokeDasharray={`${pct * 2.765} 276.5`} transform="rotate(-90 50 50)" />
              </svg>
              <div className="absolute inset-0 grid place-items-center text-center"><div><p className="font-display text-5xl font-bold text-gold-pale">{r.total}</p><p className="text-sm text-ivory/70">of 36 gunas</p></div></div>
            </div>
            <div>
              <h2 className="font-display text-3xl font-bold">{r.verdict}</h2>
              <p className="mt-2 text-ivory/80">{r.charts.boy.name || "Boy"}: {r.boy.rashi} Rashi, {r.boy.nakshatra}. {r.charts.girl.name || "Girl"}: {r.girl.rashi} Rashi, {r.girl.nakshatra}.</p>
              <p className="mt-2 text-sm text-ivory/70">{r.manglik.note}</p>
              <button className="no-print btn mt-4 border border-gold/40 text-gold-pale" onClick={() => window.print()}>Download report (PDF)</button>
            </div>
          </div>

          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[640px] text-[15px]">
              <caption className="mb-2 text-left font-display text-2xl font-semibold text-maroon">Ashta Koota</caption>
              <thead><tr className="border-b border-gold/30 text-left text-ink-faint">{["Koota", "Boy", "Girl", "Score", "What it reflects"].map((h) => <th key={h} className="py-2 font-normal">{h}</th>)}</tr></thead>
              <tbody>{r.kootas.map((k) => (
                <tr key={k.koota} className="border-b border-gold/10">
                  <td className="py-2 font-medium">{k.koota}</td><td>{k.boy}</td><td>{k.girl}</td>
                  <td className="tabular-nums"><span className={k.score === 0 ? "text-maroon" : k.score === k.max ? "text-emerald-800" : ""}>{k.score}</span> / {k.max}</td>
                  <td className="text-ink-soft">{k.meaning}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>

          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {[
              { t: "Nadi Dosha", d: r.nadiDosha, ok: "Different Nadis — no dosha." },
              { t: "Bhakoot Dosha", d: r.bhakootDosha, ok: "Moon signs are not in a 2/12, 5/9 or 6/8 relation." },
            ].map(({ t, d, ok }) => (
              <div key={t} className="leaf p-5">
                <h3 className="font-display text-xl font-semibold text-maroon">{t}</h3>
                <p className={`mt-1 font-semibold ${d.present ? "text-maroon" : "text-emerald-800"}`}>{d.present ? "Present" : "Not present"}</p>
                <p className="mt-1 text-sm text-ink-soft">{d.present ? (d.cancellations.length ? `Traditional cancellation: ${d.cancellations.join("; ")}.` : "No standard cancellation applies.") : ok}</p>
              </div>
            ))}
            <div className="leaf p-5">
              <h3 className="font-display text-xl font-semibold text-maroon">Manglik</h3>
              <p className="mt-1 text-[15px]">Boy: {r.manglik.boy ? "Manglik" : "Not Manglik"} · Girl: {r.manglik.girl ? "Manglik" : "Not Manglik"}</p>
              <p className={`mt-1 text-sm ${r.manglik.compatible ? "text-emerald-800" : "text-maroon"}`}>{r.manglik.compatible ? "Compatible by tradition" : "Review advised"}</p>
            </div>
          </div>
          <p className="mt-6 text-sm text-ink-faint">Scored with the {r.rulesetVersion} ruleset. Gun Milan is a traditional guide; tradition itself treats it as one input among many, and it does not determine the outcome of a relationship.</p>
        </section>
      )}
    </div>
  );
}
