import Link from "next/link";
import { DISCLAIMER, SITE } from "@/lib/site";
import { Mandala } from "./fx/Mandala";

export function JsonLd({ data }: { data: object }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }} />;
}

export function Breadcrumbs({ items }: { items: { name: string; href: string }[] }) {
  const all = [{ name: "Home", href: "/" }, ...items];
  return (
    <>
      <nav aria-label="Breadcrumb" className="text-sm text-ink-faint">
        <ol className="flex flex-wrap gap-1.5">
          {all.map((b, i) => (
            <li key={b.href} className="flex gap-1.5">
              {i > 0 && <span aria-hidden>/</span>}
              {i === all.length - 1 ? <span aria-current="page" className="text-ink-soft">{b.name}</span> : <Link className="hover:text-maroon" href={b.href}>{b.name}</Link>}
            </li>
          ))}
        </ol>
      </nav>
      <JsonLd data={{
        "@context": "https://schema.org", "@type": "BreadcrumbList",
        itemListElement: all.map((b, i) => ({ "@type": "ListItem", position: i + 1, name: b.name, item: SITE.url + b.href })),
      }} />
    </>
  );
}

export function PageHeader({ title, intro, crumbs, children }: { title: string; intro?: string; crumbs: { name: string; href: string }[]; children?: React.ReactNode }) {
  return (
    <div className="relative overflow-hidden border-b border-gold/20 bg-ivory-deep/60 lotus-bg">
      <Mandala size={460} className="pointer-events-none absolute -right-28 -top-24 text-gold/25 max-md:hidden" />
      <div className="container relative py-10 md:py-14 stagger">
        <Breadcrumbs items={crumbs} />
        <h1 className="mt-3 font-display text-4xl font-bold leading-tight text-maroon md:text-5xl">{title}</h1>
        {intro && <p className="mt-3 max-w-2xl text-lg text-ink-soft">{intro}</p>}
        {children}
      </div>
    </div>
  );
}

export function Disclaimer({ extra }: { extra?: string }) {
  return (
    <p className="mt-8 rounded-lg border-l-2 border-gold bg-gold-pale/30 px-4 py-3 text-sm text-ink-soft">
      {extra ? `${extra} ` : ""}{DISCLAIMER}
    </p>
  );
}

export function Faq({ items }: { items: { q: string; a: string }[] }) {
  return (
    <>
      <div className="divide-y divide-gold/25 rounded-2xl border border-gold/30 bg-white/60">
        {items.map((f) => (
          <details key={f.q} className="group px-5 py-4">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-ink">
              {f.q}
              <span className="text-gold transition-transform group-open:rotate-45" aria-hidden>+</span>
            </summary>
            <p className="mt-2 text-ink-soft">{f.a}</p>
          </details>
        ))}
      </div>
      <JsonLd data={{
        "@context": "https://schema.org", "@type": "FAQPage",
        mainEntity: items.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
      }} />
    </>
  );
}

export function Stat({ label, value, sub }: { label: string; value: React.ReactNode; sub?: React.ReactNode }) {
  return (
    <div>
      <dt className="text-sm text-ink-faint">{label}</dt>
      <dd className="font-display text-xl font-semibold text-ink">{value}</dd>
      {sub && <dd className="text-xs text-ink-faint">{sub}</dd>}
    </div>
  );
}
