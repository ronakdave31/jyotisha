import Link from "next/link";
import { addDays } from "@/lib/astro/time";

/** Prev/next day links plus a native date picker (works without JavaScript). */
export function DateNav({ date, basePath, extra = {} }: { date: string; basePath: string; extra?: Record<string, string> }) {
  const qs = (d: string) => "?" + new URLSearchParams({ ...extra, date: d }).toString();
  return (
    <div className="mt-6 flex flex-wrap items-center gap-2">
      <Link className="btn-ghost !py-2" href={basePath + qs(addDays(date, -1))} aria-label="Previous day">‹ Previous day</Link>
      <form action={basePath} className="flex items-center gap-2">
        {Object.entries(extra).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />)}
        <label htmlFor="date" className="sr-only">Choose a date</label>
        <input id="date" type="date" name="date" defaultValue={date} min="1800-01-01" max="2200-12-31" className="input !w-auto !py-2" />
        <button className="btn-primary !py-2" type="submit">Show</button>
      </form>
      <Link className="btn-ghost !py-2" href={basePath + qs(addDays(date, 1))} aria-label="Next day">Next day ›</Link>
    </div>
  );
}
