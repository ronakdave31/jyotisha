"use client";
import { useEffect, useRef } from "react";

/** Twinkling stars with the occasional shooting star. Purely decorative; static when motion is reduced. */
export function StarField({ density = 0.00018 }: { density?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!;
    const g = c.getContext("2d");
    if (!g) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let w = 0, h = 0, raf = 0;
    let stars: { x: number; y: number; r: number; p: number; s: number }[] = [];
    let meteor: { x: number; y: number; vx: number; vy: number; life: number } | null = null;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = c.clientWidth; h = c.clientHeight;
      c.width = w * dpr; c.height = h * dpr;
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      stars = Array.from({ length: Math.round(w * h * density) }, () => ({
        x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.3 + 0.3, p: Math.random() * Math.PI * 2, s: 0.5 + Math.random() * 1.5,
      }));
    };
    const draw = (t: number) => {
      g.clearRect(0, 0, w, h);
      for (const s of stars) {
        const a = reduce ? 0.7 : 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t / 1000 * s.s + s.p));
        g.fillStyle = `rgba(251,246,236,${a})`;
        g.beginPath(); g.arc(s.x, s.y, s.r, 0, Math.PI * 2); g.fill();
      }
      if (!reduce) {
        if (!meteor && Math.random() < 0.004) meteor = { x: Math.random() * w * 0.7, y: Math.random() * h * 0.3, vx: 7, vy: 3, life: 1 };
        if (meteor) {
          const grad = g.createLinearGradient(meteor.x, meteor.y, meteor.x - meteor.vx * 14, meteor.y - meteor.vy * 14);
          grad.addColorStop(0, `rgba(239,221,176,${meteor.life})`); grad.addColorStop(1, "rgba(239,221,176,0)");
          g.strokeStyle = grad; g.lineWidth = 1.6;
          g.beginPath(); g.moveTo(meteor.x, meteor.y); g.lineTo(meteor.x - meteor.vx * 14, meteor.y - meteor.vy * 14); g.stroke();
          meteor.x += meteor.vx; meteor.y += meteor.vy; meteor.life -= 0.015;
          if (meteor.life <= 0 || meteor.x > w) meteor = null;
        }
        raf = requestAnimationFrame(draw);
      }
    };
    resize();
    draw(0);
    window.addEventListener("resize", resize);
    const vis = () => { cancelAnimationFrame(raf); if (!document.hidden && !reduce) raf = requestAnimationFrame(draw); };
    document.addEventListener("visibilitychange", vis);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); document.removeEventListener("visibilitychange", vis); };
  }, [density]);
  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />;
}
