/** Scrolling band of today's key facts. Pauses on hover; static under reduced motion. */
export function Ticker({ items }: { items: { label: string; value: string }[] }) {
  const row = (aria: boolean) => (
    <ul className="flex shrink-0 items-center" aria-hidden={aria || undefined}>
      {items.map((it, i) => (
        <li key={i} className="flex items-center gap-2 whitespace-nowrap px-6 text-sm">
          <span className="text-gold-pale/70">{it.label}</span><span className="font-medium text-ivory">{it.value}</span>
          <span className="ml-6 text-saffron-light" aria-hidden>✦</span>
        </li>
      ))}
    </ul>
  );
  return (
    <div className="marquee relative overflow-hidden border-y border-gold/30 bg-maroon-dark py-2.5" role="region" aria-label="Today at a glance">
      <div className="marquee-track">{row(false)}{row(true)}</div>
    </div>
  );
}
