"use client";
import { useState } from "react";
import type { Shloka } from "@/content/shlokas";

/** Flip to reveal the meaning; draw another shloka at random. */
export function ShlokaDeck({ shlokas, startIndex = 0 }: { shlokas: Shloka[]; startIndex?: number }) {
  const [i, setI] = useState(startIndex);
  const [flipped, setFlipped] = useState(false);
  const [lang, setLang] = useState<"en" | "hi">("en");
  const s = shlokas[i];
  const next = () => {
    setFlipped(false);
    setTimeout(() => setI((x) => { let n = x; while (n === x && shlokas.length > 1) n = Math.floor(Math.random() * shlokas.length); return n; }), flipped ? 350 : 0);
  };
  return (
    <div>
      <div className={`flip ${flipped ? "is-flipped" : ""}`}>
        <div className="flip-inner min-h-[16rem]">
          <button className="flip-face leaf flex min-h-[16rem] w-full flex-col justify-center p-6 text-left" onClick={() => setFlipped(true)} aria-label={`${s.ref}. Show meaning`}>
            <span className="text-sm text-ink-faint">{s.ref} · {s.theme}</span>
            <span className="mt-3 block font-deva text-2xl leading-relaxed text-maroon">{s.lines.map((l) => <span key={l} className="block">{l}</span>)}</span>
            <span className="mt-3 block text-sm italic text-ink-soft">{s.iast.join(" ")}</span>
            <span className="mt-4 text-sm font-medium text-saffron-dark">Tap to reveal the meaning</span>
          </button>
          <div className="flip-face flip-back flex flex-col justify-center rounded-2xl bg-midnight p-6 text-ivory" aria-hidden={!flipped}>
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm text-gold-pale">{s.ref}</span>
              <span className="flex rounded-full border border-gold/40 p-0.5 text-xs">
                {(["en", "hi"] as const).map((l) => <button key={l} tabIndex={flipped ? 0 : -1} onClick={() => setLang(l)} className={`rounded-full px-2 py-0.5 ${lang === l ? "bg-gold text-midnight" : ""}`}>{l === "en" ? "English" : "हिन्दी"}</button>)}
              </span>
            </div>
            <p className={`mt-3 text-lg leading-relaxed ${lang === "hi" ? "font-deva" : ""}`}>{lang === "hi" ? s.meaningHi : s.meaningEn}</p>
            <p className="mt-3 text-sm text-gold-light">{s.reflection}</p>
            <button tabIndex={flipped ? 0 : -1} className="mt-4 self-start text-sm text-ivory/70 underline" onClick={() => setFlipped(false)}>Show the Sanskrit</button>
          </div>
        </div>
      </div>
      <button className="btn-ghost mt-4" onClick={next}>Another shloka</button>
    </div>
  );
}
