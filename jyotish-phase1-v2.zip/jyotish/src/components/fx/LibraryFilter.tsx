"use client";
import Link from "next/link";
import { useMemo, useState } from "react";

export interface LibItem { href: string; title: string; titleHi?: string; category: string; preview: string; sub?: string }

/** Chips + search over a library list; cards animate in as the filter changes. */
export function LibraryFilter({ items, categories, placeholder }: { items: LibItem[]; categories: string[]; placeholder: string }) {
  const [cat, setCat] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    return items.filter((m) => (!cat || m.category === cat) && (!s || (m.title + " " + (m.titleHi ?? "") + " " + m.category + " " + m.preview + " " + (m.sub ?? "")).toLowerCase().includes(s)));
  }, [items, cat, q]);
  return (
    <div>
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          <button onClick={() => setCat(null)} aria-pressed={!cat} className={`btn !py-1.5 text-sm ${!cat ? "bg-maroon text-ivory" : "border border-maroon/25 text-maroon"}`}>All</button>
          {categories.map((c) => (
            <button key={c} onClick={() => setCat(c === cat ? null : c)} aria-pressed={c === cat} className={`btn !py-1.5 text-sm ${c === cat ? "bg-maroon text-ivory" : "border border-maroon/25 text-maroon"}`}>{c}</button>
          ))}
        </div>
        <label className="relative md:w-72"><span className="sr-only">Search</span>
          <input className="input !rounded-full !py-2 pl-4" placeholder={placeholder} value={q} onChange={(e) => setQ(e.target.value)} />
        </label>
      </div>
      <p className="mt-3 text-sm text-ink-faint" aria-live="polite">{shown.length} {shown.length === 1 ? "result" : "results"}</p>
      <ul key={`${cat}-${q}`} className="stagger mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((m) => (
          <li key={m.href}>
            <Link href={m.href} className="lift leaf flex h-full flex-col p-5">
              <span className="text-xs text-saffron-dark">{m.category}</span>
              <span className="mt-1 font-display text-2xl font-semibold text-maroon">{m.title}</span>
              {m.titleHi && <span className="font-deva text-ink-faint">{m.titleHi}</span>}
              <span className="mt-3 line-clamp-2 font-deva text-lg text-ink">{m.preview}</span>
              {m.sub && <span className="mt-auto pt-3 text-xs text-ink-faint">{m.sub}</span>}
            </Link>
          </li>
        ))}
      </ul>
      {shown.length === 0 && <p className="mt-6 text-ink-soft">Nothing matches. Try another word or clear the category.</p>}
    </div>
  );
}
