/** An earthen lamp with a flickering flame (CSS only). */
export function Diya({ size = 64, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} aria-hidden>
      <defs>
        <radialGradient id="diya-glow" cx="50%" cy="40%" r="50%"><stop offset="0" stopColor="#F4A35A" stopOpacity=".55" /><stop offset="1" stopColor="#F4A35A" stopOpacity="0" /></radialGradient>
        <linearGradient id="diya-flame" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stopColor="#E07A1F" /><stop offset=".6" stopColor="#F4A35A" /><stop offset="1" stopColor="#FFF3C4" /></linearGradient>
      </defs>
      <circle cx="32" cy="24" r="20" fill="url(#diya-glow)" className="twinkle" />
      <g className="diya-flame"><path d="M32 8c5 8 6 13 0 20-6-7-5-12 0-20z" fill="url(#diya-flame)" /><path d="M32 17c2 4 2 7 0 10-2-3-2-6 0-10z" fill="#FFF8E1" /></g>
      <path d="M8 36c4 14 44 14 48 0-6 3-14 4-24 4S14 39 8 36z" fill="#B85E0E" />
      <path d="M8 36c6 3 14 4 24 4s18-1 24-4" stroke="#6B1E2A" strokeWidth="1.5" fill="none" />
      <path d="M14 44c5 5 31 5 36 0" stroke="#D9B464" strokeWidth="1.2" fill="none" strokeDasharray="2 3" />
    </svg>
  );
}
