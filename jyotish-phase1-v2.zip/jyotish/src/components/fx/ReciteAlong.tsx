"use client";
import { useEffect, useRef, useState } from "react";
import { ringBell } from "@/lib/client/sound";

/** Highlights each line in turn at a chosen pace, so the reader can chant along. */
export function ReciteAlong({ padas, iast, size = "lg" }: { padas: string[]; iast: string[]; size?: "lg" | "md" }) {
  const [active, setActive] = useState(-1);
  const [playing, setPlaying] = useState(false);
  const [pace, setPace] = useState(4);
  const [repeat, setRepeat] = useState(false);
  const [showIast, setShowIast] = useState(true);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    if (!playing) return;
    const words = padas[Math.max(active, 0)]?.split(/\s+/).length ?? 3;
    timer.current = setTimeout(() => {
      setActive((a) => {
        if (a + 1 < padas.length) return a + 1;
        ringBell(0.22);
        if (repeat) return 0;
        setPlaying(false);
        return padas.length;
      });
    }, active < 0 ? 300 : Math.max(1200, (words * 1000 * 4) / pace));
    return () => clearTimeout(timer.current);
  }, [playing, active, pace, repeat, padas]);

  const start = () => { setActive(-1); setPlaying(true); };

  return (
    <div>
      <div className={`space-y-2 font-deva leading-relaxed text-maroon ${size === "lg" ? "text-2xl md:text-3xl" : "text-xl"}`}>
        {padas.map((p, i) => (
          <div key={i} className={`pada px-2 py-1 ${i === active ? "is-active" : active > i ? "is-done" : ""}`}>
            <p>{p}</p>
            {showIast && <p className="font-sans text-base italic text-ink-soft">{iast[i]}</p>}
          </div>
        ))}
      </div>
      <div className="no-print mt-4 flex flex-wrap items-center gap-3 text-sm">
        {playing
          ? <button className="btn-ghost !py-2" onClick={() => setPlaying(false)}>Pause</button>
          : <button className="btn-primary !py-2" onClick={active >= 0 && active < padas.length ? () => setPlaying(true) : start}>{active >= 0 && active < padas.length ? "Resume" : "Recite along"}</button>}
        <label className="flex items-center gap-2 text-ink-soft">Pace
          <input type="range" min={2} max={8} value={pace} onChange={(e) => setPace(+e.target.value)} className="accent-saffron" aria-label="Recitation pace" />
        </label>
        <label className="flex items-center gap-1.5 text-ink-soft"><input type="checkbox" className="accent-saffron" checked={repeat} onChange={(e) => setRepeat(e.target.checked)} /> Loop</label>
        <label className="flex items-center gap-1.5 text-ink-soft"><input type="checkbox" className="accent-saffron" checked={showIast} onChange={(e) => setShowIast(e.target.checked)} /> Transliteration</label>
      </div>
    </div>
  );
}
