"use client";
import { useEffect, useState } from "react";
import type { Vidhi } from "@/content/karmkand";
import { ringBell } from "@/lib/client/sound";
import { Diya } from "./Diya";

/** Samagri checklist plus a step-by-step "puja mode". Progress is kept in this browser. */
export function VidhiPlayer({ vidhi }: { vidhi: Vidhi }) {
  const key = `vidhi:${vidhi.slug}`;
  const [have, setHave] = useState<boolean[]>(() => vidhi.samagri.map(() => false));
  const [step, setStep] = useState(-1);
  useEffect(() => { try { const s = JSON.parse(localStorage.getItem(key) || "null"); if (s?.have?.length === vidhi.samagri.length) setHave(s.have); } catch {} }, [key, vidhi.samagri.length]);
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify({ have })); } catch {} }, [key, have]);
  const ready = have.filter(Boolean).length;
  const done = step >= vidhi.steps.length;

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.5fr]">
      <section className="leaf h-fit p-5" aria-labelledby="samagri">
        <div className="flex items-baseline justify-between gap-3">
          <h2 id="samagri" className="font-display text-2xl font-semibold text-maroon">Samagri</h2>
          <span className="text-sm tabular-nums text-ink-faint">{ready} / {vidhi.samagri.length} ready</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-gold/20"><div className="h-full rounded-full bg-saffron transition-all duration-500" style={{ width: `${(ready / vidhi.samagri.length) * 100}%` }} /></div>
        <ul className="mt-4 space-y-1.5">
          {vidhi.samagri.map((s, i) => (
            <li key={s}>
              <label className="flex cursor-pointer items-start gap-3 rounded-lg px-2 py-1.5 hover:bg-gold-pale/30">
                <input type="checkbox" className="mt-1 accent-saffron" checked={have[i]} onChange={() => setHave((h) => h.map((v, j) => (j === i ? !v : v)))} />
                <span className={have[i] ? "text-ink-faint line-through" : ""}>{s}</span>
              </label>
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="steps">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 id="steps" className="font-display text-2xl font-semibold text-maroon">Vidhi, step by step</h2>
          {step < 0
            ? <button className="btn-primary !py-2" onClick={() => { setStep(0); ringBell(0.2); }}>Start puja mode</button>
            : <button className="btn-ghost !py-2" onClick={() => setStep(-1)}>Show all steps</button>}
        </div>

        {step >= 0 && !done && (
          <div className="mt-5 overflow-hidden rounded-2xl bg-midnight p-6 text-ivory" aria-live="polite">
            <div className="flex items-center justify-between text-sm text-gold-pale"><span>Step {step + 1} of {vidhi.steps.length}</span><Diya size={40} /></div>
            <div className="mt-2 h-1 overflow-hidden rounded bg-ivory/10"><div className="h-full bg-gold-light transition-all duration-500" style={{ width: `${((step + 1) / vidhi.steps.length) * 100}%` }} /></div>
            <div key={step} style={{ animation: "rise .5s ease both" }}>
              <h3 className="mt-4 font-display text-3xl font-semibold text-gold-pale">{vidhi.steps[step].title}</h3>
              <p className="mt-2 text-lg text-ivory/85">{vidhi.steps[step].detail}</p>
              {vidhi.steps[step].mantra && (
                <div className="mt-4 rounded-xl border border-gold/30 p-4">
                  <p className="font-deva text-2xl leading-relaxed text-ivory">{vidhi.steps[step].mantra}</p>
                  {vidhi.steps[step].iast && <p className="mt-1 text-sm italic text-ivory/70">{vidhi.steps[step].iast}</p>}
                </div>
              )}
            </div>
            <div className="mt-6 flex gap-3">
              <button className="btn border border-gold/40 text-gold-pale disabled:opacity-40" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>Previous</button>
              <button className="btn-primary" onClick={() => { if (step + 1 >= vidhi.steps.length) ringBell(0.3); setStep((s) => s + 1); }}>{step + 1 >= vidhi.steps.length ? "Complete" : "Next step"}</button>
            </div>
          </div>
        )}
        {done && (
          <div className="mt-5 rounded-2xl bg-maroon p-6 text-center text-ivory" style={{ animation: "rise .5s ease both" }}>
            <Diya size={72} className="mx-auto" />
            <p className="mt-2 font-display text-3xl font-semibold text-gold-pale">Puja complete</p>
            <p className="mt-1 text-ivory/80">ॐ शान्तिः शान्तिः शान्तिः</p>
            <button className="btn mt-4 border border-gold/40 text-gold-pale" onClick={() => setStep(-1)}>Back to all steps</button>
          </div>
        )}

        {step < 0 && (
          <ol className="relative mt-5 space-y-4 border-l-2 border-gold/30 pl-6">
            {vidhi.steps.map((s, i) => (
              <li key={s.title} className="reveal relative">
                <span className="absolute -left-[2.15rem] top-1 grid h-7 w-7 place-items-center rounded-full bg-saffron text-sm font-semibold text-white">{i + 1}</span>
                <h3 className="font-display text-xl font-semibold text-maroon">{s.title}</h3>
                <p className="text-ink-soft">{s.detail}</p>
                {s.mantra && <p className="mt-1 font-deva text-lg text-maroon">{s.mantra}</p>}
                {s.iast && <p className="text-sm italic text-ink-faint">{s.iast}</p>}
              </li>
            ))}
          </ol>
        )}
      </section>
    </div>
  );
}
