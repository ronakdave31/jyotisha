/** Slow-turning mandala used as a quiet background ornament. */
export function Mandala({ size = 420, className = "" }: { size?: number; className?: string }) {
  const petals = (n: number, r: number, rx: number, ry: number) =>
    Array.from({ length: n }, (_, i) => <ellipse key={`${n}-${i}`} cx="100" cy={100 - r} rx={rx} ry={ry} transform={`rotate(${(360 / n) * i} 100 100)`} />);
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" className={`spin-slow ${className}`} aria-hidden fill="none" stroke="currentColor" strokeWidth=".6">
      <circle cx="100" cy="100" r="96" /><circle cx="100" cy="100" r="78" strokeDasharray="1 3" /><circle cx="100" cy="100" r="40" />
      {petals(24, 64, 6, 18)}{petals(12, 38, 8, 20)}{petals(8, 16, 5, 12)}
    </svg>
  );
}
