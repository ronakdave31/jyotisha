"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { NAV, SITE } from "@/lib/site";
import { LocationSelector } from "./LocationPicker";
import { SearchBox } from "./SearchBox";

export function Header({ location, lang, signedIn }: { location: string; lang: "en" | "hi"; signedIn: boolean }) {
  const path = usePathname();
  const router = useRouter();
  const [menu, setMenu] = useState(false);
  const setLang = (l: "en" | "hi") => {
    document.cookie = `lang=${l}; path=/; max-age=31536000; samesite=lax`;
    router.refresh();
  };
  const isActive = (href: string) => (href === "/" ? path === "/" : path.startsWith(href));
  const [open, setOpen] = useState<string | null>(null);
  const navRef = useRef<HTMLElement>(null);
  useEffect(() => { setOpen(null); setMenu(false); }, [path]);
  useEffect(() => {
    const close = (e: MouseEvent) => { if (!navRef.current?.contains(e.target as Node)) setOpen(null); };
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(null); };
    document.addEventListener("click", close); document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("click", close); document.removeEventListener("keydown", esc); };
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-gold/25 bg-ivory/90 backdrop-blur">
      <div className="container flex h-16 items-center gap-3">
        <Link href="/" className="flex items-center gap-2" aria-label={`${SITE.name} home`}>
          <svg width="30" height="30" viewBox="0 0 40 40" aria-hidden>
            <circle cx="20" cy="20" r="18" fill="none" stroke="#B8892E" strokeWidth="1.2" />
            {Array.from({ length: 8 }, (_, i) => (
              <ellipse key={i} cx="20" cy="11" rx="3.2" ry="8" fill="#E07A1F" opacity=".85" transform={`rotate(${i * 45} 20 20)`} />
            ))}
            <circle cx="20" cy="20" r="4" fill="#6B1E2A" />
          </svg>
          <span className="font-display text-2xl font-bold text-maroon">{SITE.name}</span>
        </Link>
        <div className="ml-auto hidden flex-1 justify-end lg:flex"><SearchBox /></div>
        <div className="ml-auto flex items-center gap-1 lg:ml-0">
          <LocationSelector current={location} />
          <div className="hidden items-center rounded-full border border-ink/10 p-0.5 text-xs sm:flex" role="group" aria-label="Language">
            {(["en", "hi"] as const).map((l) => (
              <button key={l} onClick={() => setLang(l)} aria-pressed={lang === l}
                className={`rounded-full px-2 py-1 ${lang === l ? "bg-maroon text-ivory" : "text-ink-soft"}`}>{l === "en" ? "EN" : "हि"}</button>
            ))}
          </div>
          <Link href={signedIn ? "/dashboard" : "/login"} className="rounded-full p-2 text-ink-soft hover:bg-maroon/5" aria-label={signedIn ? "My account" : "Sign in"}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" /></svg>
          </Link>
          <Link href="/kundli" className="btn-primary hidden !px-4 !py-2 md:inline-flex">Generate Kundli</Link>
          <button className="rounded-full p-2 lg:hidden" onClick={() => setMenu((m) => !m)} aria-expanded={menu} aria-controls="mobile-nav" aria-label="Menu">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">{menu ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}</svg>
          </button>
        </div>
      </div>
      <nav ref={navRef} aria-label="Main" className="hidden border-t border-gold/15 lg:block">
        <ul className="container flex items-center justify-center gap-1 py-1.5 text-[15px]">
          {NAV.map((n) => {
            const active = n.children ? n.children.some((c) => isActive(c.href)) : isActive(n.href);
            const cls = `relative rounded-full px-3 py-1.5 transition-colors after:absolute after:inset-x-3 after:-bottom-0.5 after:h-0.5 after:origin-left after:scale-x-0 after:rounded after:bg-saffron after:transition-transform hover:after:scale-x-100 ${active ? "font-medium text-maroon after:scale-x-100" : "text-ink-soft hover:text-maroon"}`;
            if (!n.children) return <li key={n.href}><Link href={n.href} aria-current={active ? "page" : undefined} className={cls}>{n.label}</Link></li>;
            return (
              <li key={n.href} className="relative" onMouseEnter={() => setOpen(n.label)} onMouseLeave={() => setOpen(null)}>
                <button className={`${cls} inline-flex items-center gap-1`} aria-expanded={open === n.label} aria-haspopup="true" onClick={() => setOpen(open === n.label ? null : n.label)}>
                  {n.label}<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className={`transition-transform ${open === n.label ? "rotate-180" : ""}`}><path d="m6 9 6 6 6-6" /></svg>
                </button>
                {open === n.label && (
                  <div className="absolute left-1/2 top-full z-50 w-80 -translate-x-1/2 pt-2" style={{ animation: "rise .25s ease both" }}>
                    <ul className="rounded-2xl border border-gold/30 bg-ivory p-2 shadow-card">
                      {n.children.map((c) => (
                        <li key={c.href}><Link href={c.href} aria-current={isActive(c.href) ? "page" : undefined} className="block rounded-xl px-3 py-2 hover:bg-gold-pale/40">
                          <span className="block font-medium text-maroon">{c.label}</span><span className="block text-xs text-ink-faint">{c.hint}</span>
                        </Link></li>
                      ))}
                    </ul>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      </nav>
      {menu && (
        <nav id="mobile-nav" aria-label="Main" className="border-t border-gold/20 bg-ivory lg:hidden">
          <div className="container space-y-3 py-4">
            <SearchBox />
            <ul className="grid grid-cols-2 gap-1">
              {NAV.flatMap((n): { href: string; label: string }[] => n.children ?? [n]).map((n) => (
                <li key={n.href + n.label}><Link onClick={() => setMenu(false)} href={n.href} className={`block rounded-lg px-3 py-2 ${isActive(n.href) ? "bg-maroon/10 text-maroon" : "text-ink"}`}>{n.label}</Link></li>
              ))}
            </ul>
            <div className="flex gap-2">
              <Link onClick={() => setMenu(false)} href="/kundli" className="btn-primary flex-1">Generate Kundli</Link>
              <button onClick={() => setLang(lang === "en" ? "hi" : "en")} className="btn-ghost">{lang === "en" ? "हिन्दी" : "English"}</button>
            </div>
          </div>
        </nav>
      )}
    </header>
  );
}
