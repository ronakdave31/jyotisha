"use client";
import { useState } from "react";
import { nameNumber, numerologyCompatibility, numerologyReport, type NumSystem } from "@/lib/numerology";

type Mode = "personal" | "name" | "compat";

/** Numerology is pure arithmetic, so it runs in the browser — instant and private. */
export function NumerologyApp() {
  const [mode, setMode] = useState<Mode>("personal");
  const [system, setSystem] = useState<NumSystem>("pythagorean");
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [name2, setName2] = useState("");
  const [dob2, setDob2] = useState("");
  const [err, setErr] = useState("");
  const [rep, setRep] = useState<ReturnType<typeof numerologyReport> | null>(null);
  const [nm, setNm] = useState<ReturnType<typeof nameNumber> | null>(null);
  const [cp, setCp] = useState<{ a: ReturnType<typeof numerologyReport>; b: ReturnType<typeof numerologyReport>; lp: ReturnType<typeof numerologyCompatibility>; bn: ReturnType<typeof numerologyCompatibility> } | null>(null);

  const run = () => {
    setErr("");
    try {
      if (mode === "personal") setRep(numerologyReport(name, dob, system));
      if (mode === "name") setNm(nameNumber(name, system));
      if (mode === "compat") {
        const a = numerologyReport(name, dob, system), b = numerologyReport(name2, dob2, system);
        setCp({ a, b, lp: numerologyCompatibility(a.lifePath.value, b.lifePath.value), bn: numerologyCompatibility(a.birthNumber.value, b.birthNumber.value) });
      }
    } catch (e) { setErr((e as Error).message); }
  };

  return (
    <div className="container py-10">
      <div className="leaf p-5 md:p-7">
        <div className="flex flex-wrap gap-2" role="tablist">
          {([["personal", "Personal report"], ["name", "Name / business / baby name"], ["compat", "Compatibility"]] as [Mode, string][]).map(([m, l]) => (
            <button key={m} role="tab" aria-selected={mode === m} onClick={() => setMode(m)} className={`btn border ${mode === m ? "border-maroon bg-maroon text-ivory" : "border-ink/15 text-ink-soft"}`}>{l}</button>
          ))}
        </div>
        <form className="mt-5 grid gap-3 md:grid-cols-3" onSubmit={(e) => { e.preventDefault(); run(); }}>
          <div className="md:col-span-1"><label className="label" htmlFor="n1">{mode === "name" ? "Name to test" : "Full name at birth"}</label><input id="n1" className="input" required value={name} onChange={(e) => setName(e.target.value)} /></div>
          {mode !== "name" && <div><label className="label" htmlFor="d1">Date of birth</label><input id="d1" type="date" className="input" required value={dob} onChange={(e) => setDob(e.target.value)} /></div>}
          <div><label className="label" htmlFor="sys">System</label>
            <select id="sys" className="input" value={system} onChange={(e) => setSystem(e.target.value as NumSystem)}><option value="pythagorean">Pythagorean (1–9 sequence)</option><option value="chaldean">Chaldean (sound values 1–8)</option></select>
          </div>
          {mode === "compat" && <>
            <div><label className="label" htmlFor="n2">Partner&apos;s full name</label><input id="n2" className="input" required value={name2} onChange={(e) => setName2(e.target.value)} /></div>
            <div><label className="label" htmlFor="d2">Partner&apos;s date of birth</label><input id="d2" type="date" className="input" required value={dob2} onChange={(e) => setDob2(e.target.value)} /></div>
          </>}
          <div className="md:col-span-3"><button className="btn-primary">Calculate</button>{err && <span role="alert" className="ml-3 text-sm text-maroon">{err}</span>}</div>
        </form>
      </div>

      {mode === "personal" && rep && (
        <section className="mt-8 space-y-6" aria-live="polite">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              ["Birth (Psychic) number", rep.birthNumber.value, rep.birthNumber.calc, rep.birthNumber.traits],
              ["Life Path number", rep.lifePath.value, rep.lifePath.calc, rep.lifePath.traits],
              ["Destiny / Expression", rep.expression.value, `All letters total ${rep.expression.total}`, rep.expression.traits],
              ["Soul Urge", rep.soulUrge.value, `Vowels total ${rep.soulUrge.total}`, rep.soulUrge.traits],
              ["Personality", rep.personality.value, `Consonants total ${rep.personality.total}`, rep.personality.traits],
              ["Personal Year", rep.personalYear.value, `For ${rep.personalYear.year}`, "A one-year cycle that sets the tone for the year's focus."],
            ].map(([t, v, c, d]) => (
              <article key={t as string} className="leaf p-5">
                <div className="flex items-baseline justify-between"><h3 className="font-display text-xl font-semibold text-maroon">{t}</h3><span className="font-display text-4xl font-bold text-saffron">{v}</span></div>
                <p className="text-xs text-ink-faint">{c}</p>
                <p className="mt-2 text-[15px] text-ink-soft">{d}</p>
              </article>
            ))}
          </div>
          <div className="rounded-2xl bg-midnight p-5 text-ivory">
            <h3 className="font-display text-xl font-semibold text-gold-pale">Lucky factors (ruling planet {rep.birthNumber.planet})</h3>
            <p className="mt-2">Numbers {rep.lucky.numbers.join(", ")} · Colours {rep.lucky.colors.join(", ")} · Days {rep.lucky.days.join(", ")} · Gemstone {rep.lucky.gem}</p>
          </div>
          <LetterTable letters={rep.expression.letters} />
          <button className="btn-ghost no-print" onClick={() => window.print()}>Download report (PDF)</button>
        </section>
      )}

      {mode === "name" && nm && (
        <section className="mt-8 space-y-4" aria-live="polite">
          <div className="leaf p-5">
            <p className="text-ink-soft">{nm.system === "chaldean" ? "Chaldean" : "Pythagorean"} name number for <strong className="text-ink">{nm.name}</strong></p>
            <p className="font-display text-5xl font-bold text-saffron">{nm.value} <span className="text-xl font-normal text-ink-faint">(total {nm.total}, ruled by {nm.planet})</span></p>
            <p className="mt-2 text-ink-soft">{nm.traits}</p>
          </div>
          <LetterTable letters={nm.letters} />
        </section>
      )}

      {mode === "compat" && cp && (
        <section className="mt-8 grid gap-4 md:grid-cols-2" aria-live="polite">
          {[["Life Path", cp.lp], ["Birth number", cp.bn]].map(([t, c]) => {
            const x = c as typeof cp.lp;
            return (
              <div key={t as string} className="leaf p-5">
                <h3 className="font-display text-xl font-semibold text-maroon">{t as string}: {x.a} and {x.b}</h3>
                <p className={`mt-1 text-2xl font-semibold ${x.level === "Harmonious" ? "text-emerald-800" : x.level === "Workable" ? "text-saffron-dark" : "text-maroon"}`}>{x.level}</p>
              </div>
            );
          })}
        </section>
      )}
    </div>
  );
}

function LetterTable({ letters }: { letters: { letter: string; value: number }[] }) {
  return (
    <div className="leaf overflow-x-auto p-5">
      <h3 className="font-display text-xl font-semibold text-maroon">Letter values</h3>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {letters.map((l, i) => <span key={i} className="grid w-9 rounded border border-gold/30 bg-white text-center"><span className="text-sm font-medium">{l.letter}</span><span className="text-xs text-saffron-dark">{l.value}</span></span>)}
      </div>
    </div>
  );
}
