import Link from "next/link";
import type { Panchang, Span } from "@/lib/astro/panchang";
import { fmtDate, fmtTime } from "@/lib/astro/time";
import { PLANET_HI } from "@/lib/astro/constants";

type Lang = "en" | "hi";

const LABELS: Record<string, [string, string]> = {
  tithi: ["Tithi", "तिथि"], nakshatra: ["Nakshatra", "नक्षत्र"], yoga: ["Yoga", "योग"], karana: ["Karana", "करण"],
  vara: ["Vara", "वार"], paksha: ["Paksha", "पक्ष"], moonSign: ["Moon sign", "चन्द्र राशि"], sunSign: ["Sun sign", "सूर्य राशि"],
};
const L = (k: string, lang: Lang) => (lang === "hi" ? `${LABELS[k][1]}` : LABELS[k][0]);

function SpanList({ spans, tz, date, lang }: { spans: Span[]; tz: string; date: string; lang: Lang }) {
  return (
    <ul className="space-y-0.5">
      {spans.map((s, i) => (
        <li key={`${s.index}-${i}`} className={i > 0 ? "text-ink-soft" : ""}>
          <span className={i === 0 ? "font-semibold text-ink" : ""}>{lang === "hi" ? s.nameHi : s.name}</span>{" "}
          <span className="text-sm text-ink-faint">
            {i === spans.length - 1 && s.end ? `upto ${fmtTime(s.end, tz, date)}` : s.end ? `upto ${fmtTime(s.end, tz, date)}` : ""}
          </span>
        </li>
      ))}
    </ul>
  );
}

function WindowRow({ name, start, end, tz, date, note, tone }: { name: string; start: string; end: string; tz: string; date: string; note?: string; tone: "good" | "bad" }) {
  return (
    <li className="flex items-baseline justify-between gap-3 py-1.5">
      <span>
        <span className={`mr-2 inline-block h-2 w-2 rounded-full ${tone === "good" ? "bg-emerald-700" : "bg-maroon"}`} aria-hidden />
        {name}{note && <span className="ml-1 text-xs text-ink-faint">({note})</span>}
      </span>
      <span className="whitespace-nowrap tabular-nums text-ink-soft">{fmtTime(start, tz, date)} – {fmtTime(end, tz, date)}</span>
    </li>
  );
}

export function PanchangSummary({ p, place, lang }: { p: Panchang; place: string; lang: Lang }) {
  const { tz, date } = p.meta;
  const rahu = p.inauspicious.find((w) => w.name === "Rahu Kaal")!;
  const abhijit = p.auspicious.find((w) => w.name === "Abhijit Muhurat")!;
  const rows: [string, React.ReactNode][] = [
    [L("tithi", lang), <SpanList key="t" spans={p.tithi.slice(0, 2)} tz={tz} date={date} lang={lang} />],
    [L("nakshatra", lang), <SpanList key="n" spans={p.nakshatra.slice(0, 2)} tz={tz} date={date} lang={lang} />],
    [L("yoga", lang), <SpanList key="y" spans={p.yoga.slice(0, 1)} tz={tz} date={date} lang={lang} />],
    [L("karana", lang), <SpanList key="k" spans={p.karana.slice(0, 1)} tz={tz} date={date} lang={lang} />],
    [L("vara", lang), lang === "hi" ? p.vara.nameHi : `${p.vara.name} (${p.vara.english})`],
    ["Rahu Kaal", `${fmtTime(rahu.start, tz)} – ${fmtTime(rahu.end, tz)}`],
    ["Abhijit Muhurat", `${fmtTime(abhijit.start, tz)} – ${fmtTime(abhijit.end, tz)}`],
  ];
  return (
    <div className="leaf overflow-hidden">
      <div className="flex flex-wrap items-end justify-between gap-2 border-b border-gold/25 bg-maroon px-5 py-4 text-ivory">
        <div>
          <p className="font-display text-2xl font-semibold">{fmtDate(date, tz)}</p>
          <p className="text-sm text-ivory/80">
            {p.masa.amanta.en} {p.paksha} {p.tithi[0].name} · Vikram Samvat {p.samvat.vikramChaitradi} · Shaka {p.samvat.shaka}
          </p>
        </div>
        <p className="text-sm text-gold-pale">{place}</p>
      </div>
      <dl className="grid gap-x-8 px-5 py-4 sm:grid-cols-2">
        {rows.map(([k, v]) => (
          <div key={k} className="grid grid-cols-[7.5rem_1fr] gap-2 border-b border-gold/15 py-2.5 last:border-0">
            <dt className="text-ink-faint">{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
        <div className="grid grid-cols-[7.5rem_1fr] gap-2 py-2.5">
          <dt className="text-ink-faint">Sun / Moon</dt>
          <dd className="text-sm">
            ↑ {fmtTime(p.sun.sunrise, tz)} ↓ {fmtTime(p.sun.sunset, tz)}<br />
            Moon ↑ {fmtTime(p.moon.moonrise, tz)} ↓ {fmtTime(p.moon.moonset, tz)}
          </dd>
        </div>
      </dl>
    </div>
  );
}

const CHOG_TONE: Record<string, string> = { Amrit: "text-emerald-800", Shubh: "text-emerald-800", Labh: "text-emerald-800", Char: "text-ink", Udveg: "text-maroon", Rog: "text-maroon", Kaal: "text-maroon" };

export function PanchangFull({ p, place, lang }: { p: Panchang; place: string; lang: Lang }) {
  const { tz, date } = p.meta;
  const t = (s: string | null) => fmtTime(s, tz, date);
  const crossesMidnight = (s: string | null) => s && new Date(s).toLocaleDateString("en-CA", { timeZone: tz }) !== date;
  const limb = (key: "tithi" | "nakshatra" | "yoga" | "karana") => (
    <tr className="border-b border-gold/15 align-top last:border-0">
      <th scope="row" className="w-36 py-3 pr-4 text-left font-normal text-ink-faint">{L(key, lang)}<span className="block font-deva text-xs">{LABELS[key][lang === "hi" ? 0 : 1]}</span></th>
      <td className="py-3">
        <ul className="space-y-1">
          {p[key].map((s, i) => (
            <li key={i} className="flex flex-wrap items-baseline justify-between gap-x-4">
              <span className={i === 0 ? "font-semibold" : ""}>
                {lang === "hi" ? s.nameHi : s.name}
                {key === "nakshatra" && s.extra?.lord ? <span className="ml-1 text-xs text-ink-faint">lord {String(s.extra.lord)}</span> : null}
                {key === "yoga" && s.extra?.auspicious === false ? <span className="ml-1 text-xs text-maroon">inauspicious</span> : null}
              </span>
              <span className="text-sm tabular-nums text-ink-soft">
                {t(s.start)} → {t(s.end)}
                {crossesMidnight(s.end) && <span className="ml-1 rounded bg-midnight/10 px-1 text-[11px] text-midnight">next day</span>}
              </span>
            </li>
          ))}
        </ul>
      </td>
    </tr>
  );

  return (
    <div className="space-y-8">
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <section className="leaf p-5" aria-labelledby="limbs">
          <h2 id="limbs" className="font-display text-2xl font-semibold text-maroon">Panchang — the five limbs</h2>
          <p className="text-sm text-ink-faint">Hindu day from sunrise {t(p.sun.sunrise)} to next sunrise {t(p.sun.nextSunrise)} · {place}</p>
          <table className="mt-3 w-full text-[15px]">
            <tbody>
              {limb("tithi")}
              {limb("nakshatra")}
              {limb("yoga")}
              {limb("karana")}
              <tr className="align-top">
                <th scope="row" className="py-3 pr-4 text-left font-normal text-ink-faint">{L("vara", lang)}</th>
                <td className="py-3 font-semibold">{lang === "hi" ? p.vara.nameHi : p.vara.name} <span className="font-normal text-ink-soft">({p.vara.english}, ruled by {p.vara.lord})</span></td>
              </tr>
            </tbody>
          </table>
        </section>

        <section className="leaf p-5" aria-labelledby="calendar">
          <h2 id="calendar" className="font-display text-2xl font-semibold text-maroon">Calendar</h2>
          <dl className="mt-3 space-y-2 text-[15px]">
            {[
              ["Paksha", `${p.paksha} Paksha`],
              ["Month (Amanta)", `${p.masa.amanta.en}${p.masa.amanta.adhik ? " (Adhik)" : ""}`],
              ["Month (Purnimanta)", `${p.masa.purnimanta.en}${p.masa.purnimanta.adhik ? " (Adhik)" : ""}`],
              ["Vikram Samvat", `${p.samvat.vikramChaitradi} (Chaitradi) · ${p.samvat.vikramKartikadi} (Kartikadi, Gujarat)`],
              ["Shaka Samvat", `${p.samvat.shaka} — ${p.samvat.samvatsara}`],
              ["Ritu / Ayana", `${p.ritu.en} · ${p.sun.ayana}`],
              [L("sunSign", lang), lang === "hi" ? p.sun.sign.nameHi : p.sun.sign.name],
              [L("moonSign", lang), p.moon.signs.map((s) => `${lang === "hi" ? s.nameHi : s.name}${s.end && new Date(s.end) < new Date(p.sun.nextSunrise!) ? ` upto ${t(s.end)}` : ""}`).join(", then ")],
              ["Moon phase", `${p.moon.phaseName}, ${(p.moon.illumination * 100).toFixed(0)}% lit`],
              ["Next Sankranti", p.sun.nextSankranti ? `${p.sun.nextSankranti.sign}, ${fmtTime(p.sun.nextSankranti.at, tz, date)}` : "—"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 border-b border-gold/15 pb-2 last:border-0">
                <dt className="text-ink-faint">{k}</dt><dd className="text-right">{v}</dd>
              </div>
            ))}
          </dl>
        </section>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <section className="leaf p-5">
          <h2 className="font-display text-xl font-semibold text-maroon">Sun & Moon</h2>
          <ul className="mt-2 space-y-1.5 text-[15px]">
            {[["Sunrise", p.sun.sunrise], ["Sunset", p.sun.sunset], ["Moonrise", p.moon.moonrise], ["Moonset", p.moon.moonset]].map(([k, v]) => (
              <li key={k} className="flex justify-between"><span className="text-ink-faint">{k}</span><span className="tabular-nums">{v ? t(v) : "None this day"}</span></li>
            ))}
            <li className="flex justify-between"><span className="text-ink-faint">Day length</span><span>{Math.floor(p.sun.dayLengthMinutes / 60)}h {p.sun.dayLengthMinutes % 60}m</span></li>
          </ul>
        </section>
        <section className="leaf p-5">
          <h2 className="font-display text-xl font-semibold text-emerald-900">Auspicious timings</h2>
          <ul className="mt-2 text-[15px]">{p.auspicious.map((w, i) => <WindowRow key={i} {...w} tz={tz} date={date} tone="good" />)}</ul>
        </section>
        <section className="leaf p-5">
          <h2 className="font-display text-xl font-semibold text-maroon">Inauspicious timings</h2>
          <ul className="mt-2 text-[15px]">{p.inauspicious.map((w, i) => <WindowRow key={i} {...w} tz={tz} date={date} tone="bad" />)}</ul>
        </section>
      </div>

      <section id="choghadiya" className="leaf p-5" aria-labelledby="chog">
        <h2 id="chog" className="font-display text-2xl font-semibold text-maroon">Choghadiya</h2>
        <p className="text-sm text-ink-faint">Day and night each split into eight parts. Amrit, Shubh and Labh are favoured for new work.</p>
        <div className="mt-3 grid gap-6 md:grid-cols-2">
          {(["day", "night"] as const).map((part) => (
            <table key={part} className="w-full text-[15px]">
              <caption className="mb-1 text-left font-medium capitalize">{part}</caption>
              <tbody>
                {p.choghadiya[part].map((c, i) => (
                  <tr key={i} className="border-b border-gold/10 last:border-0">
                    <td className={`py-1.5 font-medium ${CHOG_TONE[c.name]}`}>{c.name} <span className="text-xs font-normal text-ink-faint">{c.quality}</span></td>
                    <td className="py-1.5 text-right tabular-nums text-ink-soft">{t(c.start)} – {t(c.end)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ))}
        </div>
      </section>

      <section className="leaf p-5" aria-labelledby="hora">
        <h2 id="hora" className="font-display text-2xl font-semibold text-maroon">Hora</h2>
        <p className="text-sm text-ink-faint">Planetary hours, starting from the weekday lord at sunrise.</p>
        <ol className="mt-3 grid gap-x-6 gap-y-1 text-[15px] sm:grid-cols-2 lg:grid-cols-4">
          {p.hora.map((h, i) => (
            <li key={i} className="flex justify-between border-b border-gold/10 py-1">
              <span>{lang === "hi" ? PLANET_HI[h.lord] : h.lord}</span><span className="tabular-nums text-ink-soft">{t(h.start)}</span>
            </li>
          ))}
        </ol>
      </section>

      <p className="text-xs text-ink-faint">
        Calculated with {p.meta.engine}, {p.meta.ayanamsa} ayanamsa {p.meta.ayanamsaValue.toFixed(4)}°, {p.meta.node} node; {p.meta.method}. Coordinates {p.meta.lat.toFixed(4)}, {p.meta.lon.toFixed(4)} ({tz}). <Link className="underline" href="/methodology">How we calculate</Link>
      </p>
    </div>
  );
}

export const PANCHANG_GLOSSARY = [
  { q: "What is a Tithi?", a: "A lunar day: the time the Moon takes to gain 12° on the Sun. There are 30 tithis in a lunar month, 15 in the bright half (Shukla Paksha) and 15 in the dark half (Krishna Paksha). Because the Moon's speed varies, a tithi lasts roughly 19 to 26 hours, so it can begin and end at any time of day." },
  { q: "What is a Nakshatra?", a: "One of 27 lunar mansions, each 13°20′ of the sidereal zodiac. The day's nakshatra is the one the Moon occupies; each has a ruling planet and deity used in Muhurat and Dasha calculations." },
  { q: "What are Yoga and Karana?", a: "Yoga is the sum of the Sun's and Moon's sidereal longitudes divided into 27 parts. Karana is half a tithi (6° of elongation); there are 11 karanas, of which Vishti (Bhadra) is avoided for auspicious work." },
  { q: "How is Rahu Kaal calculated?", a: "The time from local sunrise to sunset is divided into eight equal parts. Rahu Kaal is a fixed part for each weekday (for example the 8th part on Sunday, the 2nd on Monday). It therefore shifts with the season and your city." },
  { q: "Why do Amanta and Purnimanta months differ?", a: "In the Amanta system (South and West India) a month ends on the new moon; in the Purnimanta system (North India) it ends on the full moon. During Krishna Paksha the Purnimanta month name runs one ahead of the Amanta name. Festival dates are the same in both." },
  { q: "Why do timings change between cities?", a: "Sunrise, sunset and every period derived from them depend on latitude and longitude. Tithi and Nakshatra end at the same instant worldwide, but the local clock time and the tithi prevailing at sunrise differ by place." },
];
