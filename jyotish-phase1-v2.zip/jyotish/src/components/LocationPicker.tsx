"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

export interface PickedLoc { name: string; region?: string; lat: number; lon: number; tz: string; slug?: string }

export function saveLocationCookie(l: PickedLoc) {
  const v = encodeURIComponent(JSON.stringify({ name: l.name, lat: l.lat, lon: l.lon, tz: l.tz, slug: l.slug }));
  document.cookie = `loc=${v}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
}

/** Place search with curated cities, OpenStreetMap results and browser GPS. */
export function PlaceSearch({ onPick, placeholder = "Search a city or town", autoFocus = false, initial = "" }: {
  onPick: (l: PickedLoc) => void; placeholder?: string; autoFocus?: boolean; initial?: string;
}) {
  const [q, setQ] = useState(initial);
  const [results, setResults] = useState<PickedLoc[]>([]);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [active, setActive] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    clearTimeout(timer.current);
    if (!open) return;
    timer.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/geocode?q=${encodeURIComponent(q)}`);
        const j = await r.json();
        setResults(j.results ?? []);
        setActive(0);
      } catch { setResults([]); }
    }, 250);
  }, [q, open]);

  const pick = (l: PickedLoc) => { setQ(l.name); setOpen(false); onPick(l); };

  const gps = () => {
    if (!navigator.geolocation) { setMsg("Location is not available in this browser."); return; }
    setBusy(true); setMsg("");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setBusy(false);
        const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
        pick({ name: "My location", lat: +p.coords.latitude.toFixed(4), lon: +p.coords.longitude.toFixed(4), tz });
      },
      () => { setBusy(false); setMsg("Location permission was denied. Search for your city instead."); },
      { timeout: 10000 },
    );
  };

  return (
    <div className="relative">
      <div className="flex gap-2">
        <input
          className="input" value={q} placeholder={placeholder} autoFocus={autoFocus}
          role="combobox" aria-expanded={open} aria-controls="place-results" aria-autocomplete="list"
          onFocus={() => setOpen(true)}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(a + 1, results.length - 1)); }
            if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
            if (e.key === "Enter" && results[active]) { e.preventDefault(); pick(results[active]); }
            if (e.key === "Escape") setOpen(false);
          }}
        />
        <button type="button" onClick={gps} className="btn-ghost shrink-0 px-3" aria-label="Use my current location" title="Use my current location">
          {busy ? "…" : (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="3.5" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3" /><circle cx="12" cy="12" r="8" /></svg>
          )}
        </button>
      </div>
      {msg && <p className="mt-1 text-sm text-maroon">{msg}</p>}
      {open && results.length > 0 && (
        <ul id="place-results" role="listbox" className="absolute z-50 mt-1 max-h-72 w-full overflow-auto rounded-lg border border-ink/10 bg-white py-1 shadow-card">
          {results.map((r, i) => (
            <li key={`${r.name}-${r.lat}-${i}`} role="option" aria-selected={i === active}>
              <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => pick(r)}
                className={`flex w-full items-baseline justify-between gap-3 px-3 py-2 text-left ${i === active ? "bg-saffron/10" : "hover:bg-ivory-deep"}`}>
                <span className="text-ink">{r.name}</span>
                <span className="truncate text-xs text-ink-faint">{r.region}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Header location selector: stores the choice in a cookie so every page is computed for it. */
export function LocationSelector({ current }: { current: string }) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-sm text-ink-soft hover:bg-maroon/5" aria-haspopup="dialog" aria-expanded={open}>
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 21s7-6.1 7-11.5A7 7 0 0 0 5 9.5C5 14.9 12 21 12 21z" /><circle cx="12" cy="9.5" r="2.5" /></svg>
        <span className="max-w-[9rem] truncate">{current}</span>
      </button>
      {open && (
        <div role="dialog" aria-label="Choose location" className="absolute right-0 z-50 mt-2 w-80 rounded-xl border border-gold/30 bg-ivory p-3 shadow-card">
          <p className="mb-2 text-sm text-ink-soft">Panchang timings are calculated for this place.</p>
          <PlaceSearch autoFocus onPick={(l) => { saveLocationCookie(l); setOpen(false); router.refresh(); }} />
        </div>
      )}
    </div>
  );
}
