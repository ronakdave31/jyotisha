"use client";
import { useState } from "react";
import { PlaceSearch, type PickedLoc } from "../LocationPicker";

export interface BirthValue {
  name: string;
  date: string;
  time: string;
  place: PickedLoc | null;
  gender: "" | "male" | "female" | "other";
}

export const emptyBirth: BirthValue = { name: "", date: "", time: "", place: null, gender: "" };

/** Reusable birth-details fieldset (Kundli, Matching, Profiles). */
export function BirthFields({ value, onChange, idPrefix, legend, showGender = true }: {
  value: BirthValue; onChange: (v: BirthValue) => void; idPrefix: string; legend?: string; showGender?: boolean;
}) {
  const [manual, setManual] = useState(false);
  const set = (patch: Partial<BirthValue>) => onChange({ ...value, ...patch });
  return (
    <fieldset className="grid gap-3 sm:grid-cols-2">
      {legend && <legend className="mb-2 font-display text-xl font-semibold text-maroon">{legend}</legend>}
      <div className="sm:col-span-2">
        <label className="label" htmlFor={`${idPrefix}-name`}>Name</label>
        <input id={`${idPrefix}-name`} className="input" value={value.name} onChange={(e) => set({ name: e.target.value })} maxLength={80} />
      </div>
      <div>
        <label className="label" htmlFor={`${idPrefix}-date`}>Date of birth</label>
        <input id={`${idPrefix}-date`} type="date" required className="input" min="1800-01-01" max="2200-12-31" value={value.date} onChange={(e) => set({ date: e.target.value })} />
      </div>
      <div>
        <label className="label" htmlFor={`${idPrefix}-time`}>Time of birth</label>
        <input id={`${idPrefix}-time`} type="time" step="1" required className="input" value={value.time} onChange={(e) => set({ time: e.target.value })} />
      </div>
      <div className="sm:col-span-2">
        <span className="label">Birthplace</span>
        {!manual ? (
          <PlaceSearch initial={value.place?.name ?? ""} onPick={(l) => set({ place: l })} placeholder="Type the town or city of birth" />
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <input aria-label="Latitude" className="input" placeholder="Lat" inputMode="decimal" defaultValue={value.place?.lat ?? ""} onChange={(e) => set({ place: { ...(value.place ?? { name: "Custom", lon: 0, tz: "Asia/Kolkata" }), lat: +e.target.value } as PickedLoc })} />
            <input aria-label="Longitude" className="input" placeholder="Lon" inputMode="decimal" defaultValue={value.place?.lon ?? ""} onChange={(e) => set({ place: { ...(value.place ?? { name: "Custom", lat: 0, tz: "Asia/Kolkata" }), lon: +e.target.value } as PickedLoc })} />
            <input aria-label="IANA time zone" className="input" placeholder="Asia/Kolkata" defaultValue={value.place?.tz ?? "Asia/Kolkata"} onChange={(e) => set({ place: { ...(value.place ?? { name: "Custom", lat: 0, lon: 0 }), tz: e.target.value } as PickedLoc })} />
          </div>
        )}
        <div className="mt-1 flex flex-wrap justify-between gap-2 text-xs text-ink-faint">
          <span>{value.place ? `${value.place.lat.toFixed?.(4) ?? value.place.lat}, ${value.place.lon.toFixed?.(4) ?? value.place.lon} · ${value.place.tz}` : "Coordinates and time zone are filled in automatically."}</span>
          <button type="button" className="underline" onClick={() => setManual((m) => !m)}>{manual ? "Search by name" : "Enter coordinates manually"}</button>
        </div>
      </div>
      {showGender && (
        <div>
          <label className="label" htmlFor={`${idPrefix}-gender`}>Gender (optional)</label>
          <select id={`${idPrefix}-gender`} className="input" value={value.gender} onChange={(e) => set({ gender: e.target.value as BirthValue["gender"] })}>
            <option value="">Prefer not to say</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option>
          </select>
        </div>
      )}
    </fieldset>
  );
}

export function toBirthPayload(v: BirthValue, extra: Record<string, unknown> = {}) {
  if (!v.place) throw new Error("Choose a birthplace.");
  return {
    name: v.name || undefined,
    date: v.date,
    time: v.time.length === 5 ? v.time : v.time.slice(0, 8),
    tz: v.place.tz,
    lat: v.place.lat,
    lon: v.place.lon,
    place: v.place.name,
    gender: v.gender || undefined,
    ...extra,
  };
}
