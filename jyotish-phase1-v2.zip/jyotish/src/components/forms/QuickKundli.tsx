"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { PlaceSearch, type PickedLoc } from "../LocationPicker";

/** Homepage quick form: hands the birth details to /kundli, which calculates immediately. */
export function QuickKundli() {
  const router = useRouter();
  const [place, setPlace] = useState<PickedLoc | null>(null);
  const [err, setErr] = useState("");
  return (
    <form
      className="grid gap-3 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        if (!place) { setErr("Choose a birthplace from the list."); return; }
        const qs = new URLSearchParams({
          name: String(f.get("name") || ""), date: String(f.get("date")), time: String(f.get("time")),
          lat: String(place.lat), lon: String(place.lon), tz: place.tz, place: place.name, go: "1",
        });
        router.push(`/kundli?${qs}`);
      }}
    >
      <div className="sm:col-span-2"><label className="label" htmlFor="qk-name">Name</label><input id="qk-name" name="name" className="input" autoComplete="name" /></div>
      <div><label className="label" htmlFor="qk-date">Date of birth</label><input id="qk-date" name="date" type="date" required className="input" min="1800-01-01" max="2200-12-31" /></div>
      <div><label className="label" htmlFor="qk-time">Time of birth</label><input id="qk-time" name="time" type="time" required className="input" /></div>
      <div className="sm:col-span-2"><span className="label">Birthplace</span><PlaceSearch onPick={(l) => { setPlace(l); setErr(""); }} placeholder="Type your birth city" /></div>
      {err && <p className="text-sm text-maroon sm:col-span-2" role="alert">{err}</p>}
      <button className="btn-primary sm:col-span-2" type="submit">Generate Kundli</button>
    </form>
  );
}
