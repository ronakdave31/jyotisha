"use client";
import { useCallback, useEffect, useState } from "react";
import { buzz, ringBell } from "@/lib/client/sound";

/**
 * Japa counter shaped like a mala: each tap lights a bead; the bell rings at
 * the end of a round. Progress is kept in this browser only.
 */
export function ChantCounter({ id, target = 108, label = "Count one chant" }: { id: string; target?: number; label?: string }) {
  const key = `chant:${id}`;
  const [count, setCount] = useState(0);
  const [rounds, setRounds] = useState(0);
  const [goal, setGoal] = useState(target);
  const [sound, setSound] = useState(true);
  const [pulse, setPulse] = useState(0);

  useEffect(() => {
    try { const s = JSON.parse(localStorage.getItem(key) || "null"); if (s) { setCount(s.count ?? 0); setRounds(s.rounds ?? 0); setGoal(s.goal ?? target); setSound(s.sound ?? true); } } catch {}
  }, [key, target]);
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify({ count, rounds, goal, sound })); } catch {} }, [key, count, rounds, goal, sound]);

  const tap = useCallback(() => {
    setPulse((p) => p + 1);
    buzz();
    setCount((c) => {
      if (c + 1 >= goal) {
        setRounds((r) => r + 1);
        if (sound) ringBell(0.3);
        buzz(120);
        return 0;
      }
      if (sound && (c + 1) % 27 === 0) ringBell(0.08, 880);
      return c + 1;
    });
  }, [goal, sound]);

  const beads = Math.min(goal, 108);
  const lit = Math.round((count / goal) * beads);

  return (
    <div className="flex flex-wrap items-center gap-6">
      <button
        onClick={tap}
        onKeyDown={(e) => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); tap(); } }}
        aria-label={`${label}. ${count} of ${goal}`}
        className="relative grid h-40 w-40 shrink-0 place-items-center rounded-full text-ivory transition-transform active:scale-95"
      >
        <svg className="absolute inset-0" viewBox="0 0 160 160" aria-hidden>
          <circle cx="80" cy="80" r="56" fill="#6B1E2A" />
          {Array.from({ length: beads }, (_, i) => {
            const a = (i / beads) * Math.PI * 2 - Math.PI / 2;
            return <circle key={i} cx={80 + 70 * Math.cos(a)} cy={80 + 70 * Math.sin(a)} r={beads > 60 ? 2.6 : 4}
              fill={i < lit ? "#D9B464" : "rgba(184,137,46,.25)"} style={{ transition: "fill .2s" }} />;
          })}
          <circle cx="80" cy="8" r="5.5" fill="#E07A1F" />
        </svg>
        {pulse > 0 && <span key={pulse} className="pointer-events-none absolute inset-6 rounded-full border-2 border-gold-light" style={{ animation: "ripple .7s ease-out forwards" }} aria-hidden />}
        <span className="relative text-center leading-none">
          <span key={`n${pulse}`} className="block font-display text-4xl font-semibold" style={{ animation: pulse ? "pop .3s ease" : undefined }} aria-live="polite">{count}</span>
          <span className="text-xs text-gold-pale">of {goal}</span>
        </span>
      </button>
      <div className="space-y-2 text-sm text-ink-soft">
        <p>Rounds completed: <strong className="font-display text-xl text-maroon">{rounds}</strong></p>
        <label className="flex items-center gap-2">Round of
          <select className="input !w-auto !py-1" value={goal} onChange={(e) => { setGoal(+e.target.value); setCount(0); }}>{[11, 21, 27, 54, 108, 1008].map((n) => <option key={n}>{n}</option>)}</select>
        </label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={sound} onChange={(e) => setSound(e.target.checked)} className="accent-saffron" /> Bell at the end of each round</label>
        <button className="underline" onClick={() => { setCount(0); setRounds(0); }}>Reset</button>
        <p className="text-xs text-ink-faint">Tap the mala, or press Space when it is focused.</p>
      </div>
    </div>
  );
}
