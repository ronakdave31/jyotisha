"use client";
import { useState } from "react";

export function Newsletter() {
  const [state, setState] = useState<"idle" | "busy" | "done" | "error">("idle");
  const [msg, setMsg] = useState("");
  return (
    <form className="flex flex-col gap-2 sm:flex-row" onSubmit={async (e) => {
      e.preventDefault();
      setState("busy");
      const email = new FormData(e.currentTarget).get("email");
      const r = await fetch("/api/newsletter", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email }) });
      const j = await r.json().catch(() => ({}));
      if (r.ok) { setState("done"); setMsg("Subscribed. Festival reminders will reach your inbox."); } else { setState("error"); setMsg(j.error || "Could not subscribe."); }
    }}>
      <label htmlFor="nl-email" className="sr-only">Email address</label>
      <input id="nl-email" name="email" type="email" required placeholder="you@example.com" className="input sm:max-w-xs" />
      <button className="btn-primary" disabled={state === "busy"}>{state === "busy" ? "Subscribing…" : "Subscribe"}</button>
      {msg && <p role="status" className={`text-sm sm:self-center ${state === "error" ? "text-maroon" : "text-emerald-800"}`}>{msg}</p>}
    </form>
  );
}
