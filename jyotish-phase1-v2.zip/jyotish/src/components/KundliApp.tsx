"use client";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import type { Kundli } from "@/lib/astro/kundli";
import type { interpret } from "@/lib/astro/interpretations";
import { RASHIS, VIMSHOTTARI_YEARS, type Planet } from "@/lib/astro/constants";
import { BirthFields, emptyBirth, toBirthPayload, type BirthValue } from "./forms/BirthFields";
import { NorthChart, SouthChart, placementsFrom } from "./Charts";

type Result = Kundli & { interpretation: ReturnType<typeof interpret> };
type Tab = "chart" | "planets" | "vargas" | "dasha" | "yogas" | "reports" | "transits";

const fmtDeg = (d: number) => `${Math.floor(d)}°${String(Math.floor((d % 1) * 60)).padStart(2, "0")}′`;
const fmtD = (iso: string) => new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });

export function KundliApp({ signedIn, accountsEnabled }: { signedIn: boolean; accountsEnabled: boolean }) {
  const sp = useSearchParams();
  const [birth, setBirth] = useState<BirthValue>(emptyBirth);
  const [ayanamsa, setAyanamsa] = useState("lahiri");
  const [node, setNode] = useState("mean");
  const [style, setStyle] = useState<"north" | "south">("north");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [tab, setTab] = useState<Tab>("chart");
  const [saveMsg, setSaveMsg] = useState("");

  const submit = async (b = birth) => {
    setError(""); setBusy(true); setSaveMsg("");
    try {
      const r = await fetch("/api/kundli", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(toBirthPayload(b, { ayanamsa, node })) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Calculation failed");
      setResult(j); setTab("chart");
      requestAnimationFrame(() => document.getElementById("kundli-result")?.scrollIntoView({ behavior: "smooth" }));
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };

  // Prefill from URL (homepage quick form, shared links)
  useEffect(() => {
    const date = sp.get("date"), time = sp.get("time"), lat = sp.get("lat"), lon = sp.get("lon"), tz = sp.get("tz");
    if (date && time && lat && lon && tz) {
      const b: BirthValue = { name: sp.get("name") ?? "", date, time, gender: "", place: { name: sp.get("place") ?? "Birthplace", lat: +lat, lon: +lon, tz } };
      setBirth(b);
      if (sp.get("go")) submit(b);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const share = async () => {
    if (!birth.place) return;
    const qs = new URLSearchParams({ name: birth.name, date: birth.date, time: birth.time, lat: String(birth.place.lat), lon: String(birth.place.lon), tz: birth.place.tz, place: birth.place.name, go: "1" });
    const url = `${location.origin}/kundli?${qs}`;
    if (navigator.share) await navigator.share({ title: `Kundli${birth.name ? ` — ${birth.name}` : ""}`, url }).catch(() => {});
    else { await navigator.clipboard.writeText(url); setSaveMsg("Link copied. Anyone with the link can see these birth details."); }
  };

  const save = async () => {
    setSaveMsg("Saving…");
    const r = await fetch("/api/kundlis", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ birth: toBirthPayload(birth, { ayanamsa, node }) }) });
    const j = await r.json().catch(() => ({}));
    setSaveMsg(r.ok ? "Saved to your account." : j.error || "Could not save.");
  };

  return (
    <div className="container py-10">
      <form className="leaf no-print grid gap-6 p-5 md:p-7 lg:grid-cols-[1.6fr_1fr]" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <BirthFields idPrefix="k" value={birth} onChange={setBirth} />
        <div className="space-y-3">
          <div>
            <label className="label" htmlFor="ayan">Ayanamsa</label>
            <select id="ayan" className="input" value={ayanamsa} onChange={(e) => setAyanamsa(e.target.value)}>
              <option value="lahiri">Lahiri (Chitrapaksha) — default</option><option value="raman">B.V. Raman</option><option value="krishnamurti">Krishnamurti (KP)</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="node">Rahu / Ketu</label>
            <select id="node" className="input" value={node} onChange={(e) => setNode(e.target.value)}>
              <option value="mean">Mean node</option><option value="true">True node</option>
            </select>
          </div>
          <div>
            <span className="label">Chart style</span>
            <div className="flex gap-2" role="radiogroup" aria-label="Chart style">
              {(["north", "south"] as const).map((s) => (
                <button key={s} type="button" role="radio" aria-checked={style === s} onClick={() => setStyle(s)}
                  className={`btn flex-1 border ${style === s ? "border-maroon bg-maroon text-ivory" : "border-ink/15 text-ink-soft"}`}>{s === "north" ? "North Indian" : "South Indian"}</button>
              ))}
            </div>
          </div>
          <button className="btn-primary w-full" disabled={busy}>{busy ? "Calculating…" : "Generate Kundli"}</button>
          {error && <p role="alert" className="text-sm text-maroon">{error}</p>}
        </div>
      </form>

      {result && (
        <section id="kundli-result" className="mt-10 scroll-mt-28" aria-live="polite">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-4xl font-bold text-maroon">{result.meta.name || "Birth chart"}</h2>
              <p className="text-ink-soft">
                {new Date(result.meta.birth.date + "T00:00").toLocaleDateString("en-IN", { dateStyle: "long" })}, {result.meta.birth.time} · {result.meta.birth.place} ({result.meta.birth.tz})
              </p>
            </div>
            <div className="no-print flex flex-wrap gap-2">
              <button className="btn-ghost !py-2" onClick={() => window.print()}>Download PDF</button>
              <button className="btn-ghost !py-2" onClick={share}>Share</button>
              {accountsEnabled && (signedIn
                ? <button className="btn-primary !py-2" onClick={save}>Save</button>
                : <a className="btn-primary !py-2" href="/login?next=/kundli">Sign in to save</a>)}
            </div>
          </div>
          {saveMsg && <p className="mt-2 text-sm text-emerald-800" role="status">{saveMsg}</p>}

          <dl className="mt-6 grid grid-cols-2 gap-4 rounded-2xl bg-midnight p-5 text-ivory sm:grid-cols-4">
            {[["Lagna", `${result.summary.lagna} ${fmtDeg(result.ascendant.degree)}`], ["Rashi (Moon sign)", result.summary.rashi], ["Janma Nakshatra", result.summary.nakshatra], ["Running Dasha", result.dasha.current ? `${result.dasha.current.mahadasha} / ${result.dasha.current.antardasha}` : "—"]].map(([k, v]) => (
              <div key={k}><dt className="text-xs text-ivory/60">{k}</dt><dd className="font-display text-xl font-semibold text-gold-pale">{v}</dd></div>
            ))}
          </dl>

          <div className="no-print mt-6 flex gap-1 overflow-x-auto border-b border-gold/30" role="tablist">
            {([["chart", "Charts"], ["planets", "Planets"], ["vargas", "Divisional"], ["dasha", "Dasha"], ["yogas", "Yogas & Doshas"], ["reports", "Life reports"], ["transits", "Transits"]] as [Tab, string][]).map(([id, label]) => (
              <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
                className={`whitespace-nowrap border-b-2 px-4 py-2.5 text-[15px] ${tab === id ? "border-saffron font-medium text-maroon" : "border-transparent text-ink-soft hover:text-maroon"}`}>{label}</button>
            ))}
          </div>

          <div className="mt-6" role="tabpanel">
            {(tab === "chart") && <ChartsTab k={result} style={style} />}
            {tab === "planets" && <PlanetsTab k={result} />}
            {tab === "vargas" && <VargasTab k={result} style={style} />}
            {tab === "dasha" && <DashaTab k={result} />}
            {tab === "yogas" && <YogasTab k={result} />}
            {tab === "reports" && <ReportsTab k={result} />}
            {tab === "transits" && <TransitsTab k={result} />}
          </div>

          {/* Print: everything on paper regardless of tab */}
          <div className="hidden print:block">
            <div className="print-break"><PlanetsTab k={result} /></div>
            <div className="print-break"><DashaTab k={result} /></div>
            <div className="print-break"><YogasTab k={result} /></div>
            <div className="print-break"><ReportsTab k={result} /></div>
          </div>

          <p className="mt-8 text-xs text-ink-faint">
            {result.meta.engine} · {result.meta.ayanamsa} ayanamsa {result.meta.ayanamsaValue.toFixed(4)}° · {result.meta.node} node · {result.meta.houseSystem} houses · birth instant {result.meta.birth.utc} UTC · {result.meta.birth.lat.toFixed(4)}, {result.meta.birth.lon.toFixed(4)}
          </p>
        </section>
      )}
    </div>
  );
}

function Chart({ style, ascSign, placements, title }: { style: "north" | "south"; ascSign: number; placements: ReturnType<typeof placementsFrom>; title: string }) {
  return style === "north" ? <NorthChart ascSign={ascSign} placements={placements} title={title} /> : <SouthChart ascSign={ascSign} placements={placements} title={title} />;
}

function ChartsTab({ k, style }: { k: Result; style: "north" | "south" }) {
  const d9 = k.divisional.D9;
  const d10 = k.divisional.D10;
  const vp = (v: typeof d9) => placementsFrom(k.planets.map((p) => ({ planet: p.planet, sign: v.planets[p.planet] })), v.ascendant);
  return (
    <div className="grid gap-8 md:grid-cols-3">
      {[["Rashi (D1)", k.ascendant.sign, placementsFrom(k.planets, k.ascendant.sign)], ["Navamsa (D9)", d9.ascendant, vp(d9)], ["Dashamsa (D10)", d10.ascendant, vp(d10)]].map(([t, a, p]) => (
        <figure key={t as string} className="leaf p-4">
          <figcaption className="mb-2 font-display text-xl font-semibold text-maroon">{t as string}</figcaption>
          <Chart style={style} ascSign={a as number} placements={p as ReturnType<typeof placementsFrom>} title={t as string} />
        </figure>
      ))}
      <div className="md:col-span-3">
        <h3 className="font-display text-2xl font-semibold text-maroon">Houses</h3>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[560px] text-[15px]">
            <thead><tr className="border-b border-gold/30 text-left text-ink-faint"><th className="py-2 font-normal">House</th><th className="font-normal">Sign</th><th className="font-normal">Lord</th><th className="font-normal">Lord placed in</th><th className="font-normal">Occupants</th></tr></thead>
            <tbody>{k.houses.map((h) => (
              <tr key={h.house} className="border-b border-gold/10"><td className="py-2">{h.house}</td><td>{h.signName}</td><td>{h.lord}</td><td>House {h.lordHouse}</td><td>{h.occupants.join(", ") || "—"}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function PlanetsTab({ k }: { k: Result }) {
  return (
    <div className="space-y-8">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-[15px]">
          <caption className="mb-2 text-left font-display text-2xl font-semibold text-maroon">Planetary positions</caption>
          <thead><tr className="border-b border-gold/30 text-left text-ink-faint">{["Planet", "Sign", "Degree", "Nakshatra", "Pada", "House", "Dignity", "Status"].map((h) => <th key={h} className="py-2 font-normal">{h}</th>)}</tr></thead>
          <tbody>
            <tr className="border-b border-gold/10 font-medium"><td className="py-2">Ascendant</td><td>{k.ascendant.signName}</td><td className="tabular-nums">{fmtDeg(k.ascendant.degree)}</td><td>{k.ascendant.nakshatra}</td><td>{k.ascendant.pada}</td><td>1</td><td>—</td><td /></tr>
            {k.planets.map((p) => (
              <tr key={p.planet} className="border-b border-gold/10">
                <td className="py-2 font-medium">{p.planet}</td><td>{p.signName}</td><td className="tabular-nums">{fmtDeg(p.degree)}</td>
                <td>{p.nakshatra} <span className="text-xs text-ink-faint">({p.nakshatraLord})</span></td><td>{p.pada}</td><td>{p.house}</td>
                <td className={p.dignity === "Exalted" || p.dignity === "Own sign" || p.dignity === "Moolatrikona" ? "text-emerald-800" : p.dignity === "Debilitated" ? "text-maroon" : ""}>{p.dignity}</td>
                <td className="text-sm">{[p.retrograde && !["Rahu", "Ketu"].includes(p.planet) && "Retrograde", p.combust && "Combust"].filter(Boolean).join(", ") || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="leaf p-5">
          <h3 className="font-display text-xl font-semibold text-maroon">Aspects (Graha Drishti)</h3>
          <ul className="mt-2 space-y-1 text-[15px]">{k.aspects.map((a) => <li key={a.planet}><strong>{a.planet}</strong> aspects houses {a.houses.join(", ")}{a.planetsAspected.length ? ` — ${a.planetsAspected.join(", ")}` : ""}</li>)}</ul>
        </div>
        <div className="leaf p-5">
          <h3 className="font-display text-xl font-semibold text-maroon">Conjunctions</h3>
          {k.conjunctions.length ? <ul className="mt-2 space-y-1 text-[15px]">{k.conjunctions.map((c) => <li key={c.house}>House {c.house} ({c.sign}): {c.planets.join(", ")}</li>)}</ul> : <p className="mt-2 text-ink-soft">No two planets share a sign.</p>}
        </div>
      </div>
    </div>
  );
}

function VargasTab({ k, style }: { k: Result; style: "north" | "south" }) {
  const keys = Object.keys(k.divisional);
  const [sel, setSel] = useState("D9");
  const v = k.divisional[sel];
  return (
    <div className="grid gap-8 md:grid-cols-[1fr_1.2fr]">
      <div>
        <label className="label" htmlFor="varga">Divisional chart</label>
        <select id="varga" className="input" value={sel} onChange={(e) => setSel(e.target.value)}>
          {keys.map((key) => <option key={key} value={key}>{key} — {k.divisional[key].name} ({k.divisional[key].area})</option>)}
        </select>
        <div className="mt-4"><Chart style={style} ascSign={v.ascendant} placements={placementsFrom(k.planets.map((p) => ({ planet: p.planet, sign: v.planets[p.planet] })), v.ascendant)} title={`${sel} ${v.name}`} /></div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[520px] text-sm">
          <caption className="mb-2 text-left font-display text-xl font-semibold text-maroon">Sign of each planet across vargas</caption>
          <thead><tr className="border-b border-gold/30 text-left text-ink-faint"><th className="py-1 font-normal">Varga</th><th className="font-normal">Asc</th>{k.planets.map((p) => <th key={p.planet} className="font-normal">{p.planet.slice(0, 2)}</th>)}</tr></thead>
          <tbody>{keys.map((key) => (
            <tr key={key} className={`border-b border-gold/10 ${key === sel ? "bg-gold-pale/40" : ""}`}><td className="py-1 font-medium">{key}</td><td>{RASHIS[k.divisional[key].ascendant].en.slice(0, 3)}</td>{k.planets.map((p) => <td key={p.planet}>{RASHIS[k.divisional[key].planets[p.planet]].en.slice(0, 3)}</td>)}</tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

function DashaTab({ k }: { k: Result }) {
  const [open, setOpen] = useState<string | null>(k.dasha.current?.mahadasha ?? null);
  const now = Date.now();
  const live = (s: string, e: string) => now >= Date.parse(s) && now < Date.parse(e);
  return (
    <div>
      <h3 className="font-display text-2xl font-semibold text-maroon">Vimshottari Dasha</h3>
      <p className="text-ink-soft">Birth nakshatra {k.dasha.birthNakshatra}; balance of {k.dasha.balance.lord} Mahadasha at birth: {k.dasha.balance.years.toFixed(2)} years. Year = {k.dasha.yearDays} days.</p>
      <ol className="mt-4 space-y-2">
        {k.dasha.mahadashas.map((md) => (
          <li key={md.lord + md.start} className={`rounded-xl border ${live(md.start, md.end) ? "border-saffron bg-saffron/5" : "border-gold/25 bg-white/60"}`}>
            <button className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left" aria-expanded={open === md.lord} onClick={() => setOpen(open === md.lord ? null : md.lord)}>
              <span><strong className="text-maroon">{md.lord}</strong> Mahadasha <span className="text-sm text-ink-faint">({VIMSHOTTARI_YEARS[md.lord as Planet]} yrs)</span>{live(md.start, md.end) && <span className="ml-2 rounded bg-saffron px-1.5 text-xs text-white">running</span>}</span>
              <span className="text-sm tabular-nums text-ink-soft">{fmtD(md.start)} – {fmtD(md.end)}</span>
            </button>
            {open === md.lord && md.sub && (
              <ul className="border-t border-gold/20 px-4 py-2 text-[15px]">
                {md.sub.map((ad) => (
                  <li key={ad.start} className={`py-1.5 ${live(ad.start, ad.end) ? "font-semibold text-maroon" : ""}`}>
                    <div className="flex justify-between"><span>{md.lord} – {ad.lord}</span><span className="tabular-nums text-ink-soft">{fmtD(ad.start)} – {fmtD(ad.end)}</span></div>
                    {ad.sub && live(ad.start, ad.end) && (
                      <ul className="ml-4 mt-1 border-l border-gold/30 pl-3 text-sm font-normal text-ink-soft">
                        {ad.sub.map((pd) => <li key={pd.start} className={`flex justify-between ${live(pd.start, pd.end) ? "text-saffron-dark" : ""}`}><span>Pratyantar {pd.lord}</span><span className="tabular-nums">{fmtD(pd.start)} – {fmtD(pd.end)}</span></li>)}
                      </ul>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ol>
    </div>
  );
}

function YogasTab({ k }: { k: Result }) {
  const m = k.doshas.manglik, ks = k.doshas.kaalSarp, ss = k.sadeSati;
  return (
    <div className="space-y-8">
      <div className="grid gap-6 md:grid-cols-3">
        <div className="leaf p-5">
          <h3 className="font-display text-xl font-semibold text-maroon">Manglik Dosha</h3>
          <p className={`mt-1 font-semibold ${m.present ? "text-maroon" : "text-emerald-800"}`}>{m.present ? `Present (${m.severity})` : "Not present"}</p>
          <ul className="mt-2 text-sm text-ink-soft">
            <li>Mars from Lagna: house {m.fromLagna.house}{m.fromLagna.present ? " ✓" : ""}</li>
            <li>Mars from Moon: house {m.fromMoon.house}{m.fromMoon.present ? " ✓" : ""}</li>
            <li>Mars from Venus: house {m.fromVenus.house}{m.fromVenus.present ? " ✓" : ""}</li>
          </ul>
          {m.mitigations.length > 0 && <p className="mt-2 text-sm">Mitigating factors: {m.mitigations.join("; ")}.</p>}
          <p className="mt-2 text-xs text-ink-faint">{m.rule}</p>
        </div>
        <div className="leaf p-5">
          <h3 className="font-display text-xl font-semibold text-maroon">Kaal Sarp Dosha</h3>
          <p className={`mt-1 font-semibold ${ks.present ? "text-maroon" : "text-emerald-800"}`}>{ks.present ? `${ks.type} Kaal Sarp — ${ks.direction}` : "Not present"}</p>
          <p className="mt-2 text-xs text-ink-faint">{ks.rule}</p>
        </div>
        <div className="leaf p-5">
          <h3 className="font-display text-xl font-semibold text-maroon">Sade Sati</h3>
          <p className={`mt-1 font-semibold ${ss.current.active ? "text-maroon" : "text-emerald-800"}`}>{ss.current.active ? `Running — ${ss.current.phase}` : "Not running now"}</p>
          <p className="mt-1 text-sm text-ink-soft">Saturn is transiting {ss.current.saturnSign}.{ss.current.dhaiya ? ` Dhaiya: ${ss.current.dhaiya}.` : ""}</p>
        </div>
      </div>

      <div>
        <h3 className="font-display text-2xl font-semibold text-maroon">Yogas</h3>
        <ul className="mt-3 grid gap-3 md:grid-cols-2">
          {k.yogas.map((y) => (
            <li key={y.name} className={`rounded-xl border p-4 ${y.present ? "border-emerald-700/30 bg-emerald-50/50" : "border-gold/20 bg-white/50"}`}>
              <p className="font-medium">{y.name} <span className={`ml-1 text-sm ${y.present ? "text-emerald-800" : "text-ink-faint"}`}>{y.present ? "present" : "absent"}</span></p>
              <p className="text-sm text-ink-soft">{y.reason}</p>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3 className="font-display text-2xl font-semibold text-maroon">Sade Sati periods in this lifetime</h3>
        <ol className="mt-3 space-y-3">
          {ss.cycles.map((c, i) => (
            <li key={i} className="rounded-xl border border-gold/25 bg-white/60 p-4">
              <p className="font-medium">Cycle {i + 1}: {fmtD(c.start)} – {fmtD(c.end)}</p>
              <ul className="mt-1 text-sm text-ink-soft">{c.segments.map((s, j) => <li key={j}>{s.phase}, Saturn in {s.sign}: {fmtD(s.start)} – {fmtD(s.end)}</li>)}</ul>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

function ReportsTab({ k }: { k: Result }) {
  const i = k.interpretation;
  return (
    <div className="space-y-6">
      <p className="text-lg text-ink">{i.lagna}</p>
      {i.periods.length > 0 && <div className="rounded-xl bg-midnight p-5 text-ivory"><h3 className="font-display text-xl font-semibold text-gold-pale">Important planetary periods</h3>{i.periods.map((p) => <p key={p} className="mt-2 text-ivory/85">{p}</p>)}</div>}
      <div className="grid gap-5 md:grid-cols-2">
        {i.areas.map((a) => (
          <article key={a.id} className="leaf p-5">
            <h3 className="font-display text-2xl font-semibold text-maroon">{a.title}</h3>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-[15px] text-ink-soft">{a.points.map((p) => <li key={p}>{p}</li>)}</ul>
            {a.disclaimer && <p className="mt-3 text-xs text-maroon">{a.disclaimer}</p>}
          </article>
        ))}
      </div>
      <p className="text-sm text-ink-faint">{i.disclaimer}</p>
    </div>
  );
}

function TransitsTab({ k }: { k: Result }) {
  const moon = k.planets.find((p) => p.planet === "Moon")!.sign;
  const [rows, setRows] = useState<{ planet: string; signName: string; degree: number; retrograde: boolean; houseFromMoon: number; houseFromLagna: number; nextSignChange: string | null }[] | null>(null);
  useEffect(() => { fetch(`/api/transits?moon=${moon}&lagna=${k.ascendant.sign}`).then((r) => r.json()).then((j) => setRows(j.transits)); }, [moon, k.ascendant.sign]);
  const natal = useMemo(() => Object.fromEntries(k.planets.map((p) => [p.planet, p.signName])), [k.planets]);
  if (!rows) return <p className="text-ink-soft">Loading current transits…</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-[15px]">
        <caption className="mb-2 text-left font-display text-2xl font-semibold text-maroon">Gochar — planets today against your chart</caption>
        <thead><tr className="border-b border-gold/30 text-left text-ink-faint">{["Planet", "Transit sign", "Natal sign", "From Moon", "From Lagna", "Next sign change"].map((h) => <th key={h} className="py-2 font-normal">{h}</th>)}</tr></thead>
        <tbody>{rows.map((r) => (
          <tr key={r.planet} className="border-b border-gold/10">
            <td className="py-2 font-medium">{r.planet}{r.retrograde && !["Rahu", "Ketu"].includes(r.planet) ? " (R)" : ""}</td>
            <td>{r.signName} {fmtDeg(r.degree)}</td><td>{natal[r.planet]}</td><td>{r.houseFromMoon}</td><td>{r.houseFromLagna}</td>
            <td className="tabular-nums text-ink-soft">{r.nextSignChange ? fmtD(r.nextSignChange) : "—"}</td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}
