import { cookies } from "next/headers";
import { resolveLocation } from "./location";

export function getLang(): "en" | "hi" {
  return cookies().get("lang")?.value === "hi" ? "hi" : "en";
}
export function getLocation(searchParams: Record<string, string | string[] | undefined> = {}) {
  return resolveLocation(searchParams, cookies().get("loc")?.value);
}
