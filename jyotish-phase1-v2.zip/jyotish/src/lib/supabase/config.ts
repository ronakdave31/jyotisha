export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
/** Accounts and saving are disabled (tools still work) until Supabase env vars are set. */
export const supabaseEnabled = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
