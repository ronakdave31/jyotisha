export const SITE = {
  name: process.env.NEXT_PUBLIC_SITE_NAME || "Jyotisha",
  tagline: "Vedic astrology, Panchang and Kundli — calculated, not copied",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, ""),
  publisher: "Krayon Medias",
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "hello@krayonmedias.com",
};

export interface NavItem { href: string; label: string; children?: { href: string; label: string; hint: string }[] }

export const NAV: NavItem[] = [
  { href: "/", label: "Home" },
  { href: "/panchang", label: "Daily Panchang" },
  { href: "/kundli", label: "Kundli" },
  { href: "/muhurat", label: "Muhurat" },
  { href: "/astrology", label: "Astrology" },
  { href: "/numerology", label: "Numerology" },
  {
    href: "/mantras", label: "Mantras", children: [
      { href: "/mantras", label: "Mantras", hint: "Recite along, with a mala counter" },
      { href: "/shlokas", label: "Shlokas", hint: "Gita, Upanishads and Vedas with meaning" },
      { href: "/vedas", label: "Vedas", hint: "The four Vedas, Vedangas and Upanishads" },
      { href: "/karmkand", label: "Karmakand", hint: "The sixteen samskaras and daily karma" },
      { href: "/vidhi", label: "Puja vidhi", hint: "Step-by-step pujas with samagri lists" },
    ],
  },
  { href: "/blog", label: "Blogs" },
  { href: "/festivals", label: "Festivals" },
];

export const DISCLAIMER =
  "Astrology, Panchang interpretations and numerology are traditional belief systems. Calculations are astronomical; readings are cultural guidance, not guaranteed predictions or professional (medical, legal, financial) advice.";
