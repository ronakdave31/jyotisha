/**
 * Curated city list for instant selection and SEO landing pages (/panchang/[city]).
 * Any other place is resolved through /api/geocode (OpenStreetMap Nominatim),
 * with the IANA zone derived offline from coordinates.
 */
export interface City {
  slug: string;
  name: string;
  state: string;
  country: string;
  lat: number;
  lon: number;
  tz: string;
  featured?: boolean;
}

const IN = (slug: string, name: string, state: string, lat: number, lon: number, featured = false): City => ({
  slug, name, state, country: "India", lat, lon, tz: "Asia/Kolkata", featured,
});

export const CITIES: City[] = [
  IN("new-delhi", "New Delhi", "Delhi", 28.6139, 77.209, true),
  IN("mumbai", "Mumbai", "Maharashtra", 19.076, 72.8777, true),
  IN("bengaluru", "Bengaluru", "Karnataka", 12.9716, 77.5946, true),
  IN("kolkata", "Kolkata", "West Bengal", 22.5726, 88.3639, true),
  IN("chennai", "Chennai", "Tamil Nadu", 13.0827, 80.2707, true),
  IN("hyderabad", "Hyderabad", "Telangana", 17.385, 78.4867, true),
  IN("ahmedabad", "Ahmedabad", "Gujarat", 23.0225, 72.5714, true),
  IN("pune", "Pune", "Maharashtra", 18.5204, 73.8567, true),
  IN("jaipur", "Jaipur", "Rajasthan", 26.9124, 75.7873, true),
  IN("varanasi", "Varanasi", "Uttar Pradesh", 25.3176, 82.9739, true),
  IN("ujjain", "Ujjain", "Madhya Pradesh", 23.1765, 75.7885, true),
  IN("lucknow", "Lucknow", "Uttar Pradesh", 26.8467, 80.9462, true),
  IN("surat", "Surat", "Gujarat", 21.1702, 72.8311),
  IN("vadodara", "Vadodara", "Gujarat", 22.3072, 73.1812),
  IN("rajkot", "Rajkot", "Gujarat", 22.3039, 70.8022),
  IN("dwarka", "Dwarka", "Gujarat", 22.2394, 68.9678),
  IN("nagpur", "Nagpur", "Maharashtra", 21.1458, 79.0882),
  IN("nashik", "Nashik", "Maharashtra", 19.9975, 73.7898),
  IN("indore", "Indore", "Madhya Pradesh", 22.7196, 75.8577),
  IN("bhopal", "Bhopal", "Madhya Pradesh", 23.2599, 77.4126),
  IN("patna", "Patna", "Bihar", 25.5941, 85.1376),
  IN("gaya", "Gaya", "Bihar", 24.7914, 85.0002),
  IN("ranchi", "Ranchi", "Jharkhand", 23.3441, 85.3096),
  IN("bhubaneswar", "Bhubaneswar", "Odisha", 20.2961, 85.8245),
  IN("puri", "Puri", "Odisha", 19.8135, 85.8312),
  IN("guwahati", "Guwahati", "Assam", 26.1445, 91.7362),
  IN("chandigarh", "Chandigarh", "Chandigarh", 30.7333, 76.7794),
  IN("amritsar", "Amritsar", "Punjab", 31.634, 74.8723),
  IN("dehradun", "Dehradun", "Uttarakhand", 30.3165, 78.0322),
  IN("haridwar", "Haridwar", "Uttarakhand", 29.9457, 78.1642),
  IN("rishikesh", "Rishikesh", "Uttarakhand", 30.0869, 78.2676),
  IN("prayagraj", "Prayagraj", "Uttar Pradesh", 25.4358, 81.8463),
  IN("ayodhya", "Ayodhya", "Uttar Pradesh", 26.7922, 82.1998),
  IN("mathura", "Mathura", "Uttar Pradesh", 27.4924, 77.6737),
  IN("agra", "Agra", "Uttar Pradesh", 27.1767, 78.0081),
  IN("kanpur", "Kanpur", "Uttar Pradesh", 26.4499, 80.3319),
  IN("jodhpur", "Jodhpur", "Rajasthan", 26.2389, 73.0243),
  IN("udaipur", "Udaipur", "Rajasthan", 24.5854, 73.7125),
  IN("kochi", "Kochi", "Kerala", 9.9312, 76.2673),
  IN("thiruvananthapuram", "Thiruvananthapuram", "Kerala", 8.5241, 76.9366),
  IN("madurai", "Madurai", "Tamil Nadu", 9.9252, 78.1198),
  IN("coimbatore", "Coimbatore", "Tamil Nadu", 11.0168, 76.9558),
  IN("tirupati", "Tirupati", "Andhra Pradesh", 13.6288, 79.4192),
  IN("visakhapatnam", "Visakhapatnam", "Andhra Pradesh", 17.6868, 83.2185),
  IN("vijayawada", "Vijayawada", "Andhra Pradesh", 16.5062, 80.648),
  IN("mysuru", "Mysuru", "Karnataka", 12.2958, 76.6394),
  IN("mangaluru", "Mangaluru", "Karnataka", 12.9141, 74.856),
  IN("goa-panaji", "Panaji", "Goa", 15.4909, 73.8278),
  IN("raipur", "Raipur", "Chhattisgarh", 21.2514, 81.6296),
  IN("jammu", "Jammu", "Jammu and Kashmir", 32.7266, 74.857),
  IN("srinagar", "Srinagar", "Jammu and Kashmir", 34.0837, 74.7973),
  { slug: "kathmandu", name: "Kathmandu", state: "Bagmati", country: "Nepal", lat: 27.7172, lon: 85.324, tz: "Asia/Kathmandu" },
  { slug: "dubai", name: "Dubai", state: "Dubai", country: "UAE", lat: 25.2048, lon: 55.2708, tz: "Asia/Dubai" },
  { slug: "singapore", name: "Singapore", state: "", country: "Singapore", lat: 1.3521, lon: 103.8198, tz: "Asia/Singapore" },
  { slug: "london", name: "London", state: "England", country: "UK", lat: 51.5074, lon: -0.1278, tz: "Europe/London" },
  { slug: "new-york", name: "New York", state: "NY", country: "USA", lat: 40.7128, lon: -74.006, tz: "America/New_York" },
  { slug: "san-francisco", name: "San Francisco", state: "CA", country: "USA", lat: 37.7749, lon: -122.4194, tz: "America/Los_Angeles" },
  { slug: "toronto", name: "Toronto", state: "ON", country: "Canada", lat: 43.6532, lon: -79.3832, tz: "America/Toronto" },
  { slug: "sydney", name: "Sydney", state: "NSW", country: "Australia", lat: -33.8688, lon: 151.2093, tz: "Australia/Sydney" },
];

export const DEFAULT_CITY = CITIES[0];

export function findCity(slug: string | undefined | null) {
  return CITIES.find((c) => c.slug === slug);
}

export function searchCities(q: string, limit = 8) {
  const s = q.trim().toLowerCase();
  if (!s) return CITIES.filter((c) => c.featured).slice(0, limit);
  return CITIES.filter((c) => c.name.toLowerCase().includes(s) || c.state.toLowerCase().includes(s)).slice(0, limit);
}
