/**
 * Numerology — Pythagorean and Chaldean systems with full calculation breakdowns.
 * Planetary rulerships follow the Indian (Cheiro/Chaldean) convention.
 */

export type NumSystem = "pythagorean" | "chaldean";

const PYTHAGOREAN: Record<string, number> = Object.fromEntries(
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map((c, i) => [c, (i % 9) + 1]),
);
const CHALDEAN: Record<string, number> = {
  A: 1, I: 1, J: 1, Q: 1, Y: 1, B: 2, K: 2, R: 2, C: 3, G: 3, L: 3, S: 3, D: 4, M: 4, T: 4,
  E: 5, H: 5, N: 5, X: 5, U: 6, V: 6, W: 6, O: 7, Z: 7, F: 8, P: 8,
};
const VOWELS = new Set(["A", "E", "I", "O", "U"]);
const MASTER = new Set([11, 22, 33]);

export function reduce(n: number, keepMaster = true): number {
  while (n > 9 && !(keepMaster && MASTER.has(n))) n = String(n).split("").reduce((s, d) => s + Number(d), 0);
  return n;
}

function letters(name: string) {
  return name.toUpperCase().replace(/[^A-Z]/g, "").split("");
}

function nameSum(name: string, system: NumSystem, filter?: (c: string) => boolean) {
  const table = system === "chaldean" ? CHALDEAN : PYTHAGOREAN;
  const parts = letters(name).filter((c) => (filter ? filter(c) : true)).map((c) => ({ letter: c, value: table[c] }));
  const total = parts.reduce((s, p) => s + p.value, 0);
  return { parts, total, reduced: system === "chaldean" ? reduce(total, false) : reduce(total) };
}

export const NUMBER_INFO: Record<number, { planet: string; colors: string[]; days: string[]; traits: string; gem: string }> = {
  1: { planet: "Sun", colors: ["Gold", "Orange", "Yellow"], days: ["Sunday"], gem: "Ruby", traits: "Leadership, independence, originality and drive. Natural initiators who prefer to set their own direction." },
  2: { planet: "Moon", colors: ["White", "Cream", "Light green"], days: ["Monday"], gem: "Pearl", traits: "Sensitivity, diplomacy and imagination. Cooperative partners who read people and situations well." },
  3: { planet: "Jupiter", colors: ["Yellow", "Purple", "Pink"], days: ["Thursday"], gem: "Yellow sapphire", traits: "Expression, wisdom and optimism. Teachers and communicators drawn to growth and learning." },
  4: { planet: "Rahu", colors: ["Electric blue", "Grey"], days: ["Saturday", "Sunday"], gem: "Hessonite", traits: "Structure, persistence and unconventional thinking. Builders who question the established way." },
  5: { planet: "Mercury", colors: ["Green", "Light grey"], days: ["Wednesday"], gem: "Emerald", traits: "Versatility, wit and adaptability. Quick learners who thrive on variety, travel and trade." },
  6: { planet: "Venus", colors: ["Blue", "Pink", "White"], days: ["Friday"], gem: "Diamond", traits: "Harmony, beauty and responsibility. Nurturers with an eye for art, comfort and relationships." },
  7: { planet: "Ketu", colors: ["Green", "Smoke grey"], days: ["Monday", "Thursday"], gem: "Cat's eye", traits: "Introspection, intuition and research. Seekers drawn to spirituality and deeper truths." },
  8: { planet: "Saturn", colors: ["Dark blue", "Black", "Purple"], days: ["Saturday"], gem: "Blue sapphire", traits: "Discipline, endurance and ambition. Slow, steady builders whose results grow with time." },
  9: { planet: "Mars", colors: ["Red", "Crimson", "Pink"], days: ["Tuesday"], gem: "Red coral", traits: "Energy, courage and compassion. Humanitarian fighters who finish what they start." },
  11: { planet: "Moon (master)", colors: ["Silver", "White"], days: ["Monday"], gem: "Pearl", traits: "Master number: heightened intuition and inspiration; carries the qualities of 2 at a higher intensity." },
  22: { planet: "Rahu (master)", colors: ["Coral", "Gold"], days: ["Sunday"], gem: "Hessonite", traits: "Master builder: turns large visions into practical form; carries the qualities of 4 at a higher intensity." },
  33: { planet: "Jupiter (master)", colors: ["Gold", "Yellow"], days: ["Thursday"], gem: "Yellow sapphire", traits: "Master teacher: service and compassion; carries the qualities of 6 at a higher intensity." },
};

const FRIENDLY: Record<number, number[]> = {
  1: [1, 2, 3, 9], 2: [1, 2, 7], 3: [1, 3, 6, 9], 4: [1, 5, 6, 8], 5: [1, 4, 5, 6], 6: [3, 4, 5, 6, 9], 7: [1, 2, 7], 8: [4, 5, 6, 8], 9: [1, 3, 6, 9],
};

export function numerologyReport(fullName: string, dob: string, system: NumSystem = "pythagorean", asOfYear = new Date().getFullYear()) {
  const [y, m, d] = dob.split("-").map(Number);
  if (!y || !m || !d) throw new Error("Date of birth must be YYYY-MM-DD");

  const birthNumber = reduce(d, false);
  const lifePathSteps = [reduce(m), reduce(d), reduce(String(y).split("").reduce((s, c) => s + +c, 0))];
  const lifePath = reduce(lifePathSteps.reduce((a, b) => a + b, 0));
  const expression = nameSum(fullName, system);
  const soul = nameSum(fullName, system, (c) => VOWELS.has(c));
  const personality = nameSum(fullName, system, (c) => !VOWELS.has(c));
  const personalYear = reduce(reduce(d) + reduce(m) + reduce(String(asOfYear).split("").reduce((s, c) => s + +c, 0)), false);

  const base = (n: number) => (n > 9 ? reduce(n, false) : n);
  const info = NUMBER_INFO[birthNumber];
  const luckyNumbers = [...new Set([birthNumber, base(lifePath), ...(FRIENDLY[birthNumber] ?? [])])].sort((a, b) => a - b);

  return {
    system,
    input: { fullName, dob },
    birthNumber: { value: birthNumber, calc: `Day ${d} → ${birthNumber}`, ...NUMBER_INFO[birthNumber] },
    lifePath: { value: lifePath, calc: `Month ${m}→${lifePathSteps[0]}, Day ${d}→${lifePathSteps[1]}, Year ${y}→${lifePathSteps[2]}; sum → ${lifePath}`, ...NUMBER_INFO[lifePath] },
    expression: { value: expression.reduced, total: expression.total, letters: expression.parts, ...NUMBER_INFO[expression.reduced] },
    soulUrge: { value: soul.reduced, total: soul.total, ...NUMBER_INFO[soul.reduced] },
    personality: { value: personality.reduced, total: personality.total, ...NUMBER_INFO[personality.reduced] },
    personalYear: { value: personalYear, year: asOfYear },
    lucky: { numbers: luckyNumbers, colors: info.colors, days: info.days, gem: info.gem },
  };
}

export function nameNumber(name: string, system: NumSystem = "chaldean") {
  const r = nameSum(name, system);
  return { name, system, total: r.total, value: r.reduced, letters: r.parts, ...NUMBER_INFO[r.reduced] };
}

export function numerologyCompatibility(a: number, b: number) {
  const x = reduce(a, false), y = reduce(b, false);
  const friendly = (FRIENDLY[x] ?? []).includes(y) && (FRIENDLY[y] ?? []).includes(x);
  const oneWay = (FRIENDLY[x] ?? []).includes(y) || (FRIENDLY[y] ?? []).includes(x);
  return { a: x, b: y, level: friendly ? "Harmonious" : oneWay ? "Workable" : "Challenging" };
}
