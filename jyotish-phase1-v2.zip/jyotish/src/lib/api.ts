import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isValidZone } from "./astro/time";

// ---------------------------------------------------------------------------
// Rate limiting — in-memory token bucket per IP. Swap for Upstash/Redis in
// multi-instance production (see docs/DEPLOYMENT.md).
// ---------------------------------------------------------------------------
const buckets = new Map<string, { tokens: number; at: number }>();
export function rateLimit(req: NextRequest, perMinute = 60) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || req.ip || "local";
  const key = `${ip}:${req.nextUrl.pathname}`;
  const now = Date.now();
  const b = buckets.get(key) ?? { tokens: perMinute, at: now };
  b.tokens = Math.min(perMinute, b.tokens + ((now - b.at) / 60000) * perMinute);
  b.at = now;
  if (b.tokens < 1) {
    buckets.set(key, b);
    return NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429, headers: { "Retry-After": "60" } });
  }
  b.tokens -= 1;
  buckets.set(key, b);
  if (buckets.size > 10000) buckets.clear();
  return null;
}

// ---------------------------------------------------------------------------
// Calculation cache — LRU in memory. Results are deterministic for a given
// input, so caching is safe. Replace with Redis for horizontal scaling.
// ---------------------------------------------------------------------------
const cache = new Map<string, { v: unknown; exp: number }>();
export function cached<T>(key: string, ttlMs: number, fn: () => T): T {
  const hit = cache.get(key);
  if (hit && hit.exp > Date.now()) {
    cache.delete(key);
    cache.set(key, hit);
    return hit.v as T;
  }
  const v = fn();
  cache.set(key, { v, exp: Date.now() + ttlMs });
  if (cache.size > 500) cache.delete(cache.keys().next().value!);
  return v;
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------
export const zDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD").refine((s) => {
  const y = +s.slice(0, 4);
  return y >= 1800 && y <= 2200;
}, "Year must be between 1800 and 2200");
export const zTime = z.string().regex(/^\d{2}:\d{2}(:\d{2})?$/, "Use HH:mm");
export const zLat = z.coerce.number().min(-66.5, "Latitudes beyond the polar circles are not supported").max(66.5, "Latitudes beyond the polar circles are not supported");
export const zLon = z.coerce.number().min(-180).max(180);
export const zTz = z.string().refine(isValidZone, "Unknown IANA time zone");
export const zAyanamsa = z.enum(["lahiri", "raman", "krishnamurti"]).default("lahiri");

export const zBirth = z.object({
  name: z.string().trim().max(80).optional(),
  date: zDate,
  time: zTime,
  tz: zTz,
  lat: zLat,
  lon: zLon,
  place: z.string().max(160).optional(),
  gender: z.enum(["male", "female", "other"]).optional(),
  ayanamsa: zAyanamsa.optional(),
  node: z.enum(["mean", "true"]).optional(),
});

export function bad(error: z.ZodError | string, status = 400) {
  const message = typeof error === "string" ? error : error.issues.map((i) => `${i.path.join(".") || "input"}: ${i.message}`).join("; ");
  return NextResponse.json({ error: message }, { status });
}

export function serverError(e: unknown) {
  const message = e instanceof Error ? e.message : "Calculation failed";
  console.error("[api]", e);
  return NextResponse.json({ error: message }, { status: 500 });
}
