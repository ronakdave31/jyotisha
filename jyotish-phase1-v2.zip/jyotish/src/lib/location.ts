import { DEFAULT_CITY, findCity } from "./cities";
import { isValidZone } from "./astro/time";

export interface Loc { name: string; lat: number; lon: number; tz: string; slug?: string }

/** Resolve a location from query params (?city= or ?lat&lon&tz&name) or the `loc` cookie, falling back to New Delhi. */
export function resolveLocation(params: Record<string, string | string[] | undefined>, cookieValue?: string): Loc {
  const p = (k: string) => (Array.isArray(params[k]) ? params[k]![0] : (params[k] as string | undefined));
  const city = findCity(p("city"));
  if (city) return { name: city.name, lat: city.lat, lon: city.lon, tz: city.tz, slug: city.slug };
  const lat = Number(p("lat")), lon = Number(p("lon")), tz = p("tz");
  if (Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 66.5 && Math.abs(lon) <= 180 && tz && isValidZone(tz)) {
    return { name: p("name") || `${lat.toFixed(2)}, ${lon.toFixed(2)}`, lat, lon, tz };
  }
  if (cookieValue) {
    try {
      const c = JSON.parse(cookieValue) as Loc;
      if (Number.isFinite(c.lat) && Number.isFinite(c.lon) && Math.abs(c.lat) <= 66.5 && isValidZone(c.tz)) return c;
    } catch { /* ignore malformed cookie */ }
  }
  return { name: DEFAULT_CITY.name, lat: DEFAULT_CITY.lat, lon: DEFAULT_CITY.lon, tz: DEFAULT_CITY.tz, slug: DEFAULT_CITY.slug };
}
