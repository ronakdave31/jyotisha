/**
 * Ashta Koota (Gun Milan) — North Indian 36-point system.
 * Every scoring table below is configuration data. Regional traditions differ
 * on Vashya, Gana and Yoni scoring, so these are exported for the admin
 * rules editor and are versioned in the database (table `matching_rules`).
 */
import { NAKSHATRAS, NATURAL_RELATIONS, RASHIS, type Planet } from "./constants";
import { computeKundli, type BirthInput } from "./kundli";

export const MATCHING_RULESET_VERSION = "north-ashtakoota-v1";

const VARNA_BY_SIGN = [1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0]; // 0 Brahmin, 1 Kshatriya, 2 Vaishya, 3 Shudra (by water/fire/earth/air)
const VARNA_NAMES = ["Brahmin", "Kshatriya", "Vaishya", "Shudra"];

// Vashya groups: 0 Chatushpada (quadruped), 1 Manava (human), 2 Jalachara (water), 3 Vanachara (wild), 4 Keeta (insect)
function vashyaGroup(lon: number) {
  const sign = Math.floor(lon / 30), deg = lon % 30;
  switch (sign) {
    case 0: case 1: return 0;
    case 2: case 5: case 6: case 10: return 1;
    case 3: case 11: return 2;
    case 4: return 3;
    case 7: return 4;
    case 8: return deg < 15 ? 1 : 0;
    case 9: return deg < 15 ? 0 : 2;
  }
  return 1;
}
const VASHYA_NAMES = ["Chatushpada", "Manava", "Jalachara", "Vanachara", "Keeta"];
/** rows: boy, cols: girl */
export const VASHYA_TABLE = [
  [2, 1, 1, 0.5, 1],
  [1, 2, 0.5, 0, 1],
  [1, 0.5, 2, 1, 1],
  [0.5, 0, 1, 2, 0],
  [1, 1, 1, 0, 2],
];

const YONI_OF_NAK = [0, 1, 2, 3, 3, 4, 5, 2, 5, 6, 6, 7, 8, 9, 8, 9, 10, 10, 4, 11, 12, 11, 13, 0, 13, 7, 1];
const YONI_NAMES = ["Horse", "Elephant", "Sheep", "Serpent", "Dog", "Cat", "Rat", "Cow", "Buffalo", "Tiger", "Deer", "Monkey", "Mongoose", "Lion"];
export const YONI_TABLE = [
  [4, 2, 2, 3, 2, 2, 2, 1, 0, 1, 3, 3, 2, 1],
  [2, 4, 3, 3, 2, 2, 2, 2, 3, 1, 2, 3, 2, 0],
  [2, 3, 4, 2, 1, 2, 1, 3, 3, 1, 2, 0, 3, 1],
  [3, 3, 2, 4, 2, 1, 1, 1, 1, 2, 2, 2, 0, 2],
  [2, 2, 1, 2, 4, 2, 1, 2, 2, 1, 0, 2, 1, 1],
  [2, 2, 2, 1, 2, 4, 0, 2, 2, 1, 3, 3, 2, 1],
  [2, 2, 1, 1, 1, 0, 4, 2, 2, 2, 2, 2, 1, 2],
  [1, 2, 3, 1, 2, 2, 2, 4, 3, 0, 3, 2, 2, 1],
  [0, 3, 3, 1, 2, 2, 2, 3, 4, 1, 2, 2, 2, 1],
  [1, 1, 1, 2, 1, 1, 2, 0, 1, 4, 1, 1, 2, 1],
  [3, 2, 2, 2, 0, 3, 2, 3, 2, 1, 4, 2, 2, 1],
  [3, 3, 0, 2, 2, 3, 2, 2, 2, 1, 2, 4, 3, 2],
  [2, 2, 3, 0, 1, 2, 1, 2, 2, 2, 2, 3, 4, 2],
  [1, 0, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 2, 4],
];

// Gana: 0 Deva, 1 Manushya, 2 Rakshasa
const GANA_OF_NAK = [0, 1, 2, 1, 0, 1, 0, 0, 2, 2, 1, 1, 0, 2, 0, 2, 0, 2, 2, 1, 1, 0, 2, 2, 1, 1, 0];
const GANA_NAMES = ["Deva", "Manushya", "Rakshasa"];
/** rows: boy, cols: girl */
export const GANA_TABLE = [
  [6, 6, 1],
  [5, 6, 0],
  [1, 0, 6],
];

// Nadi: 0 Adi (Vata), 1 Madhya (Pitta), 2 Antya (Kapha) — zig-zag over the 27 nakshatras
const NADI_OF_NAK = Array.from({ length: 27 }, (_, i) => [0, 1, 2, 2, 1, 0][i % 6]);
const NADI_NAMES = ["Adi", "Madhya", "Antya"];

function maitriScore(a: Planet, b: Planet) {
  if (a === b) return 5;
  const rel = (x: Planet, y: Planet) =>
    NATURAL_RELATIONS[x].friends.includes(y) ? 2 : NATURAL_RELATIONS[x].enemies.includes(y) ? 0 : 1;
  const r = [rel(a, b), rel(b, a)].sort().join("");
  return ({ "22": 5, "12": 4, "11": 3, "02": 1, "01": 0.5, "00": 0 } as Record<string, number>)[r];
}

function taraScore(fromNak: number, toNak: number) {
  const count = ((toNak - fromNak + 27) % 27) + 1;
  const tara = count % 9 === 0 ? 9 : count % 9;
  return { tara, good: ![3, 5, 7].includes(tara) };
}

export interface KootaResult {
  koota: string;
  max: number;
  score: number;
  boy: string;
  girl: string;
  meaning: string;
}

export function ashtaKoota(boyMoon: number, girlMoon: number) {
  const bs = Math.floor(boyMoon / 30), gs = Math.floor(girlMoon / 30);
  const bn = Math.floor(boyMoon / (360 / 27)), gn = Math.floor(girlMoon / (360 / 27));
  const out: KootaResult[] = [];

  const bv = VARNA_BY_SIGN[bs], gv = VARNA_BY_SIGN[gs];
  out.push({ koota: "Varna", max: 1, score: bv <= gv ? 1 : 0, boy: VARNA_NAMES[bv], girl: VARNA_NAMES[gv], meaning: "Spiritual and ego compatibility" });

  const bva = vashyaGroup(boyMoon), gva = vashyaGroup(girlMoon);
  out.push({ koota: "Vashya", max: 2, score: VASHYA_TABLE[bva][gva], boy: VASHYA_NAMES[bva], girl: VASHYA_NAMES[gva], meaning: "Mutual attraction and influence" });

  const t1 = taraScore(gn, bn), t2 = taraScore(bn, gn);
  out.push({ koota: "Tara", max: 3, score: (t1.good ? 1.5 : 0) + (t2.good ? 1.5 : 0), boy: `Tara ${t2.tara}`, girl: `Tara ${t1.tara}`, meaning: "Destiny, health and well-being" });

  const by = YONI_OF_NAK[bn], gy = YONI_OF_NAK[gn];
  out.push({ koota: "Yoni", max: 4, score: YONI_TABLE[by][gy], boy: YONI_NAMES[by], girl: YONI_NAMES[gy], meaning: "Physical and intimate compatibility" });

  const bl = RASHIS[bs].lord, gl = RASHIS[gs].lord;
  out.push({ koota: "Graha Maitri", max: 5, score: maitriScore(bl, gl), boy: bl, girl: gl, meaning: "Mental wavelength and friendship" });

  const bg = GANA_OF_NAK[bn], gg = GANA_OF_NAK[gn];
  out.push({ koota: "Gana", max: 6, score: GANA_TABLE[bg][gg], boy: GANA_NAMES[bg], girl: GANA_NAMES[gg], meaning: "Temperament" });

  const dist = ((bs - gs + 12) % 12) + 1; // boy's sign counted from girl's
  const pair = [dist, ((gs - bs + 12) % 12) + 1].sort((a, b) => a - b).join("/");
  const bhakootBad = ["2/12", "5/9", "6/8"].includes(pair);
  out.push({ koota: "Bhakoot", max: 7, score: bhakootBad ? 0 : 7, boy: RASHIS[bs].en, girl: RASHIS[gs].en, meaning: `Family welfare and prosperity (signs ${pair} apart)` });

  const bnd = NADI_OF_NAK[bn], gnd = NADI_OF_NAK[gn];
  out.push({ koota: "Nadi", max: 8, score: bnd === gnd ? 0 : 8, boy: NADI_NAMES[bnd], girl: NADI_NAMES[gnd], meaning: "Health and progeny" });

  const total = out.reduce((s, k) => s + k.score, 0);

  // Commonly cited cancellations (parihara). Reported, not auto-applied to the score.
  const nadiDosha = bnd === gnd;
  const nadiCancel: string[] = [];
  if (nadiDosha) {
    if (bs === gs && bn !== gn) nadiCancel.push("Same Rashi, different Nakshatra");
    if (bn === gn && Math.floor((boyMoon % (360 / 27)) / (360 / 108)) !== Math.floor((girlMoon % (360 / 27)) / (360 / 108))) nadiCancel.push("Same Nakshatra, different pada");
    if (bl === gl) nadiCancel.push("Same Rashi lord");
  }
  const bhakootCancel: string[] = [];
  if (bhakootBad) {
    if (bl === gl) bhakootCancel.push("Same Rashi lord");
    if (maitriScore(bl, gl) >= 4) bhakootCancel.push("Rashi lords are friends");
  }

  return {
    rulesetVersion: MATCHING_RULESET_VERSION,
    kootas: out,
    total,
    max: 36,
    verdict: total >= 28 ? "Excellent" : total >= 21 ? "Good" : total >= 18 ? "Average — acceptable traditionally" : "Below the traditional threshold of 18",
    nadiDosha: { present: nadiDosha, cancellations: nadiCancel },
    bhakootDosha: { present: bhakootBad, cancellations: bhakootCancel },
    boy: { rashi: RASHIS[bs].en, nakshatra: NAKSHATRAS[bn].en },
    girl: { rashi: RASHIS[gs].en, nakshatra: NAKSHATRAS[gn].en },
  };
}

export function matchProfiles(boy: BirthInput, girl: BirthInput) {
  const kb = computeKundli(boy);
  const kg = computeKundli(girl);
  const moon = (k: typeof kb) => k.planets.find((p) => p.planet === "Moon")!.lon;
  const koota = ashtaKoota(moon(kb), moon(kg));
  const mb = kb.doshas.manglik, mg = kg.doshas.manglik;
  return {
    ...koota,
    manglik: {
      boy: mb.present, girl: mg.present,
      compatible: mb.present === mg.present,
      note: mb.present === mg.present
        ? mb.present ? "Both charts are Manglik; tradition considers the dosha mutually balanced." : "Neither chart is Manglik."
        : "Only one chart is Manglik. Tradition advises reviewing mitigations with an astrologer.",
    },
    charts: {
      boy: { name: kb.meta.name, lagna: kb.summary.lagna, rashi: kb.summary.rashi, nakshatra: kb.summary.nakshatra },
      girl: { name: kg.meta.name, lagna: kg.summary.lagna, rashi: kg.summary.rashi, nakshatra: kg.summary.nakshatra },
    },
  };
}
