/**
 * Festival & vrat rules engine. Dates are derived from computed tithis, never
 * hardcoded. Each rule names the lunar month (Amanta), the tithi and the time
 * of day at which that tithi must prevail (karmakala). Rules are data, so they
 * can be moved to the `festival_rules` table and edited by admins.
 */
import { MASAS, RASHIS, TITHIS } from "./constants";
import { nextNewMoon, prevNewMoon, searchRiseSet, siderealLongitude } from "./ephemeris";
import { elongation } from "./panchang";
import { findCrossing } from "./search";
import { addDays, localIsoDate, localMidnight } from "./time";

export type Karmakala = "sunrise" | "madhyahna" | "aparahna" | "pradosh" | "nishita" | "moonrise-evening";

export interface FestivalRule {
  id: string;
  name: string;
  masa: number; // Amanta month, Chaitra = 0
  tithi: number; // 0..29 (Shukla 0–14, Krishna 15–29)
  at: Karmakala;
  category: "festival" | "vrat";
  note?: string;
}

export const FESTIVAL_RULES: FestivalRule[] = [
  { id: "ugadi-gudi-padwa", name: "Ugadi / Gudi Padwa", masa: 0, tithi: 0, at: "sunrise", category: "festival" },
  { id: "chaitra-navratri", name: "Chaitra Navratri begins", masa: 0, tithi: 0, at: "sunrise", category: "festival" },
  { id: "ram-navami", name: "Ram Navami", masa: 0, tithi: 8, at: "madhyahna", category: "festival" },
  { id: "hanuman-jayanti", name: "Hanuman Jayanti", masa: 0, tithi: 14, at: "sunrise", category: "festival", note: "North Indian date; observed on other dates in parts of South India" },
  { id: "akshaya-tritiya", name: "Akshaya Tritiya", masa: 1, tithi: 2, at: "sunrise", category: "festival" },
  { id: "guru-purnima", name: "Guru Purnima", masa: 3, tithi: 14, at: "sunrise", category: "festival" },
  { id: "raksha-bandhan", name: "Raksha Bandhan", masa: 4, tithi: 14, at: "aparahna", category: "festival", note: "Rakhi is traditionally tied outside Bhadra (Vishti karana)" },
  { id: "janmashtami", name: "Krishna Janmashtami", masa: 4, tithi: 22, at: "nishita", category: "festival", note: "Smarta rule (Ashtami at midnight). ISKCON/Vaishnava dates may differ by a day" },
  { id: "ganesh-chaturthi", name: "Ganesh Chaturthi", masa: 5, tithi: 3, at: "madhyahna", category: "festival" },
  { id: "sharad-navratri", name: "Sharad Navratri begins", masa: 6, tithi: 0, at: "sunrise", category: "festival" },
  { id: "dussehra", name: "Dussehra (Vijayadashami)", masa: 6, tithi: 9, at: "aparahna", category: "festival" },
  { id: "sharad-purnima", name: "Sharad Purnima", masa: 6, tithi: 14, at: "pradosh", category: "festival" },
  { id: "karva-chauth", name: "Karva Chauth", masa: 6, tithi: 18, at: "moonrise-evening", category: "vrat", note: "Purnimanta: Kartika Krishna Chaturthi" },
  { id: "dhanteras", name: "Dhanteras", masa: 6, tithi: 27, at: "pradosh", category: "festival" },
  { id: "diwali", name: "Diwali (Lakshmi Puja)", masa: 6, tithi: 29, at: "pradosh", category: "festival", note: "Amavasya prevailing during Pradosh Kaal" },
  { id: "govardhan-puja", name: "Govardhan Puja", masa: 7, tithi: 0, at: "sunrise", category: "festival" },
  { id: "bhai-dooj", name: "Bhai Dooj", masa: 7, tithi: 1, at: "aparahna", category: "festival" },
  { id: "chhath-puja", name: "Chhath Puja (Sandhya Arghya)", masa: 7, tithi: 5, at: "sunrise", category: "festival" },
  { id: "dev-uthani-ekadashi", name: "Dev Uthani Ekadashi", masa: 7, tithi: 10, at: "sunrise", category: "vrat" },
  { id: "vasant-panchami", name: "Vasant Panchami", masa: 10, tithi: 4, at: "sunrise", category: "festival" },
  { id: "maha-shivaratri", name: "Maha Shivaratri", masa: 10, tithi: 28, at: "nishita", category: "festival", note: "Purnimanta: Phalguna Krishna Chaturdashi" },
  { id: "holika-dahan", name: "Holika Dahan", masa: 11, tithi: 14, at: "pradosh", category: "festival", note: "Holi (Dhulandi) is celebrated the following day" },
];

interface Lunation { start: Date; end: Date; masa: number; adhik: boolean }

function lunations(from: Date, to: Date): Lunation[] {
  const out: Lunation[] = [];
  let nm = prevNewMoon(from);
  while (nm < to) {
    const next = nextNewMoon(new Date(nm.getTime() + 86400e3));
    const r1 = Math.floor(siderealLongitude("Sun", nm) / 30);
    const r2 = Math.floor(siderealLongitude("Sun", next) / 30);
    out.push({ start: nm, end: next, masa: (r1 + 1) % 12, adhik: r1 === r2 });
    nm = next;
  }
  return out;
}

interface DayInfo {
  date: string;
  sunrise: Date;
  sunset: Date;
  nextSunrise: Date;
  points: Record<Karmakala, Date>;
}

function dayInfo(date: string, lat: number, lon: number, tz: string): DayInfo | null {
  const sunrise = searchRiseSet("Sun", "rise", localMidnight(date, tz), lat, lon);
  if (!sunrise) return null;
  const sunset = searchRiseSet("Sun", "set", sunrise, lat, lon)!;
  const nextSunrise = searchRiseSet("Sun", "rise", new Date(sunset.getTime() + 60e3), lat, lon)!;
  const day = sunset.getTime() - sunrise.getTime();
  const night = nextSunrise.getTime() - sunset.getTime();
  const at = (t: number) => new Date(t);
  return {
    date, sunrise, sunset, nextSunrise,
    points: {
      sunrise: at(sunrise.getTime() + 60e3),
      madhyahna: at(sunrise.getTime() + day * 0.5),
      aparahna: at(sunrise.getTime() + day * 0.7),
      pradosh: at(sunset.getTime() + night * (1 / 15)), // first muhurta after sunset
      nishita: at(sunset.getTime() + night * 0.5),
      "moonrise-evening": at(sunset.getTime() + 2 * 3600e3),
    },
  };
}

export interface CalendarEvent {
  id: string;
  name: string;
  date: string;
  category: "festival" | "vrat" | "sankranti";
  tithi?: string;
  masa?: string;
  tithiStart?: string | null;
  tithiEnd?: string | null;
  note?: string;
}

/** Festivals, Ekadashi, Pradosh, Purnima, Amavasya and Sankranti between two civil dates (inclusive). */
export function festivalCalendar(startDate: string, endDate: string, lat: number, lon: number, tz: string): CalendarEvent[] {
  const days: DayInfo[] = [];
  for (let d = startDate; d <= endDate; d = addDays(d, 1)) {
    const info = dayInfo(d, lat, lon, tz);
    if (info) days.push(info);
  }
  if (!days.length) return [];
  const lun = lunations(days[0].sunrise, days[days.length - 1].nextSunrise);
  const masaAt = (t: Date) => lun.find((l) => t >= l.start && t < l.end);
  const tithiAt = (t: Date) => Math.floor(elongation(t) / 12);
  const span = (tithi: number, near: Date) => ({
    tithiStart: findCrossing(elongation, tithi * 12, near, -1, 4, 3)?.toISOString() ?? null,
    tithiEnd: findCrossing(elongation, ((tithi + 1) % 30) * 12, near, 1, 4, 3)?.toISOString() ?? null,
  });

  const events: CalendarEvent[] = [];
  const pushRule = (rule: { id: string; name: string; tithi: number; at: Karmakala; category: "festival" | "vrat"; note?: string; masa?: number }) => {
    // Candidate days: the tithi prevails at the karmakala, or (kshaya tithi) it begins and
    // ends between this day's karmakala and the next, in which case this day observes it.
    const T = rule.tithi;
    const hits: { day: DayInfo; near: Date }[] = [];
    days.forEach((d, i) => {
      const t = d.points[rule.at];
      const ti = tithiAt(t);
      let near: Date | null = null;
      if (ti === T) near = t;
      else if (ti === (T + 29) % 30 && days[i + 1] && tithiAt(days[i + 1].points[rule.at]) === (T + 1) % 30) {
        const start = findCrossing(elongation, T * 12, t, 1, 2, 2);
        if (start) near = new Date(start.getTime() + 60e3);
      }
      if (!near) return;
      const m = masaAt(near);
      if (rule.masa === undefined || (m && !m.adhik && m.masa === rule.masa)) hits.push({ day: d, near });
    });
    // group consecutive hits (vriddhi tithi): the first day is taken
    const chosen: { day: DayInfo; near: Date }[] = [];
    for (const h of hits) {
      const prev = chosen[chosen.length - 1];
      if (prev && addDays(prev.day.date, 1) === h.day.date) continue;
      chosen.push(h);
    }
    for (const { day: c, near } of chosen) {
      const m = masaAt(near);
      events.push({
        id: `${rule.id}-${c.date}`,
        name: rule.name,
        date: c.date,
        category: rule.category,
        tithi: `${TITHIS[rule.tithi].paksha} ${TITHIS[rule.tithi].en}`,
        masa: m ? MASAS[m.masa].en + (m.adhik ? " (Adhik)" : "") : undefined,
        note: rule.note,
        ...span(rule.tithi, near),
      });
    }
  };

  FESTIVAL_RULES.forEach((r) => pushRule(r));
  // Recurring vrats
  pushRule({ id: "ekadashi-shukla", name: "Shukla Ekadashi", tithi: 10, at: "sunrise", category: "vrat", note: "Smarta observance (Ekadashi at sunrise). Vaishnava Ekadashi may fall a day later" });
  pushRule({ id: "ekadashi-krishna", name: "Krishna Ekadashi", tithi: 25, at: "sunrise", category: "vrat", note: "Smarta observance (Ekadashi at sunrise). Vaishnava Ekadashi may fall a day later" });
  pushRule({ id: "pradosh-shukla", name: "Pradosh Vrat (Shukla)", tithi: 12, at: "pradosh", category: "vrat" });
  pushRule({ id: "pradosh-krishna", name: "Pradosh Vrat (Krishna)", tithi: 27, at: "pradosh", category: "vrat" });
  pushRule({ id: "purnima", name: "Purnima", tithi: 14, at: "sunrise", category: "vrat" });
  pushRule({ id: "amavasya", name: "Amavasya", tithi: 29, at: "sunrise", category: "vrat" });
  pushRule({ id: "sankashti", name: "Sankashti Chaturthi", tithi: 18, at: "moonrise-evening", category: "vrat" });

  // Sankrantis (solar ingress). Makar Sankranti flagged as a festival.
  const sun = (d: Date) => siderealLongitude("Sun", d);
  let t = days[0].sunrise;
  const end = days[days.length - 1].nextSunrise;
  while (t < end) {
    const sign = Math.floor(sun(t) / 30);
    const ing = findCrossing(sun, ((sign + 1) % 12) * 30, t, 1, 24, 40);
    if (!ing || ing > end) break;
    const s = (sign + 1) % 12;
    events.push({
      id: `sankranti-${s}-${localIsoDate(ing, tz)}`,
      name: s === 9 ? "Makar Sankranti" : `${RASHIS[s].en} Sankranti`,
      date: localIsoDate(ing, tz),
      category: s === 9 ? "festival" : "sankranti",
      tithiStart: ing.toISOString(),
      note: "Exact moment of the Sun's sidereal ingress",
    });
    t = new Date(ing.getTime() + 86400e3);
  }

  return events.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name));
}
