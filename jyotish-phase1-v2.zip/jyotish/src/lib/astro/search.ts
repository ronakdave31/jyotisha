/** Root-finding helpers for angular quantities that increase over time. */

const wrap180 = (x: number) => {
  const y = ((x + 180) % 360 + 360) % 360 - 180;
  return y;
};

/**
 * Find when an increasing angular function `fn` passes `target` (deg).
 * direction +1 searches forward from `from`, -1 backward. Precision ~1 second.
 */
export function findCrossing(
  fn: (d: Date) => number,
  target: number,
  from: Date,
  direction: 1 | -1 = 1,
  stepHours = 4,
  maxDays = 40,
): Date | null {
  const g = (t: number) => wrap180(fn(new Date(t)) - target);
  const step = stepHours * 3600e3 * direction;
  let t0 = from.getTime();
  let g0 = g(t0);
  const end = t0 + direction * maxDays * 86400e3;
  while (direction === 1 ? t0 < end : t0 > end) {
    const t1 = t0 + step;
    const g1 = g(t1);
    const before = direction === 1 ? g0 : g1;
    const after = direction === 1 ? g1 : g0;
    if (before < 0 && after >= 0 && Math.abs(before) < 90 && Math.abs(after) < 90) {
      let lo = Math.min(t0, t1);
      let hi = Math.max(t0, t1);
      while (hi - lo > 1000) {
        const mid = (lo + hi) / 2;
        if (g(mid) < 0) lo = mid;
        else hi = mid;
      }
      return new Date(Math.round((lo + hi) / 2));
    }
    t0 = t1;
    g0 = g1;
  }
  return null;
}
