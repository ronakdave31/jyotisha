/**
 * Rule-based life-area interpretations. Kept separate from calculations so an
 * astrologer can edit the wording (mirrored in the `interpretations` table).
 * Every statement names the chart factor it comes from.
 */
import { RASHIS, type Planet } from "./constants";
import type { Kundli } from "./kundli";
import { ordinal } from "./horoscope";

export const HOUSE_THEMES = [
  "self, body and personality", "family, speech and accumulated wealth", "courage, effort, siblings and communication",
  "home, mother, property and inner peace", "children, intelligence, creativity and past merit", "service, health routines, debts and competition",
  "marriage, partnerships and public dealings", "transformation, longevity, research and hidden matters", "fortune, dharma, teachers and long journeys",
  "career, status and public action", "gains, networks and fulfilment of desires", "expenses, foreign lands, retreat and liberation",
];

const STRONG = ["Exalted", "Moolatrikona", "Own sign"];
const DUSTHANA = [6, 8, 12];
const GOOD_HOUSES = [1, 4, 5, 7, 9, 10, 11];

interface Area {
  id: string;
  title: string;
  house: number;
  karaka: Planet;
  focus: string;
  disclaimer?: string;
}

export const LIFE_AREAS: Area[] = [
  { id: "career", title: "Career and business", house: 10, karaka: "Saturn", focus: "profession and reputation" },
  { id: "marriage", title: "Marriage and relationships", house: 7, karaka: "Venus", focus: "partnership" },
  { id: "wealth", title: "Wealth and finances", house: 2, karaka: "Jupiter", focus: "savings and income" },
  { id: "education", title: "Education", house: 5, karaka: "Mercury", focus: "learning and intellect" },
  {
    id: "health", title: "Health tendencies", house: 6, karaka: "Sun", focus: "vitality and routines",
    disclaimer: "Astrological indications are traditional beliefs, not medical advice. Consult a qualified doctor for any health concern.",
  },
  { id: "family", title: "Family and children", house: 4, karaka: "Jupiter", focus: "home life and children" },
  { id: "spiritual", title: "Spiritual growth", house: 9, karaka: "Jupiter", focus: "dharma and inner growth" },
];

export function interpret(k: Kundli) {
  const planet = (p: Planet) => k.planets.find((x) => x.planet === p)!;
  const areas = LIFE_AREAS.map((a) => {
    const h = k.houses[a.house - 1];
    const lord = planet(h.lord);
    const karaka = planet(a.karaka);
    const points: string[] = [];

    points.push(
      `Your ${ordinal(a.house)} house (${HOUSE_THEMES[a.house - 1]}) falls in ${h.signName}, ruled by ${h.lord}. ` +
        `${h.lord} sits in the ${ordinal(lord.house)} house of ${HOUSE_THEMES[lord.house - 1]}, linking ${a.focus} with those themes.`,
    );
    if (STRONG.includes(lord.dignity)) points.push(`${h.lord} is ${lord.dignity.toLowerCase()}, which tradition reads as a well-supported ${a.focus}.`);
    if (lord.dignity === "Debilitated") points.push(`${h.lord} is debilitated; results in ${a.focus} traditionally come through sustained effort and maturity.`);
    if (DUSTHANA.includes(lord.house) && lord.house !== a.house) points.push(`The lord in a dusthana (6, 8 or 12) suggests obstacles to work through in this area.`);
    if (GOOD_HOUSES.includes(lord.house)) points.push(`The lord in a kendra or trikona-type house is considered supportive.`);
    if (lord.combust) points.push(`${h.lord} is combust (close to the Sun), which can weaken its independent expression.`);
    if (h.occupants.length) points.push(`Planets in this house: ${h.occupants.join(", ")}. Each colours ${a.focus} with its own nature.`);
    else points.push(`No planets occupy this house, so its lord and aspects carry most of the indication.`);
    points.push(
      `${a.karaka}, the natural significator (karaka), is in ${karaka.signName} in your ${ordinal(karaka.house)} house` +
        (STRONG.includes(karaka.dignity) ? `, ${karaka.dignity.toLowerCase()} and strong.` : karaka.dignity === "Debilitated" ? `, debilitated.` : `.`),
    );
    if (a.id === "marriage" && k.doshas.manglik.present) points.push(`Manglik Dosha is present (${k.doshas.manglik.severity.toLowerCase()}); see the Dosha section for traditional mitigations.`);
    return { ...a, points };
  });

  const cur = k.dasha.current;
  const periods = cur
    ? [
        `You are running the ${cur.mahadasha} Mahadasha until ${new Date(cur.mdEnd).toDateString()}. ${cur.mahadasha} rules your ` +
          k.houses.filter((h) => h.lord === cur.mahadasha).map((h) => ordinal(h.house)).join(" and ") +
          ` house(s) and sits in your ${ordinal(planet(cur.mahadasha).house)} house, so these themes are emphasised.`,
        cur.antardasha ? `The current Antardasha is ${cur.antardasha}, until ${new Date(cur.adEnd!).toDateString()}.` : "",
      ].filter(Boolean)
    : [];

  return {
    lagna: `${RASHIS[k.ascendant.sign].en} Lagna (${RASHIS[k.ascendant.sign].western} ascendant), ruled by ${k.ascendant.lord}.`,
    areas,
    periods,
    disclaimer: "Interpretations follow classical Parashari rules and are offered as traditional guidance, not guaranteed predictions.",
  };
}
