import { NAKSHATRAS, VIMSHOTTARI_ORDER, VIMSHOTTARI_YEARS, type Planet } from "./constants";

/** Year length used to convert dasha years into days (configurable; 365.25 is the common default). */
export const DASHA_YEAR_DAYS = 365.25;
const DAY = 86400e3;
const TOTAL = 120;

export interface DashaPeriod {
  lord: Planet;
  start: string;
  end: string;
  years: number;
  sub?: DashaPeriod[];
}

function subPeriods(parentLord: Planet, start: number, parentYears: number, depth: number, now: number): DashaPeriod[] {
  const out: DashaPeriod[] = [];
  let idx = VIMSHOTTARI_ORDER.indexOf(parentLord);
  let t = start;
  for (let i = 0; i < 9; i++) {
    const lord = VIMSHOTTARI_ORDER[(idx + i) % 9];
    const years = (parentYears * VIMSHOTTARI_YEARS[lord]) / TOTAL;
    const end = t + years * DASHA_YEAR_DAYS * DAY;
    const p: DashaPeriod = { lord, start: new Date(t).toISOString(), end: new Date(end).toISOString(), years };
    // Pratyantardasha only for the antardashas of the running mahadasha (keeps payload small)
    if (depth > 1 && now >= start && now < start + parentYears * DASHA_YEAR_DAYS * DAY) {
      p.sub = subPeriods(lord, t, years, depth - 1, now);
    }
    out.push(p);
    t = end;
  }
  return out;
}

/**
 * Vimshottari Dasha from the Moon's sidereal longitude at birth.
 * Returns mahadashas covering 120 years from the (virtual) start of the birth dasha.
 */
export function vimshottari(moonLon: number, birth: Date, now = new Date()) {
  const nakLen = 360 / 27;
  const nak = Math.floor(moonLon / nakLen);
  const fractionElapsed = (moonLon % nakLen) / nakLen;
  const firstLord = NAKSHATRAS[nak].lord;
  const firstYears = VIMSHOTTARI_YEARS[firstLord];
  const virtualStart = birth.getTime() - fractionElapsed * firstYears * DASHA_YEAR_DAYS * DAY;
  const balanceYears = (1 - fractionElapsed) * firstYears;

  const mahadashas: DashaPeriod[] = [];
  let t = virtualStart;
  const startIdx = VIMSHOTTARI_ORDER.indexOf(firstLord);
  for (let i = 0; i < 9; i++) {
    const lord = VIMSHOTTARI_ORDER[(startIdx + i) % 9];
    const years = VIMSHOTTARI_YEARS[lord];
    const end = t + years * DASHA_YEAR_DAYS * DAY;
    mahadashas.push({
      lord, years,
      start: new Date(t).toISOString(),
      end: new Date(end).toISOString(),
      sub: subPeriods(lord, t, years, now.getTime() >= t && now.getTime() < end ? 2 : 1, now.getTime()),
    });
    t = end;
  }

  const nowMs = now.getTime();
  const within = (p: DashaPeriod) => nowMs >= Date.parse(p.start) && nowMs < Date.parse(p.end);
  const md = mahadashas.find(within);
  const ad = md?.sub?.find(within);
  const pd = ad?.sub?.find(within);

  return {
    system: "Vimshottari",
    yearDays: DASHA_YEAR_DAYS,
    birthNakshatra: NAKSHATRAS[nak].en,
    balance: { lord: firstLord, years: balanceYears },
    mahadashas,
    current: md ? { mahadasha: md.lord, antardasha: ad?.lord, pratyantardasha: pd?.lord, mdEnd: md.end, adEnd: ad?.end, pdEnd: pd?.end } : null,
  };
}

/** Recompute antardasha + pratyantardasha for any mahadasha (used by the Dasha explorer). */
export function expandMahadasha(md: { lord: Planet; start: string; years: number }) {
  const start = Date.parse(md.start);
  return subPeriods(md.lord, start, md.years, 1, -1).map((ad) => ({
    ...ad,
    sub: subPeriods(ad.lord, Date.parse(ad.start), ad.years, 0, -1),
  }));
}
