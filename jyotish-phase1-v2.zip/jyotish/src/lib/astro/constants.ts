// Traditional reference data. Pure data only — no calculation logic lives here.

export type Bilingual = { en: string; hi: string };

export const RASHIS: (Bilingual & { lord: Planet; element: "Fire" | "Earth" | "Air" | "Water"; quality: "Movable" | "Fixed" | "Dual"; western: string })[] = [
  { en: "Mesha", hi: "मेष", western: "Aries", lord: "Mars", element: "Fire", quality: "Movable" },
  { en: "Vrishabha", hi: "वृषभ", western: "Taurus", lord: "Venus", element: "Earth", quality: "Fixed" },
  { en: "Mithuna", hi: "मिथुन", western: "Gemini", lord: "Mercury", element: "Air", quality: "Dual" },
  { en: "Karka", hi: "कर्क", western: "Cancer", lord: "Moon", element: "Water", quality: "Movable" },
  { en: "Simha", hi: "सिंह", western: "Leo", lord: "Sun", element: "Fire", quality: "Fixed" },
  { en: "Kanya", hi: "कन्या", western: "Virgo", lord: "Mercury", element: "Earth", quality: "Dual" },
  { en: "Tula", hi: "तुला", western: "Libra", lord: "Venus", element: "Air", quality: "Movable" },
  { en: "Vrishchika", hi: "वृश्चिक", western: "Scorpio", lord: "Mars", element: "Water", quality: "Fixed" },
  { en: "Dhanu", hi: "धनु", western: "Sagittarius", lord: "Jupiter", element: "Fire", quality: "Dual" },
  { en: "Makara", hi: "मकर", western: "Capricorn", lord: "Saturn", element: "Earth", quality: "Movable" },
  { en: "Kumbha", hi: "कुम्भ", western: "Aquarius", lord: "Saturn", element: "Air", quality: "Fixed" },
  { en: "Meena", hi: "मीन", western: "Pisces", lord: "Jupiter", element: "Water", quality: "Dual" },
];

export type Planet = "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn" | "Rahu" | "Ketu";
export const PLANETS: Planet[] = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"];
export const PLANET_HI: Record<Planet, string> = {
  Sun: "सूर्य", Moon: "चन्द्र", Mars: "मंगल", Mercury: "बुध", Jupiter: "गुरु", Venus: "शुक्र", Saturn: "शनि", Rahu: "राहु", Ketu: "केतु",
};
export const PLANET_ABBR: Record<Planet | "Ascendant", string> = {
  Sun: "Su", Moon: "Mo", Mars: "Ma", Mercury: "Me", Jupiter: "Ju", Venus: "Ve", Saturn: "Sa", Rahu: "Ra", Ketu: "Ke", Ascendant: "As",
};

export const NAKSHATRAS: (Bilingual & { lord: Planet; deity: string })[] = [
  { en: "Ashwini", hi: "अश्विनी", lord: "Ketu", deity: "Ashwini Kumaras" },
  { en: "Bharani", hi: "भरणी", lord: "Venus", deity: "Yama" },
  { en: "Krittika", hi: "कृत्तिका", lord: "Sun", deity: "Agni" },
  { en: "Rohini", hi: "रोहिणी", lord: "Moon", deity: "Brahma" },
  { en: "Mrigashira", hi: "मृगशिरा", lord: "Mars", deity: "Soma" },
  { en: "Ardra", hi: "आर्द्रा", lord: "Rahu", deity: "Rudra" },
  { en: "Punarvasu", hi: "पुनर्वसु", lord: "Jupiter", deity: "Aditi" },
  { en: "Pushya", hi: "पुष्य", lord: "Saturn", deity: "Brihaspati" },
  { en: "Ashlesha", hi: "आश्लेषा", lord: "Mercury", deity: "Sarpa" },
  { en: "Magha", hi: "मघा", lord: "Ketu", deity: "Pitrs" },
  { en: "Purva Phalguni", hi: "पूर्व फाल्गुनी", lord: "Venus", deity: "Bhaga" },
  { en: "Uttara Phalguni", hi: "उत्तर फाल्गुनी", lord: "Sun", deity: "Aryaman" },
  { en: "Hasta", hi: "हस्त", lord: "Moon", deity: "Savitr" },
  { en: "Chitra", hi: "चित्रा", lord: "Mars", deity: "Tvashtr" },
  { en: "Swati", hi: "स्वाति", lord: "Rahu", deity: "Vayu" },
  { en: "Vishakha", hi: "विशाखा", lord: "Jupiter", deity: "Indra-Agni" },
  { en: "Anuradha", hi: "अनुराधा", lord: "Saturn", deity: "Mitra" },
  { en: "Jyeshtha", hi: "ज्येष्ठा", lord: "Mercury", deity: "Indra" },
  { en: "Mula", hi: "मूल", lord: "Ketu", deity: "Nirriti" },
  { en: "Purva Ashadha", hi: "पूर्वाषाढ़ा", lord: "Venus", deity: "Apas" },
  { en: "Uttara Ashadha", hi: "उत्तराषाढ़ा", lord: "Sun", deity: "Vishvedevas" },
  { en: "Shravana", hi: "श्रवण", lord: "Moon", deity: "Vishnu" },
  { en: "Dhanishta", hi: "धनिष्ठा", lord: "Mars", deity: "Vasus" },
  { en: "Shatabhisha", hi: "शतभिषा", lord: "Rahu", deity: "Varuna" },
  { en: "Purva Bhadrapada", hi: "पूर्व भाद्रपद", lord: "Jupiter", deity: "Aja Ekapada" },
  { en: "Uttara Bhadrapada", hi: "उत्तर भाद्रपद", lord: "Saturn", deity: "Ahirbudhnya" },
  { en: "Revati", hi: "रेवती", lord: "Mercury", deity: "Pushan" },
];

const TITHI_BASE: Bilingual[] = [
  { en: "Pratipada", hi: "प्रतिपदा" }, { en: "Dwitiya", hi: "द्वितीया" }, { en: "Tritiya", hi: "तृतीया" },
  { en: "Chaturthi", hi: "चतुर्थी" }, { en: "Panchami", hi: "पंचमी" }, { en: "Shashthi", hi: "षष्ठी" },
  { en: "Saptami", hi: "सप्तमी" }, { en: "Ashtami", hi: "अष्टमी" }, { en: "Navami", hi: "नवमी" },
  { en: "Dashami", hi: "दशमी" }, { en: "Ekadashi", hi: "एकादशी" }, { en: "Dwadashi", hi: "द्वादशी" },
  { en: "Trayodashi", hi: "त्रयोदशी" }, { en: "Chaturdashi", hi: "चतुर्दशी" },
];
/** Index 0..29. 0–14 Shukla (14 = Purnima), 15–29 Krishna (29 = Amavasya). */
export const TITHIS: (Bilingual & { paksha: "Shukla" | "Krishna"; number: number })[] = Array.from({ length: 30 }, (_, i) => {
  const paksha = i < 15 ? "Shukla" : "Krishna";
  const n = i % 15;
  const name = n === 14 ? (paksha === "Shukla" ? { en: "Purnima", hi: "पूर्णिमा" } : { en: "Amavasya", hi: "अमावस्या" }) : TITHI_BASE[n];
  return { ...name, paksha, number: n + 1 };
});

export const YOGAS: Bilingual[] = [
  ["Vishkambha", "विष्कम्भ"], ["Priti", "प्रीति"], ["Ayushman", "आयुष्मान"], ["Saubhagya", "सौभाग्य"], ["Shobhana", "शोभन"],
  ["Atiganda", "अतिगण्ड"], ["Sukarma", "सुकर्मा"], ["Dhriti", "धृति"], ["Shula", "शूल"], ["Ganda", "गण्ड"],
  ["Vriddhi", "वृद्धि"], ["Dhruva", "ध्रुव"], ["Vyaghata", "व्याघात"], ["Harshana", "हर्षण"], ["Vajra", "वज्र"],
  ["Siddhi", "सिद्धि"], ["Vyatipata", "व्यतीपात"], ["Variyana", "वरीयान"], ["Parigha", "परिघ"], ["Shiva", "शिव"],
  ["Siddha", "सिद्ध"], ["Sadhya", "साध्य"], ["Shubha", "शुभ"], ["Shukla", "शुक्ल"], ["Brahma", "ब्रह्म"],
  ["Indra", "इन्द्र"], ["Vaidhriti", "वैधृति"],
].map(([en, hi]) => ({ en, hi }));

/** Yogas traditionally treated as inauspicious for beginning new work. */
export const INAUSPICIOUS_YOGAS = new Set([0, 5, 8, 9, 12, 14, 16, 18, 26]);

export const MOVABLE_KARANAS: Bilingual[] = [
  { en: "Bava", hi: "बव" }, { en: "Balava", hi: "बालव" }, { en: "Kaulava", hi: "कौलव" }, { en: "Taitila", hi: "तैतिल" },
  { en: "Garaja", hi: "गर" }, { en: "Vanija", hi: "वणिज" }, { en: "Vishti (Bhadra)", hi: "विष्टि (भद्रा)" },
];
export const FIXED_KARANAS: Bilingual[] = [
  { en: "Shakuni", hi: "शकुनि" }, { en: "Chatushpada", hi: "चतुष्पद" }, { en: "Naga", hi: "नाग" }, { en: "Kimstughna", hi: "किंस्तुघ्न" },
];

export const VARAS: (Bilingual & { lord: Planet; english: string })[] = [
  { en: "Ravivara", hi: "रविवार", english: "Sunday", lord: "Sun" },
  { en: "Somavara", hi: "सोमवार", english: "Monday", lord: "Moon" },
  { en: "Mangalavara", hi: "मंगलवार", english: "Tuesday", lord: "Mars" },
  { en: "Budhavara", hi: "बुधवार", english: "Wednesday", lord: "Mercury" },
  { en: "Guruvara", hi: "गुरुवार", english: "Thursday", lord: "Jupiter" },
  { en: "Shukravara", hi: "शुक्रवार", english: "Friday", lord: "Venus" },
  { en: "Shanivara", hi: "शनिवार", english: "Saturday", lord: "Saturn" },
];

/** Lunar months, Chaitra first. */
export const MASAS: Bilingual[] = [
  ["Chaitra", "चैत्र"], ["Vaishakha", "वैशाख"], ["Jyeshtha", "ज्येष्ठ"], ["Ashadha", "आषाढ़"], ["Shravana", "श्रावण"],
  ["Bhadrapada", "भाद्रपद"], ["Ashwin", "आश्विन"], ["Kartika", "कार्तिक"], ["Margashirsha", "मार्गशीर्ष"],
  ["Pausha", "पौष"], ["Magha", "माघ"], ["Phalguna", "फाल्गुन"],
].map(([en, hi]) => ({ en, hi }));

export const SAMVATSARAS = [
  "Prabhava", "Vibhava", "Shukla", "Pramoda", "Prajapati", "Angirasa", "Shrimukha", "Bhava", "Yuva", "Dhatri",
  "Ishvara", "Bahudhanya", "Pramathi", "Vikrama", "Vrisha", "Chitrabhanu", "Svabhanu", "Tarana", "Parthiva", "Vyaya",
  "Sarvajit", "Sarvadhari", "Virodhi", "Vikriti", "Khara", "Nandana", "Vijaya", "Jaya", "Manmatha", "Durmukhi",
  "Hevilambi", "Vilambi", "Vikari", "Sharvari", "Plava", "Shubhakrit", "Shobhakrit", "Krodhi", "Vishvavasu", "Parabhava",
  "Plavanga", "Kilaka", "Saumya", "Sadharana", "Virodhikrit", "Paridhavi", "Pramadi", "Ananda", "Rakshasa", "Nala",
  "Pingala", "Kalayukti", "Siddharthi", "Raudra", "Durmati", "Dundubhi", "Rudhirodgari", "Raktakshi", "Krodhana", "Akshaya",
];

export const RITUS: Bilingual[] = [
  ["Vasanta", "वसन्त"], ["Grishma", "ग्रीष्म"], ["Varsha", "वर्षा"], ["Sharad", "शरद"], ["Hemanta", "हेमन्त"], ["Shishira", "शिशिर"],
].map(([en, hi]) => ({ en, hi }));

/** Chaldean (descending speed) order used for Hora. */
export const HORA_ORDER: Planet[] = ["Sun", "Venus", "Mercury", "Moon", "Saturn", "Jupiter", "Mars"];

export const CHOGHADIYA = {
  dayOrder: ["Udveg", "Char", "Labh", "Amrit", "Kaal", "Shubh", "Rog"],
  nightOrder: ["Shubh", "Amrit", "Char", "Rog", "Kaal", "Labh", "Udveg"],
  /** First choghadiya by weekday (Sun..Sat) */
  dayStart: ["Udveg", "Amrit", "Rog", "Labh", "Shubh", "Char", "Kaal"],
  nightStart: ["Shubh", "Char", "Kaal", "Udveg", "Amrit", "Rog", "Labh"],
  quality: { Amrit: "Best", Shubh: "Good", Labh: "Gain", Char: "Neutral", Udveg: "Bad", Rog: "Evil", Kaal: "Loss" } as Record<string, string>,
};

/** 1-based segment of the 8-fold daytime division, by weekday Sun..Sat. */
export const RAHU_KAAL_SEGMENT = [8, 2, 7, 5, 6, 4, 3];
export const YAMAGANDA_SEGMENT = [5, 4, 3, 2, 1, 7, 6];
export const GULIKA_SEGMENT = [7, 6, 5, 4, 3, 2, 1];

/** Dur Muhurat: 1-based daytime muhurta (of 15). "N" prefix = night muhurta. Sun..Sat */
export const DUR_MUHURAT: (number | `N${number}`)[][] = [[14], [9, 12], [4, "N7"], [8], [6, 12], [4, 9], [1, 2]];

/** Ghatis (of 60) from nakshatra start at which Varjyam (Tyajya) and Amrit Kaal begin. Each lasts 4 ghatis, scaled to nakshatra length. */
export const VARJYAM_GHATI = [50, 24, 30, 40, 14, 21, 30, 20, 32, 30, 20, 18, 21, 20, 14, 14, 10, 14, 20, 24, 20, 10, 10, 18, 16, 30, 30];
export const AMRIT_GHATI = [42, 48, 54, 52, 38, 35, 54, 44, 56, 54, 44, 42, 45, 44, 38, 38, 34, 38, 44, 48, 44, 34, 34, 42, 40, 54, 54];

export const VIMSHOTTARI_ORDER: Planet[] = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"];
export const VIMSHOTTARI_YEARS: Record<Planet, number> = {
  Ketu: 7, Venus: 20, Sun: 6, Moon: 10, Mars: 7, Rahu: 18, Jupiter: 16, Saturn: 19, Mercury: 17,
};

export const EXALTATION: Partial<Record<Planet, { sign: number; deg: number }>> = {
  Sun: { sign: 0, deg: 10 }, Moon: { sign: 1, deg: 3 }, Mars: { sign: 9, deg: 28 }, Mercury: { sign: 5, deg: 15 },
  Jupiter: { sign: 3, deg: 5 }, Venus: { sign: 11, deg: 27 }, Saturn: { sign: 6, deg: 20 },
};
export const OWN_SIGNS: Partial<Record<Planet, number[]>> = {
  Sun: [4], Moon: [3], Mars: [0, 7], Mercury: [2, 5], Jupiter: [8, 11], Venus: [1, 6], Saturn: [9, 10],
};
export const MOOLATRIKONA: Partial<Record<Planet, { sign: number; from: number; to: number }>> = {
  Sun: { sign: 4, from: 0, to: 20 }, Moon: { sign: 1, from: 3, to: 30 }, Mars: { sign: 0, from: 0, to: 12 },
  Mercury: { sign: 5, from: 15, to: 20 }, Jupiter: { sign: 8, from: 0, to: 10 }, Venus: { sign: 6, from: 0, to: 15 },
  Saturn: { sign: 10, from: 0, to: 20 },
};

/** Naisargika (natural) friendship — Brihat Parashara Hora Shastra. */
export const NATURAL_RELATIONS: Record<string, { friends: Planet[]; neutral: Planet[]; enemies: Planet[] }> = {
  Sun: { friends: ["Moon", "Mars", "Jupiter"], neutral: ["Mercury"], enemies: ["Venus", "Saturn"] },
  Moon: { friends: ["Sun", "Mercury"], neutral: ["Mars", "Jupiter", "Venus", "Saturn"], enemies: [] },
  Mars: { friends: ["Sun", "Moon", "Jupiter"], neutral: ["Venus", "Saturn"], enemies: ["Mercury"] },
  Mercury: { friends: ["Sun", "Venus"], neutral: ["Mars", "Jupiter", "Saturn"], enemies: ["Moon"] },
  Jupiter: { friends: ["Sun", "Moon", "Mars"], neutral: ["Saturn"], enemies: ["Mercury", "Venus"] },
  Venus: { friends: ["Mercury", "Saturn"], neutral: ["Mars", "Jupiter"], enemies: ["Sun", "Moon"] },
  Saturn: { friends: ["Mercury", "Venus"], neutral: ["Jupiter"], enemies: ["Sun", "Moon", "Mars"] },
};

/** Combustion orbs in degrees from the Sun (second value when retrograde). */
export const COMBUSTION_ORB: Partial<Record<Planet, [number, number]>> = {
  Moon: [12, 12], Mars: [17, 17], Mercury: [14, 12], Jupiter: [11, 11], Venus: [10, 8], Saturn: [15, 15],
};

export const ZODIAC_GLYPH = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"].map((g) => g + "\uFE0E"); // text presentation, not emoji
