/**
 * Kundli (birth chart) engine — astronomical positions + Parashari rules.
 * Houses are whole-sign from the Lagna (default in most Indian software).
 */
import {
  COMBUSTION_ORB, EXALTATION, MOOLATRIKONA, NAKSHATRAS, NATURAL_RELATIONS, OWN_SIGNS, PLANETS, RASHIS, type Planet,
} from "./constants";
import { VARGAS, VARGA_KEYS } from "./divisional";
import { vimshottari } from "./dasha";
import { ENGINE_VERSION, ascendant, ayanamsa, dailyMotion, norm360, siderealLongitude, type AyanamsaId, type NodeType } from "./ephemeris";
import { findCrossing } from "./search";
import { localToUtc } from "./time";

export interface BirthInput {
  name?: string;
  date: string; // YYYY-MM-DD local
  time: string; // HH:mm or HH:mm:ss local
  tz: string; // IANA
  lat: number;
  lon: number;
  place?: string;
  gender?: "male" | "female" | "other";
  ayanamsa?: AyanamsaId;
  node?: NodeType;
}

export interface PlanetInfo {
  planet: Planet; lon: number; sign: number; signName: string; degree: number; nakshatra: string; nakshatraIndex: number;
  nakshatraLord: Planet; pada: number; house: number; speed: number; retrograde: boolean; combust: boolean; dignity: Dignity;
}
export interface HouseInfo { house: number; sign: number; signName: string; lord: Planet; lordHouse: number; occupants: Planet[] }

export type Dignity = "Exalted" | "Debilitated" | "Moolatrikona" | "Own sign" | "Friendly" | "Neutral" | "Enemy" | "—";

export function dignityOf(planet: Planet, lon: number): Dignity {
  if (planet === "Rahu" || planet === "Ketu") return "—";
  const sign = Math.floor(lon / 30);
  const deg = lon % 30;
  const ex = EXALTATION[planet]!;
  if (ex.sign === sign) return "Exalted";
  if ((ex.sign + 6) % 12 === sign) return "Debilitated";
  const mt = MOOLATRIKONA[planet];
  if (mt && mt.sign === sign && deg >= mt.from && deg < mt.to) return "Moolatrikona";
  if (OWN_SIGNS[planet]!.includes(sign)) return "Own sign";
  const lord = RASHIS[sign].lord;
  const rel = NATURAL_RELATIONS[planet];
  if (rel.friends.includes(lord)) return "Friendly";
  if (rel.enemies.includes(lord)) return "Enemy";
  return "Neutral";
}

/** Graha drishti: houses counted from the planet (inclusive) that it aspects. */
export const ASPECT_OFFSETS: Partial<Record<Planet, number[]>> = {
  Sun: [7], Moon: [7], Mercury: [7], Venus: [7], Mars: [4, 7, 8], Jupiter: [5, 7, 9], Saturn: [3, 7, 10],
};
const aspectsSign = (p: Planet, from: number, target: number) =>
  (ASPECT_OFFSETS[p] ?? []).includes(((target - from + 12) % 12) + 1);

const houseFrom = (fromSign: number, sign: number) => ((sign - fromSign + 12) % 12) + 1;

export function computeKundli(input: BirthInput, now = new Date()) {
  const ayId = input.ayanamsa ?? "lahiri";
  const opts = { ayanamsa: ayId, node: input.node ?? "mean" } as const;
  const utc = localToUtc(input.date, input.time, input.tz);
  const asc = ascendant(utc, input.lat, input.lon, opts);
  const lagnaSign = Math.floor(asc.ascendant / 30);

  const describe = (lon: number) => {
    const nak = Math.floor(lon / (360 / 27));
    return {
      lon,
      sign: Math.floor(lon / 30),
      signName: RASHIS[Math.floor(lon / 30)].en,
      degree: lon % 30,
      nakshatra: NAKSHATRAS[nak].en,
      nakshatraIndex: nak,
      nakshatraLord: NAKSHATRAS[nak].lord,
      pada: Math.floor((lon % (360 / 27)) / (360 / 108)) + 1,
    };
  };

  const sunLon = siderealLongitude("Sun", utc, opts);
  const planets: PlanetInfo[] = PLANETS.map((p) => {
    const lon = siderealLongitude(p, utc, opts);
    const speed = dailyMotion(p, utc, opts);
    const d = describe(lon);
    const orb = COMBUSTION_ORB[p];
    const retro = p === "Rahu" || p === "Ketu" ? true : speed < 0;
    const distSun = Math.abs(((lon - sunLon + 540) % 360) - 180);
    return {
      planet: p,
      ...d,
      house: houseFrom(lagnaSign, d.sign),
      speed,
      retrograde: retro,
      combust: orb ? distSun <= orb[retro ? 1 : 0] : false,
      dignity: dignityOf(p, lon),
    };
  });
  const byName = Object.fromEntries(planets.map((p) => [p.planet, p])) as Record<Planet, (typeof planets)[number]>;

  const houses: HouseInfo[] = Array.from({ length: 12 }, (_, i) => {
    const sign = (lagnaSign + i) % 12;
    const lord = RASHIS[sign].lord;
    return {
      house: i + 1,
      sign,
      signName: RASHIS[sign].en,
      lord,
      lordHouse: byName[lord].house,
      occupants: planets.filter((p) => p.sign === sign).map((p) => p.planet),
    };
  });

  const divisional = Object.fromEntries(
    VARGA_KEYS.map((k) => [
      k,
      {
        name: VARGAS[k].name,
        area: VARGAS[k].area,
        ascendant: VARGAS[k].fn(asc.ascendant),
        planets: Object.fromEntries(planets.map((p) => [p.planet, VARGAS[k].fn(p.lon)])) as Record<Planet, number>,
      },
    ]),
  );

  const aspects = planets
    .filter((p) => ASPECT_OFFSETS[p.planet])
    .map((p) => ({
      planet: p.planet,
      houses: ASPECT_OFFSETS[p.planet]!.map((o) => ((p.house - 1 + o - 1) % 12) + 1),
      planetsAspected: planets.filter((q) => q.planet !== p.planet && aspectsSign(p.planet, p.sign, q.sign)).map((q) => q.planet),
    }));

  const conjunctions = houses.filter((h) => h.occupants.length > 1).map((h) => ({ house: h.house, sign: h.signName, planets: h.occupants }));

  const moon = byName.Moon;
  const dasha = vimshottari(moon.lon, utc, now);
  const yogas = detectYogas(planets, houses, lagnaSign);
  const doshas = detectDoshas(planets, lagnaSign);
  const sadeSati = sadeSatiPeriods(moon.sign, utc, now, opts);

  return {
    meta: {
      name: input.name ?? null,
      birth: { date: input.date, time: input.time, tz: input.tz, utc: utc.toISOString(), lat: input.lat, lon: input.lon, place: input.place ?? null },
      ayanamsa: ayId,
      ayanamsaValue: ayanamsa(utc, ayId),
      node: opts.node,
      houseSystem: "Whole sign",
      engine: ENGINE_VERSION,
      computedAt: new Date().toISOString(),
    },
    ascendant: { ...describe(asc.ascendant), midheaven: asc.midheaven, lord: RASHIS[lagnaSign].lord },
    planets,
    houses,
    divisional,
    aspects,
    conjunctions,
    dasha,
    yogas,
    doshas,
    sadeSati,
    summary: {
      lagna: RASHIS[lagnaSign].en,
      rashi: moon.signName,
      nakshatra: `${moon.nakshatra} (pada ${moon.pada})`,
      sunSign: byName.Sun.signName,
    },
  };
}

type P = PlanetInfo;
type H = HouseInfo;

export interface YogaResult {
  name: string;
  present: boolean;
  category: "Raja" | "Dhana" | "Mahapurusha" | "Lunar" | "Solar" | "Cancellation" | "Other";
  reason: string;
}

function detectYogas(planets: P[], houses: H[], lagnaSign: number): YogaResult[] {
  const by = Object.fromEntries(planets.map((p) => [p.planet, p])) as Record<Planet, P>;
  const moon = by.Moon;
  const kendra = [1, 4, 7, 10];
  const lordOf = (h: number) => houses[h - 1].lord;
  const out: YogaResult[] = [];

  const jupFromMoon = houseFrom(moon.sign, by.Jupiter.sign);
  out.push({
    name: "Gajakesari Yoga", category: "Lunar", present: kendra.includes(jupFromMoon),
    reason: `Jupiter is in house ${jupFromMoon} from the Moon (kendra required: 1, 4, 7 or 10).`,
  });
  out.push({
    name: "Budhaditya Yoga", category: "Solar", present: by.Sun.sign === by.Mercury.sign,
    reason: `Sun in ${by.Sun.signName}, Mercury in ${by.Mercury.signName}.`,
  });
  out.push({
    name: "Chandra-Mangala Yoga", category: "Dhana", present: by.Moon.sign === by.Mars.sign,
    reason: `Moon in ${by.Moon.signName}, Mars in ${by.Mars.signName}.`,
  });

  const mahapurusha: [Planet, string][] = [["Mars", "Ruchaka"], ["Mercury", "Bhadra"], ["Jupiter", "Hamsa"], ["Venus", "Malavya"], ["Saturn", "Shasha"]];
  for (const [pl, name] of mahapurusha) {
    const p = by[pl];
    const strong = ["Exalted", "Own sign", "Moolatrikona"].includes(p.dignity);
    out.push({
      name: `${name} Yoga`, category: "Mahapurusha", present: strong && kendra.includes(p.house),
      reason: `${pl} is ${p.dignity.toLowerCase()} in house ${p.house} (needs own/exalted sign in a kendra from Lagna).`,
    });
  }

  // Association = conjunction, mutual aspect, or sign exchange (parivartana)
  const associated = (a: Planet, b: Planet) => {
    if (a === b) return false;
    const pa = by[a], pb = by[b];
    if (pa.sign === pb.sign) return "conjunction";
    if (aspectsSign(a, pa.sign, pb.sign) && aspectsSign(b, pb.sign, pa.sign)) return "mutual aspect";
    if (RASHIS[pa.sign].lord === b && RASHIS[pb.sign].lord === a) return "sign exchange";
    return false;
  };

  // Raja Yoga: kendra lord with trikona lord
  const raja: string[] = [];
  for (const k of [4, 7, 10]) for (const t of [5, 9]) {
    const a = lordOf(k), b = lordOf(t);
    if (a === b) raja.push(`${a} owns both house ${k} and ${t} (Yogakaraka)`);
    else { const how = associated(a, b); if (how) raja.push(`${k}th lord ${a} and ${t}th lord ${b} by ${how}`); }
  }
  out.push({ name: "Raja Yoga (Kendra–Trikona)", category: "Raja", present: raja.length > 0, reason: raja.length ? raja.join("; ") + "." : "No kendra lord is associated with a trikona lord." });

  // Dhana Yoga: wealth lords (2, 11) with 1, 5, 9 lords
  const dhana: string[] = [];
  for (const w of [2, 11]) for (const t of [1, 5, 9]) {
    const a = lordOf(w), b = lordOf(t);
    if (a === b) continue;
    const how = associated(a, b);
    if (how) dhana.push(`${w}th lord ${a} with ${t}th lord ${b} by ${how}`);
  }
  out.push({ name: "Dhana Yoga", category: "Dhana", present: dhana.length > 0, reason: dhana.length ? [...new Set(dhana)].join("; ") + "." : "Wealth lords (2nd, 11th) are not associated with 1st, 5th or 9th lords." });

  // Neecha Bhanga Raja Yoga (principal classical conditions)
  for (const p of planets.filter((q) => q.dignity === "Debilitated")) {
    const debSignLord = RASHIS[p.sign].lord;
    const exSign = EXALTATION[p.planet]!.sign;
    const exSignLord = RASHIS[exSign].lord;
    const reasons: string[] = [];
    const inKendra = (pl: Planet) => kendra.includes(by[pl].house) || kendra.includes(houseFrom(moon.sign, by[pl].sign));
    if (inKendra(debSignLord)) reasons.push(`${debSignLord} (lord of the debilitation sign) is in a kendra from Lagna or Moon`);
    if (inKendra(exSignLord)) reasons.push(`${exSignLord} (lord of its exaltation sign) is in a kendra from Lagna or Moon`);
    if (by[debSignLord].sign === p.sign) reasons.push(`${debSignLord} is conjunct the debilitated planet`);
    out.push({
      name: `Neecha Bhanga Raja Yoga (${p.planet})`, category: "Cancellation", present: reasons.length > 0,
      reason: reasons.length ? reasons.join("; ") + "." : `${p.planet} is debilitated with no classical cancellation found.`,
    });
  }

  // Kemadruma: no planet (except Sun and nodes) in 2nd or 12th from Moon
  const flank = planets.filter((p) => !["Sun", "Moon", "Rahu", "Ketu"].includes(p.planet) && [2, 12].includes(houseFrom(moon.sign, p.sign)));
  out.push({ name: "Kemadruma Yoga", category: "Lunar", present: flank.length === 0, reason: flank.length ? `Cancelled: ${flank.map((p) => p.planet).join(", ")} flank the Moon.` : "No planet occupies the 2nd or 12th from the Moon." });

  void lagnaSign;
  return out;
}

const KAAL_SARP_NAMES = ["Anant", "Kulik", "Vasuki", "Shankhpal", "Padma", "Mahapadma", "Takshak", "Karkotak", "Shankhachud", "Ghatak", "Vishdhar", "Sheshnag"];

function detectDoshas(planets: P[], lagnaSign: number) {
  const by = Object.fromEntries(planets.map((p) => [p.planet, p])) as Record<Planet, P>;
  const marsHouses = [1, 2, 4, 7, 8, 12];
  const mars = by.Mars;
  const fromLagna = mars.house;
  const fromMoon = houseFrom(by.Moon.sign, mars.sign);
  const fromVenus = houseFrom(by.Venus.sign, mars.sign);
  const exceptions: string[] = [];
  if (["Own sign", "Exalted", "Moolatrikona"].includes(mars.dignity)) exceptions.push(`Mars is ${mars.dignity.toLowerCase()}`);
  if (aspectsSign("Jupiter", by.Jupiter.sign, mars.sign) || by.Jupiter.sign === mars.sign) exceptions.push("Jupiter conjoins or aspects Mars");
  const manglikLagna = marsHouses.includes(fromLagna);
  const manglikMoon = marsHouses.includes(fromMoon);

  // Kaal Sarp: all seven grahas within the Rahu→Ketu arc, or all within Ketu→Rahu
  const rahu = by.Rahu.lon;
  const seven = planets.filter((p) => !["Rahu", "Ketu"].includes(p.planet));
  const arc = (lon: number) => norm360(lon - rahu);
  const allOneSide = seven.every((p) => arc(p.lon) < 180) || seven.every((p) => arc(p.lon) > 180);
  const rahuHouse = by.Rahu.house;

  return {
    manglik: {
      present: manglikLagna || manglikMoon,
      fromLagna: { house: fromLagna, present: manglikLagna },
      fromMoon: { house: fromMoon, present: manglikMoon },
      fromVenus: { house: fromVenus, present: marsHouses.includes(fromVenus) },
      severity: manglikLagna && manglikMoon ? "High" : manglikLagna || manglikMoon ? "Mild" : "None",
      mitigations: exceptions,
      rule: "Mars in houses 1, 2, 4, 7, 8 or 12 from Lagna, Moon or Venus.",
    },
    kaalSarp: {
      present: allOneSide,
      type: allOneSide ? KAAL_SARP_NAMES[rahuHouse - 1] : null,
      direction: allOneSide ? (seven.every((p) => arc(p.lon) < 180) ? "Rahu→Ketu (Anuloma)" : "Ketu→Rahu (Viloma)") : null,
      rule: "All seven planets hemmed between Rahu and Ketu on one side of the nodal axis.",
    },
    lagnaSign,
  };
}

/** Saturn's transits through the 12th, 1st and 2nd from the natal Moon, ±3 years around birth to +100 years. */
export function sadeSatiPeriods(moonSign: number, birth: Date, now: Date, opts: { ayanamsa: AyanamsaId; node: NodeType }) {
  const satSign = (d: Date) => Math.floor(siderealLongitude("Saturn", d, opts) / 30);
  const phaseOf = (s: number) => {
    const h = houseFrom(moonSign, s);
    return h === 12 ? "Rising (12th)" : h === 1 ? "Peak (1st)" : h === 2 ? "Setting (2nd)" : null;
  };
  const step = 8 * 86400e3;
  const startT = birth.getTime() - 3 * 365.25 * 86400e3;
  const endT = birth.getTime() + 100 * 365.25 * 86400e3;
  const segments: { phase: string; sign: string; start: string; end: string }[] = [];
  let t = startT;
  let cur = satSign(new Date(t));
  let segStart = t;
  const refine = (a: number, b: number, from: number) => {
    // bisection on sign change
    while (b - a > 3600e3) {
      const m = (a + b) / 2;
      if (satSign(new Date(m)) === from) a = m; else b = m;
    }
    return b;
  };
  while (t < endT) {
    const nt = t + step;
    const s = satSign(new Date(nt));
    if (s !== cur) {
      const change = refine(t, nt, cur);
      const ph = phaseOf(cur);
      if (ph) segments.push({ phase: ph, sign: RASHIS[cur].en, start: new Date(segStart).toISOString(), end: new Date(change).toISOString() });
      cur = s;
      segStart = change;
    }
    t = nt;
  }
  // Group consecutive segments into cycles (a gap > 2 years starts a new cycle)
  const cycles: { start: string; end: string; segments: typeof segments }[] = [];
  for (const seg of segments) {
    const last = cycles[cycles.length - 1];
    if (last && Date.parse(seg.start) - Date.parse(last.end) < 2 * 365.25 * 86400e3) {
      last.segments.push(seg);
      last.end = seg.end;
    } else cycles.push({ start: seg.start, end: seg.end, segments: [seg] });
  }
  const nowSign = satSign(now);
  const currentPhase = phaseOf(nowSign);
  // Dhaiya (Kantaka/Ashtama Shani): Saturn in 4th or 8th from Moon
  const hNow = houseFrom(moonSign, nowSign);
  return {
    cycles,
    current: { active: !!currentPhase, phase: currentPhase, saturnSign: RASHIS[nowSign].en, dhaiya: hNow === 4 || hNow === 8 ? `Saturn in ${hNow}th from Moon` : null },
  };
}

/** Current transits (Gochar) relative to a natal Moon and Lagna. */
export function gochar(moonSign: number, lagnaSign: number, at = new Date(), opts: { ayanamsa?: AyanamsaId; node?: NodeType } = {}) {
  return PLANETS.map((p) => {
    const lon = siderealLongitude(p, at, opts);
    const sign = Math.floor(lon / 30);
    const node = p === "Rahu" || p === "Ketu";
    const nextIngress = node
      ? findCrossing((d) => norm360(360 - siderealLongitude(p, d, opts)), norm360(360 - sign * 30), at, 1, 72, 600)
      : findCrossing((d) => siderealLongitude(p, d, opts), ((sign + 1) % 12) * 30, at, 1, p === "Moon" ? 6 : 48, p === "Moon" ? 4 : 1200);
    return {
      planet: p,
      lon,
      sign,
      signName: RASHIS[sign].en,
      degree: lon % 30,
      retrograde: p === "Rahu" || p === "Ketu" ? true : dailyMotion(p, at, opts) < 0,
      houseFromMoon: houseFrom(moonSign, sign),
      houseFromLagna: houseFrom(lagnaSign, sign),
      nextSignChange: nextIngress?.toISOString() ?? null,
    };
  });
}

export type Kundli = ReturnType<typeof computeKundli>;
