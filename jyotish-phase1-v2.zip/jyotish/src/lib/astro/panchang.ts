/**
 * Panchang engine. Astronomical inputs come from ./ephemeris; the traditional
 * rules (segment sizes, weekday tables, month naming) are applied here and are
 * documented inline. Day boundary = local sunrise to next sunrise.
 */
import {
  AMRIT_GHATI, CHOGHADIYA, DUR_MUHURAT, FIXED_KARANAS, GULIKA_SEGMENT, HORA_ORDER, MASAS, MOVABLE_KARANAS,
  NAKSHATRAS, RAHU_KAAL_SEGMENT, RASHIS, RITUS, SAMVATSARAS, TITHIS, VARAS, VARJYAM_GHATI, YAMAGANDA_SEGMENT, YOGAS,
  INAUSPICIOUS_YOGAS, type Planet,
} from "./constants";
import {
  ENGINE_VERSION, ayanamsa, moonIllumination, moonPhaseAngle, nextNewMoon, norm360, prevNewMoon, searchRiseSet,
  siderealLongitude, type AyanamsaId, type NodeType,
} from "./ephemeris";
import { findCrossing } from "./search";
import { addDays, localIsoDate, localMidnight, weekdayIndex } from "./time";

export interface PanchangInput {
  date: string; // YYYY-MM-DD, civil date at the location
  lat: number;
  lon: number;
  tz: string; // IANA zone
  elevation?: number;
  ayanamsa?: AyanamsaId;
  node?: NodeType;
}

export interface Span {
  index: number;
  name: string;
  nameHi: string;
  start: string | null;
  end: string | null;
  extra?: Record<string, unknown>;
}
export interface Window {
  name: string;
  start: string;
  end: string;
  quality?: string;
  note?: string;
}

const iso = (d: Date | null) => (d ? d.toISOString() : null);
const add = (d: Date, ms: number) => new Date(d.getTime() + ms);

// --- Angular quantities -----------------------------------------------------
const sunSid = (d: Date) => siderealLongitude("Sun", d);
const moonSid = (d: Date) => siderealLongitude("Moon", d);
/** Moon − Sun elongation; ayanamsa-independent. */
export const elongation = (d: Date) => norm360(moonSid(d) - sunSid(d));
const yogaAngle = (d: Date) => norm360(moonSid(d) + sunSid(d));

export const tithiIndexAt = (d: Date) => Math.floor(elongation(d) / 12);
export const nakshatraIndexAt = (d: Date) => Math.floor(moonSid(d) / (360 / 27));

export function karanaName(k: number) {
  // 60 half-tithis per synodic month
  if (k === 0) return FIXED_KARANAS[3];
  if (k >= 57) return FIXED_KARANAS[k - 57];
  return MOVABLE_KARANAS[(k - 1) % 7];
}

/** All segments of `size` degrees of `fn` that overlap [from, to). */
function spans(fn: (d: Date) => number, size: number, from: Date, to: Date, step: number) {
  const out: { index: number; start: Date | null; end: Date | null }[] = [];
  const count = Math.round(360 / size);
  let idx = Math.floor(fn(from) / size);
  let start = findCrossing(fn, idx * size, from, -1, step, 3);
  let guard = 0;
  while (guard++ < 8) {
    const end = findCrossing(fn, ((idx + 1) % count) * size, start ?? from, 1, step, 3);
    out.push({ index: idx, start, end });
    if (!end || end >= to) break;
    start = end;
    idx = (idx + 1) % count;
  }
  return out;
}

function divideInterval(start: Date, end: Date, parts: number) {
  const len = (end.getTime() - start.getTime()) / parts;
  return Array.from({ length: parts }, (_, i) => ({ start: add(start, i * len), end: add(start, (i + 1) * len) }));
}

// --- Lunar month and year ---------------------------------------------------
function amantaMonthAt(d: Date) {
  const nm = prevNewMoon(d);
  const nextNm = nextNewMoon(add(d, 60e3));
  const r1 = Math.floor(sunSid(nm) / 30);
  const r2 = Math.floor(sunSid(nextNm) / 30);
  return { index: (r1 + 1) % 12, adhik: r1 === r2, newMoon: nm, nextNewMoon: nextNm };
}

function hinduYear(d: Date, amantaIndex: number) {
  // Walk back to the new moon that began Chaitra (non-adhik) of the current year.
  let nm = prevNewMoon(d);
  let monthsBack = 0;
  let m = amantaMonthAt(add(nm, 86400e3));
  while (!(m.index === 0 && !m.adhik) && monthsBack < 14) {
    nm = prevNewMoon(add(nm, -86400e3));
    m = amantaMonthAt(add(nm, 86400e3));
    monthsBack++;
  }
  const gregYear = nm.getUTCFullYear();
  const shaka = gregYear - 78;
  const vikram = shaka + 135;
  return {
    shaka,
    vikramChaitradi: vikram,
    // Gujarat & parts of Rajasthan begin the Vikram year at Kartika Shukla Pratipada
    vikramKartikadi: amantaIndex >= 7 ? vikram : vikram - 1,
    kaliYuga: shaka + 3179,
    samvatsara: SAMVATSARAS[(shaka + 11) % 60],
    chaitraStart: nm.toISOString(),
  };
}

// --- Main -------------------------------------------------------------------
export function computePanchang(input: PanchangInput) {
  const { date, lat, lon, tz, elevation = 0 } = input;
  const ayId = input.ayanamsa ?? "lahiri";
  const midnight = localMidnight(date, tz);

  const sunrise = searchRiseSet("Sun", "rise", midnight, lat, lon, elevation);
  if (!sunrise) throw new Error("No sunrise at this location on this date (polar day/night). Panchang cannot be computed.");
  const sunset = searchRiseSet("Sun", "set", sunrise, lat, lon, elevation)!;
  const nextSunrise = searchRiseSet("Sun", "rise", add(sunset, 60e3), lat, lon, elevation)!;
  const prevSunset = searchRiseSet("Sun", "set", add(sunrise, -26 * 3600e3), lat, lon, elevation)!;
  const nextMidnight = localMidnight(addDays(date, 1), tz);
  const moonriseRaw = searchRiseSet("Moon", "rise", midnight, lat, lon, elevation, 1.1);
  const moonsetRaw = searchRiseSet("Moon", "set", midnight, lat, lon, elevation, 1.1);
  const moonrise = moonriseRaw && moonriseRaw < nextMidnight ? moonriseRaw : null;
  const moonset = moonsetRaw && moonsetRaw < nextMidnight ? moonsetRaw : null;

  const wd = weekdayIndex(date);
  const vara = VARAS[wd];

  // Five limbs across the Hindu day (sunrise → next sunrise)
  const tithiSpans = spans(elongation, 12, sunrise, nextSunrise, 4).map((s): Span => {
    const t = TITHIS[s.index];
    return { index: s.index, name: t.en, nameHi: t.hi, start: iso(s.start), end: iso(s.end), extra: { paksha: t.paksha, number: t.number } };
  });
  const nakSpans = spans(moonSid, 360 / 27, sunrise, nextSunrise, 4);
  const nakshatras = nakSpans.map((s): Span => {
    const n = NAKSHATRAS[s.index];
    return { index: s.index, name: n.en, nameHi: n.hi, start: iso(s.start), end: iso(s.end), extra: { lord: n.lord, deity: n.deity } };
  });
  const yogas = spans(yogaAngle, 360 / 27, sunrise, nextSunrise, 4).map((s): Span => ({
    index: s.index, name: YOGAS[s.index].en, nameHi: YOGAS[s.index].hi, start: iso(s.start), end: iso(s.end),
    extra: { auspicious: !INAUSPICIOUS_YOGAS.has(s.index) },
  }));
  const karanas = spans(elongation, 6, sunrise, nextSunrise, 3).map((s): Span => {
    const k = karanaName(s.index);
    return { index: s.index, name: k.en, nameHi: k.hi, start: iso(s.start), end: iso(s.end) };
  });

  const tithiAtSunrise = TITHIS[tithiSpans[0].index];
  const paksha = tithiAtSunrise.paksha;

  // Signs
  const moonSignSpans = spans(moonSid, 30, sunrise, nextSunrise, 6).map((s): Span => ({
    index: s.index, name: RASHIS[s.index].en, nameHi: RASHIS[s.index].hi, start: iso(s.start), end: iso(s.end),
  }));
  const sunSignIdx = Math.floor(sunSid(sunrise) / 30);
  const nextSankrantiAt = findCrossing(sunSid, ((sunSignIdx + 1) % 12) * 30, sunrise, 1, 24, 35);

  // Month & year
  const am = amantaMonthAt(sunrise);
  const purnimantaIndex = paksha === "Krishna" ? (am.index + 1) % 12 : am.index;
  const year = hinduYear(sunrise, am.index);

  // Day / night divisions
  const dayLen = sunset.getTime() - sunrise.getTime();
  const nightLen = nextSunrise.getTime() - sunset.getTime();
  const prevNightLen = sunrise.getTime() - prevSunset.getTime();
  const eighths = divideInterval(sunrise, sunset, 8);
  const seg = (n: number) => eighths[n - 1];
  const dayMuhurta = dayLen / 15;
  const nightMuhurta = nightLen / 15;

  const inauspicious: Window[] = [
    { name: "Rahu Kaal", ...isoWin(seg(RAHU_KAAL_SEGMENT[wd])) },
    { name: "Yamaganda", ...isoWin(seg(YAMAGANDA_SEGMENT[wd])) },
    { name: "Gulika Kaal", ...isoWin(seg(GULIKA_SEGMENT[wd])) },
    ...DUR_MUHURAT[wd].map((m) => {
      const night = typeof m === "string";
      const n = night ? Number(m.slice(1)) : m;
      const base = night ? sunset : sunrise;
      const len = night ? nightMuhurta : dayMuhurta;
      return { name: "Dur Muhurat", start: add(base, (n - 1) * len).toISOString(), end: add(base, n * len).toISOString() };
    }),
  ];

  // Varjyam and Amrit Kaal from nakshatra spans (4 ghatis scaled to nakshatra length)
  const varjyam: Window[] = [];
  const amritKaal: Window[] = [];
  for (const s of nakSpans) {
    if (!s.start || !s.end) continue;
    const L = s.end.getTime() - s.start.getTime();
    const mk = (gh: number) => ({ start: add(s.start!, (gh / 60) * L), end: add(s.start!, ((gh + 4) / 60) * L) });
    const v = mk(VARJYAM_GHATI[s.index]);
    const a = mk(AMRIT_GHATI[s.index]);
    if (v.end > sunrise && v.start < nextSunrise) varjyam.push({ name: "Varjyam", ...isoWin(v), note: NAKSHATRAS[s.index].en });
    if (a.end > sunrise && a.start < nextSunrise) amritKaal.push({ name: "Amrit Kaal", ...isoWin(a), note: NAKSHATRAS[s.index].en });
  }

  const auspicious: Window[] = [
    {
      name: "Abhijit Muhurat",
      start: add(sunrise, 7 * dayMuhurta).toISOString(),
      end: add(sunrise, 8 * dayMuhurta).toISOString(),
      note: wd === 3 ? "Traditionally avoided on Wednesday" : undefined,
    },
    {
      name: "Brahma Muhurat",
      start: add(sunrise, -2 * (prevNightLen / 15)).toISOString(),
      end: add(sunrise, -(prevNightLen / 15)).toISOString(),
    },
    ...amritKaal,
  ];

  const choghadiya = {
    day: divideInterval(sunrise, sunset, 8).map((w, i) => {
      const startIdx = CHOGHADIYA.dayOrder.indexOf(CHOGHADIYA.dayStart[wd]);
      const name = CHOGHADIYA.dayOrder[(startIdx + i) % 7];
      return { name, quality: CHOGHADIYA.quality[name], ...isoWin(w) };
    }),
    night: divideInterval(sunset, nextSunrise, 8).map((w, i) => {
      const startIdx = CHOGHADIYA.nightOrder.indexOf(CHOGHADIYA.nightStart[wd]);
      const name = CHOGHADIYA.nightOrder[(startIdx + i) % 7];
      return { name, quality: CHOGHADIYA.quality[name], ...isoWin(w) };
    }),
  };

  const firstHora = HORA_ORDER.indexOf(vara.lord);
  const hora = [...divideInterval(sunrise, sunset, 12), ...divideInterval(sunset, nextSunrise, 12)].map((w, i) => ({
    lord: HORA_ORDER[(firstHora + i) % 7] as Planet,
    period: i < 12 ? "day" : "night",
    ...isoWin(w),
  }));

  const phase = moonPhaseAngle(sunrise);
  const sunSidAtRise = sunSid(sunrise);

  return {
    meta: {
      date, lat, lon, tz, elevation,
      ayanamsa: ayId,
      ayanamsaValue: ayanamsa(sunrise, ayId),
      node: input.node ?? "mean",
      engine: ENGINE_VERSION,
      method: "Sidereal (nirayana) longitudes; sunrise-to-sunrise day; Sun upper limb with standard refraction",
      monthSystems: ["amanta", "purnimanta"],
      computedAt: new Date().toISOString(),
    },
    sun: {
      sunrise: iso(sunrise), sunset: iso(sunset), nextSunrise: iso(nextSunrise),
      sign: { index: sunSignIdx, name: RASHIS[sunSignIdx].en, nameHi: RASHIS[sunSignIdx].hi },
      nextSankranti: nextSankrantiAt ? { at: iso(nextSankrantiAt), sign: RASHIS[(sunSignIdx + 1) % 12].en } : null,
      ayana: sunSidAtRise >= 270 || sunSidAtRise < 90 ? "Uttarayana" : "Dakshinayana",
      dayLengthMinutes: Math.round(dayLen / 60000),
    },
    moon: {
      moonrise: iso(moonrise), moonset: iso(moonset),
      phaseAngle: phase, illumination: moonIllumination(sunrise),
      phaseName: phaseName(phase),
      signs: moonSignSpans,
    },
    vara: { index: wd, name: vara.en, nameHi: vara.hi, english: vara.english, lord: vara.lord },
    tithi: tithiSpans,
    nakshatra: nakshatras,
    yoga: yogas,
    karana: karanas,
    paksha,
    masa: {
      amanta: { ...MASAS[am.index], adhik: am.adhik },
      purnimanta: { ...MASAS[purnimantaIndex], adhik: am.adhik },
    },
    ritu: RITUS[Math.floor(am.index / 2)],
    samvat: year,
    auspicious,
    inauspicious: [...inauspicious, ...varjyam],
    choghadiya,
    hora,
  };
}

function isoWin(w: { start: Date; end: Date }) {
  return { start: w.start.toISOString(), end: w.end.toISOString() };
}

function phaseName(angle: number) {
  const names = ["New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous", "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent"];
  return names[Math.floor(((angle + 22.5) % 360) / 45)];
}

export type Panchang = ReturnType<typeof computePanchang>;

/** Lightweight sunrise snapshot used by calendars (tithi/nakshatra prevailing at sunrise). */
export function sunriseSnapshot(date: string, lat: number, lon: number, tz: string) {
  const midnight = localMidnight(date, tz);
  const sunrise = searchRiseSet("Sun", "rise", midnight, lat, lon);
  if (!sunrise) return null;
  const sunset = searchRiseSet("Sun", "set", sunrise, lat, lon)!;
  return {
    date,
    sunrise,
    sunset,
    tithiAtSunrise: tithiIndexAt(sunrise),
    tithiAtSunset: tithiIndexAt(sunset),
    nakshatraAtSunrise: nakshatraIndexAt(sunrise),
    sunSign: Math.floor(sunSid(sunrise) / 30),
    localDate: localIsoDate(sunrise, tz),
  };
}
