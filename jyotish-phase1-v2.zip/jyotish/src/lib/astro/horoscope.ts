/**
 * Transit-based (Gochara) horoscope for the 12 Moon signs. Text is composed
 * from classical Gochara phala rules for each planet's house from the natal
 * Moon — deterministic and traceable, never random.
 */
import { RASHIS, type Planet } from "./constants";
import { siderealLongitude } from "./ephemeris";

/** Houses (from natal Moon) where a transiting planet is classically favourable. */
const FAVOURABLE: Partial<Record<Planet, number[]>> = {
  Moon: [1, 3, 6, 7, 10, 11],
  Sun: [3, 6, 10, 11],
  Mars: [3, 6, 11],
  Mercury: [2, 4, 6, 8, 10, 11],
  Jupiter: [2, 5, 7, 9, 11],
  Venus: [1, 2, 3, 4, 5, 8, 9, 11, 12],
  Saturn: [3, 6, 11],
};

export const MOON_TRANSIT_TEXT: string[] = [
  "The Moon transits your own sign, lifting mood and visibility. A good day for personal initiatives and looking after yourself.",
  "The Moon moves through your 2nd house of speech and resources. Watch spending and choose words carefully; family matters need patience.",
  "The Moon in your 3rd house favours courage, short trips and communication. Effort pays off and siblings or colleagues are supportive.",
  "The Moon in your 4th house turns attention home. Emotional sensitivity runs high; keep plans simple and avoid unnecessary arguments.",
  "The Moon in your 5th house can scatter focus. Avoid speculation; channel energy into study, creativity or time with children.",
  "The Moon in your 6th house helps you overcome obstacles and clear pending work. Health routines and competitive tasks go well.",
  "The Moon in your 7th house brings partners and the public into focus. Cooperation, meetings and agreements are favoured.",
  "The Moon transits your 8th house (Chandrashtama). Tradition advises caution: postpone important beginnings, rest well and avoid risks.",
  "The Moon in your 9th house can feel restless. Seek guidance from elders, keep faith practices, and defer long journeys if possible.",
  "The Moon in your 10th house supports work and recognition. A productive day for professional tasks and responsibilities.",
  "The Moon in your 11th house brings gains and friendly support. Networking, requests and financial matters tend to go smoothly.",
  "The Moon in your 12th house raises expenses and tiredness. Favour rest, charity and quiet reflection over new commitments.",
];

const PLANET_TOPIC: Partial<Record<Planet, string>> = {
  Sun: "authority and vitality", Mars: "energy and drive", Mercury: "communication and trade",
  Jupiter: "growth and guidance", Venus: "relationships and comforts", Saturn: "discipline and long-term effort",
};

const houseFrom = (from: number, to: number) => ((to - from + 12) % 12) + 1;

export function horoscopeFor(moonSign: number, at: Date) {
  const positions = (["Moon", "Sun", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"] as Planet[]).map((p) => {
    const sign = Math.floor(siderealLongitude(p, at) / 30);
    const house = houseFrom(moonSign, sign);
    return { planet: p, sign: RASHIS[sign].en, house, favourable: FAVOURABLE[p]!.includes(house) };
  });
  const moon = positions[0];
  const slow = positions.filter((p) => ["Jupiter", "Saturn"].includes(p.planet));
  const fast = positions.filter((p) => ["Sun", "Mars", "Mercury", "Venus"].includes(p.planet));

  const score = positions.reduce((s, p) => s + (p.favourable ? (p.planet === "Moon" ? 2 : 1) : 0), 0);
  const line = (p: (typeof positions)[number]) =>
    `${p.planet} in your ${ordinal(p.house)} house is ${p.favourable ? "supportive" : "challenging"} for ${PLANET_TOPIC[p.planet]}.`;

  return {
    sign: RASHIS[moonSign].en,
    signHi: RASHIS[moonSign].hi,
    western: RASHIS[moonSign].western,
    chandrashtama: moon.house === 8,
    daily: MOON_TRANSIT_TEXT[moon.house - 1],
    weekly: fast.map(line).join(" "),
    yearly: slow.map(line).join(" "),
    rating: Math.max(1, Math.min(5, Math.round((score / 8) * 5))),
    positions,
  };
}

export function ordinal(n: number) {
  return n + (n === 1 ? "st" : n === 2 ? "nd" : n === 3 ? "rd" : "th");
}
