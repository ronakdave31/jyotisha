import { DateTime, IANAZone } from "luxon";

export function isValidZone(tz: string) {
  return IANAZone.isValidZone(tz);
}

/** UTC instant of local midnight starting `isoDate` (YYYY-MM-DD) in zone `tz`. */
export function localMidnight(isoDate: string, tz: string): Date {
  const dt = DateTime.fromISO(isoDate, { zone: tz }).startOf("day");
  if (!dt.isValid) throw new Error(`Invalid date ${isoDate} / zone ${tz}`);
  return dt.toJSDate();
}

/** Convert a local wall-clock birth time to a UTC instant. Handles DST via IANA rules. */
export function localToUtc(isoDate: string, time: string, tz: string): Date {
  const dt = DateTime.fromISO(`${isoDate}T${time}`, { zone: tz });
  if (!dt.isValid) throw new Error(`Invalid local time ${isoDate} ${time} ${tz}`);
  return dt.toJSDate();
}

export function weekdayIndex(isoDate: string): number {
  // Sunday = 0, independent of zone
  return DateTime.fromISO(isoDate, { zone: "UTC" }).weekday % 7;
}

export function todayIn(tz: string): string {
  return DateTime.now().setZone(tz).toISODate()!;
}

export function addDays(isoDate: string, n: number): string {
  return DateTime.fromISO(isoDate, { zone: "UTC" }).plus({ days: n }).toISODate()!;
}

export function fmtTime(d: Date | string | null | undefined, tz: string, refDate?: string): string {
  if (!d) return "—";
  const dt = DateTime.fromJSDate(typeof d === "string" ? new Date(d) : d).setZone(tz);
  const t = dt.toFormat("hh:mm a");
  if (refDate && dt.toISODate() !== refDate) return `${t}, ${dt.toFormat("d LLL")}`;
  return t;
}

export function fmtDate(isoDate: string, tz = "UTC", fmt = "cccc, d LLLL yyyy") {
  return DateTime.fromISO(isoDate, { zone: tz }).toFormat(fmt);
}

export function localIsoDate(d: Date, tz: string) {
  return DateTime.fromJSDate(d).setZone(tz).toISODate()!;
}
