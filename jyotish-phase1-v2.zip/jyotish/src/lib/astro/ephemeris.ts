/**
 * Astronomical layer. Computes positions only — no traditional interpretation.
 * Engine: Astronomy Engine (MIT licence), VSOP87/ELP-derived models, accuracy
 * well under 1 arcminute for the Sun, Moon and planets over 1700–2200 CE.
 *
 * Sidereal longitudes follow the Swiss Ephemeris convention: positions are
 * referred to the mean equinox of date (nutation removed) and a mean ayanamsa
 * is subtracted.
 */
import * as A from "astronomy-engine";
import type { Planet } from "./constants";

export const ENGINE_VERSION = "astronomy-engine@2.1.19";

export type AyanamsaId = "lahiri" | "raman" | "krishnamurti" | "tropical";
export type NodeType = "mean" | "true";

/** Reference epochs (JD TT) and values (deg), as defined in the Swiss Ephemeris. */
const AYANAMSA_DEF: Record<Exclude<AyanamsaId, "tropical">, { jd: number; value: number }> = {
  lahiri: { jd: 2435553.5, value: 23.245524743 }, // Indian Calendar Reform Committee, 21 Mar 1956
  raman: { jd: 2415020.0, value: 21.01444 },
  krishnamurti: { jd: 2415020.0, value: 22.363889 },
};

const J2000 = 2451545.0;

/** IAU 2006 general precession in longitude, arcseconds. */
function precessionArcsec(T: number) {
  return 5028.796195 * T + 1.1054348 * T * T + 0.00007964 * T ** 3 - 0.000023857 * T ** 4;
}

export function julianDayTT(date: Date): number {
  const t = A.MakeTime(date);
  return t.tt + J2000;
}

export function ayanamsa(date: Date, id: AyanamsaId = "lahiri"): number {
  if (id === "tropical") return 0;
  const def = AYANAMSA_DEF[id];
  const T = (julianDayTT(date) - J2000) / 36525;
  const T0 = (def.jd - J2000) / 36525;
  return def.value + (precessionArcsec(T) - precessionArcsec(T0)) / 3600;
}

export const norm360 = (x: number) => ((x % 360) + 360) % 360;
const rad = Math.PI / 180;

function nutationLon(date: Date) {
  return A.e_tilt(A.MakeTime(date)).dpsi / 3600;
}

const BODY: Partial<Record<Planet, A.Body>> = {
  Sun: A.Body.Sun, Moon: A.Body.Moon, Mars: A.Body.Mars, Mercury: A.Body.Mercury,
  Jupiter: A.Body.Jupiter, Venus: A.Body.Venus, Saturn: A.Body.Saturn,
};

/** Apparent geocentric tropical longitude, true equinox of date. */
function tropicalTrue(planet: Planet, date: Date): number {
  const t = A.MakeTime(date);
  if (planet === "Sun") return A.SunPosition(t).elon;
  if (planet === "Moon") return A.EclipticGeoMoon(t).lon;
  const vec = A.GeoVector(BODY[planet]!, t, true);
  return A.Ecliptic(vec).elon;
}

/** Lunar ascending node, tropical, mean equinox of date (Meeus ch. 47). */
function lunarNode(date: Date, type: NodeType): number {
  const T = (julianDayTT(date) - J2000) / 36525;
  const omega = 125.0445479 - 1934.1362891 * T + 0.0020754 * T * T + T ** 3 / 467441 - T ** 4 / 60616000;
  if (type === "mean") return norm360(omega);
  const D = (297.8501921 + 445267.1114034 * T) * rad;
  const M = (357.5291092 + 35999.0502909 * T) * rad;
  const Mp = (134.9633964 + 477198.8675055 * T) * rad;
  const F = (93.272095 + 483202.0175233 * T) * rad;
  return norm360(
    omega - 1.4979 * Math.sin(2 * (D - F)) - 0.15 * Math.sin(M) - 0.1226 * Math.sin(2 * D) +
      0.1176 * Math.sin(2 * F) - 0.0801 * Math.sin(2 * (Mp - F)),
  );
}

export interface CalcOptions {
  ayanamsa?: AyanamsaId;
  node?: NodeType;
}

/** Sidereal longitude in degrees [0, 360). */
export function siderealLongitude(planet: Planet, date: Date, opts: CalcOptions = {}): number {
  const ay = ayanamsa(date, opts.ayanamsa ?? "lahiri");
  if (planet === "Rahu" || planet === "Ketu") {
    const rahu = lunarNode(date, opts.node ?? "mean") - ay;
    return norm360(planet === "Rahu" ? rahu : rahu + 180);
  }
  return norm360(tropicalTrue(planet, date) - nutationLon(date) - ay);
}

/** Daily motion in degrees/day (negative = retrograde). Central difference over ±6h. */
export function dailyMotion(planet: Planet, date: Date, opts: CalcOptions = {}): number {
  const h = 6 * 3600e3;
  const a = siderealLongitude(planet, new Date(date.getTime() - h), opts);
  const b = siderealLongitude(planet, new Date(date.getTime() + h), opts);
  let d = b - a;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  return d * 2;
}

/** Sidereal ascendant (Lagna) and Midheaven for a place. */
export function ascendant(date: Date, lat: number, lon: number, opts: CalcOptions = {}) {
  const t = A.MakeTime(date);
  const tilt = A.e_tilt(t);
  const eps = tilt.tobl * rad;
  const lst = norm360(A.SiderealTime(t) * 15 + lon) * rad; // RAMC
  const phi = lat * rad;
  const asc = Math.atan2(Math.cos(lst), -(Math.sin(lst) * Math.cos(eps) + Math.tan(phi) * Math.sin(eps))) / rad;
  const mc = Math.atan2(Math.sin(lst), Math.cos(lst) * Math.cos(eps)) / rad;
  const corr = tilt.dpsi / 3600 + ayanamsa(date, opts.ayanamsa ?? "lahiri");
  return { ascendant: norm360(asc - corr), midheaven: norm360(mc - corr), ramc: lst / rad };
}

export function moonPhaseAngle(date: Date) {
  return A.MoonPhase(A.MakeTime(date));
}
export function moonIllumination(date: Date) {
  return A.Illumination(A.Body.Moon, A.MakeTime(date)).phase_fraction;
}

export type RiseSet = "rise" | "set";
/** Next rise/set of Sun or Moon after `from` (upper limb, standard refraction). Returns null if none within limitDays (polar regions). */
export function searchRiseSet(body: "Sun" | "Moon", kind: RiseSet, from: Date, lat: number, lon: number, elevation = 0, limitDays = 1.2) {
  const obs = new A.Observer(lat, lon, elevation);
  const r = A.SearchRiseSet(body === "Sun" ? A.Body.Sun : A.Body.Moon, obs, kind === "rise" ? +1 : -1, A.MakeTime(from), limitDays);
  return r ? r.date : null;
}

export function nextNewMoon(from: Date) {
  return A.SearchMoonPhase(0, A.MakeTime(from), 40)!.date;
}
export function prevNewMoon(from: Date) {
  return A.SearchMoonPhase(0, A.MakeTime(from), -40)!.date;
}
