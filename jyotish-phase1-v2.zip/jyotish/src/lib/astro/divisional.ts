/**
 * Parashari divisional charts (Vargas). Each function maps a sidereal longitude
 * to a sign index 0–11 in that varga. Rules per Brihat Parashara Hora Shastra.
 */

const isOdd = (sign: number) => sign % 2 === 0; // Mesha (0) is an odd sign
const quality = (sign: number) => sign % 3; // 0 movable, 1 fixed, 2 dual

type VargaFn = (lon: number) => number;

const part = (lon: number, n: number) => Math.floor((lon % 30) / (30 / n));
const signOf = (lon: number) => Math.floor(lon / 30);

export const VARGAS: Record<string, { name: string; area: string; fn: VargaFn }> = {
  D1: { name: "Rashi", area: "Body, overall life", fn: (l) => signOf(l) },
  D2: {
    name: "Hora", area: "Wealth",
    fn: (l) => {
      const s = signOf(l), p = part(l, 2);
      return isOdd(s) ? (p === 0 ? 4 : 3) : p === 0 ? 3 : 4; // Leo (Sun) / Cancer (Moon)
    },
  },
  D3: { name: "Drekkana", area: "Siblings, courage", fn: (l) => (signOf(l) + part(l, 3) * 4) % 12 },
  D4: { name: "Chaturthamsa", area: "Property, fortune", fn: (l) => (signOf(l) + part(l, 4) * 3) % 12 },
  D7: {
    name: "Saptamsa", area: "Children",
    fn: (l) => { const s = signOf(l); return (s + (isOdd(s) ? 0 : 6) + part(l, 7)) % 12; },
  },
  D9: { name: "Navamsa", area: "Spouse, dharma, strength of planets", fn: (l) => Math.floor(l / (30 / 9)) % 12 },
  D10: {
    name: "Dashamsa", area: "Career, status",
    fn: (l) => { const s = signOf(l); return (s + (isOdd(s) ? 0 : 8) + part(l, 10)) % 12; },
  },
  D12: { name: "Dwadashamsa", area: "Parents", fn: (l) => (signOf(l) + part(l, 12)) % 12 },
  D16: { name: "Shodashamsa", area: "Vehicles, comforts", fn: (l) => ([0, 4, 8][quality(signOf(l))] + part(l, 16)) % 12 },
  D20: { name: "Vimshamsa", area: "Spiritual practice", fn: (l) => ([0, 8, 4][quality(signOf(l))] + part(l, 20)) % 12 },
  D24: { name: "Chaturvimshamsa", area: "Education, learning", fn: (l) => ((isOdd(signOf(l)) ? 4 : 3) + part(l, 24)) % 12 },
  D27: { name: "Bhamsa", area: "Strengths and weaknesses", fn: (l) => Math.floor(l / (30 / 27)) % 12 },
  D30: {
    name: "Trimsamsa", area: "Misfortunes, challenges",
    fn: (l) => {
      const s = signOf(l), d = l % 30;
      if (isOdd(s)) return d < 5 ? 0 : d < 10 ? 10 : d < 18 ? 8 : d < 25 ? 2 : 6;
      return d < 5 ? 1 : d < 12 ? 5 : d < 20 ? 11 : d < 25 ? 9 : 7;
    },
  },
  D40: { name: "Khavedamsa", area: "Maternal legacy", fn: (l) => ((isOdd(signOf(l)) ? 0 : 6) + part(l, 40)) % 12 },
  D45: { name: "Akshavedamsa", area: "Paternal legacy, character", fn: (l) => ([0, 4, 8][quality(signOf(l))] + part(l, 45)) % 12 },
  D60: { name: "Shashtiamsa", area: "Past karma, overall", fn: (l) => (signOf(l) + part(l, 60)) % 12 },
};

export const VARGA_KEYS = Object.keys(VARGAS);
