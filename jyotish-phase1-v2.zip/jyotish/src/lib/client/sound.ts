"use client";
/** Synthesised temple bell (no audio files, so nothing to license). */
let ctx: AudioContext | null = null;
export function ringBell(volume = 0.25, base = 523.25) {
  try {
    ctx = ctx ?? new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const now = ctx.currentTime;
    const master = ctx.createGain();
    master.gain.value = volume;
    master.connect(ctx.destination);
    // Inharmonic partials of a struck bell
    [[1, 1], [2.0, 0.5], [2.76, 0.35], [5.4, 0.18], [8.93, 0.08]].forEach(([ratio, amp]) => {
      const o = ctx!.createOscillator();
      const g = ctx!.createGain();
      o.type = "sine";
      o.frequency.value = base * ratio;
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(amp, now + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 2.6 / Math.sqrt(ratio));
      o.connect(g).connect(master);
      o.start(now);
      o.stop(now + 3);
    });
  } catch { /* audio unavailable */ }
}
export function buzz(ms = 12) {
  try { navigator.vibrate?.(ms); } catch { /* ignore */ }
}
