/** The Vedic corpus: reference data in our own words. Counts follow the standard printed editions. */

export interface Veda {
  slug: string;
  name: string;
  nameHi: string;
  meaning: string;
  essence: string;
  priest: string;
  size: string;
  shakhas: string;
  upaveda: string;
  upanishads: string[];
  opening: { text: string; iast: string; ref: string; meaning: string };
  color: string;
}

export const VEDAS: Veda[] = [
  {
    slug: "rigveda", name: "Rigveda", nameHi: "ऋग्वेद", meaning: "Knowledge of verses (ṛc)",
    essence: "The oldest Veda: hymns of praise to Agni, Indra, Varuna, Soma, the Ashvins, Ushas and other devas, together with the earliest philosophical hymns such as the Nasadiya Sukta on creation and the Purusha Sukta.",
    priest: "Hotṛ, who recites the hymns at the yajna",
    size: "10 mandalas, 1,028 suktas, about 10,550 verses",
    shakhas: "Shakala (complete) and Bashkala (partly)",
    upaveda: "Ayurveda (medicine)",
    upanishads: ["Aitareya", "Kaushitaki"],
    opening: { text: "अग्निमीळे पुरोहितं यज्ञस्य देवमृत्विजम् ।", iast: "agnim īḷe purohitaṃ yajñasya devam ṛtvijam", ref: "Rigveda 1.1.1", meaning: "I praise Agni, the household priest, the divine minister of the sacrifice." },
    color: "#E07A1F",
  },
  {
    slug: "samaveda", name: "Samaveda", nameHi: "सामवेद", meaning: "Knowledge of melodies (sāman)",
    essence: "Verses, mostly drawn from the Rigveda, set to melody for singing during the Soma rituals. The Bhagavad Gita (10.22) has Krishna say: among the Vedas, I am the Samaveda. Indian classical music traces its roots here.",
    priest: "Udgātṛ, who sings the sāmans",
    size: "About 1,875 verses in two parts, Purvarchika and Uttararchika",
    shakhas: "Kauthuma, Ranayaniya, Jaiminiya",
    upaveda: "Gandharvaveda (music and dance)",
    upanishads: ["Chandogya", "Kena"],
    opening: { text: "अग्न आ याहि वीतये गृणानो हव्यदातये ।", iast: "agna ā yāhi vītaye gṛṇāno havyadātaye", ref: "Samaveda 1.1.1", meaning: "Come, Agni, praised in song, to the feast and to the giving of offerings." },
    color: "#2C3966",
  },
  {
    slug: "yajurveda", name: "Yajurveda", nameHi: "यजुर्वेद", meaning: "Knowledge of sacrificial formulas (yajus)",
    essence: "Prose formulas and verses for performing the yajna step by step: the practical manual of the ritual. It has two recensions: Shukla (White), with mantras alone, and Krishna (Black), with mantras and explanations interwoven.",
    priest: "Adhvaryu, who performs the physical actions of the ritual",
    size: "Shukla: Vajasaneyi Samhita, 40 adhyayas, about 1,975 mantras. Krishna: Taittiriya Samhita, 7 kandas",
    shakhas: "Shukla: Madhyandina, Kanva. Krishna: Taittiriya, Maitrayani, Kathaka, Kapishthala",
    upaveda: "Dhanurveda (archery and martial science)",
    upanishads: ["Isha", "Brihadaranyaka (Shukla)", "Taittiriya", "Katha", "Shvetashvatara (Krishna)"],
    opening: { text: "इषे त्वोर्जे त्वा वायव स्थ ।", iast: "iṣe tvorje tvā vāyava stha", ref: "Shukla Yajurveda 1.1", meaning: "For nourishment you, for strength you; you are the winds." },
    color: "#6B1E2A",
  },
  {
    slug: "atharvaveda", name: "Atharvaveda", nameHi: "अथर्ववेद", meaning: "Knowledge of the Atharvan sages",
    essence: "Hymns for everyday life: healing, protection, prosperity, marriage, kingship and peace at home, along with deep hymns on Brahman and the earth (the Bhumi Sukta). Closest of the four to the concerns of the household.",
    priest: "Brahman, who oversees the whole ritual and corrects errors",
    size: "20 kandas, about 730 hymns and 6,000 verses",
    shakhas: "Shaunaka, Paippalada",
    upaveda: "Sthapatyaveda (architecture) or Arthashastra, by different lists",
    upanishads: ["Mundaka", "Mandukya", "Prashna"],
    opening: { text: "माता भूमिः पुत्रो अहं पृथिव्याः ।", iast: "mātā bhūmiḥ putro ahaṃ pṛthivyāḥ", ref: "Atharvaveda 12.1.12 (Bhumi Sukta)", meaning: "The Earth is my mother; I am a child of the Earth." },
    color: "#B8892E",
  },
];

/** The four layers of each Veda, from hymn to philosophy. */
export const LAYERS = [
  { name: "Samhita", hi: "संहिता", kanda: "Karma-kanda", text: "The collected mantras and hymns, the core text of each Veda." },
  { name: "Brahmana", hi: "ब्राह्मण", kanda: "Karma-kanda", text: "Prose explaining how and why each ritual is performed, with its stories and symbolism." },
  { name: "Aranyaka", hi: "आरण्यक", kanda: "Upasana-kanda", text: "'Forest texts' that turn outer ritual into inner meditation, for those withdrawing from household life." },
  { name: "Upanishad", hi: "उपनिषद्", kanda: "Jnana-kanda", text: "The philosophical summit (Vedanta): the nature of Brahman, Atman and liberation." },
];

export const VEDANGAS = [
  { name: "Shiksha", hi: "शिक्षा", role: "Phonetics", text: "Correct pronunciation, accent and pitch, so a mantra keeps its power across generations." },
  { name: "Chhandas", hi: "छन्दस्", role: "Metre", text: "The metres of Vedic verse, such as Gayatri (24 syllables), Anushtubh (32) and Trishtubh (44)." },
  { name: "Vyakarana", hi: "व्याकरण", role: "Grammar", text: "The science of language, culminating in Panini's Ashtadhyayi." },
  { name: "Nirukta", hi: "निरुक्त", role: "Etymology", text: "The meaning and derivation of difficult Vedic words, as explained by Yaska." },
  { name: "Kalpa", hi: "कल्प", role: "Ritual", text: "The sutras for ritual: Shrauta (great sacrifices), Grihya (household samskaras), Dharma (conduct) and Shulba (altar geometry)." },
  { name: "Jyotisha", hi: "ज्योतिष", role: "Astronomy and time", text: "Reckoning of the calendar and auspicious times for the rituals. The root of the Panchang and of every timing on this site.", href: "/panchang" },
];

export const PRINCIPAL_UPANISHADS = [
  { name: "Isha", veda: "Shukla Yajurveda", teaching: "The Lord pervades all; act without attachment." },
  { name: "Kena", veda: "Samaveda", teaching: "By what power do the mind and senses work?" },
  { name: "Katha", veda: "Krishna Yajurveda", teaching: "Nachiketa learns the secret of death from Yama." },
  { name: "Prashna", veda: "Atharvaveda", teaching: "Six seekers put six questions on life and prana." },
  { name: "Mundaka", veda: "Atharvaveda", teaching: "Higher and lower knowledge; 'Satyameva Jayate'." },
  { name: "Mandukya", veda: "Atharvaveda", teaching: "Om and the four states of consciousness, in twelve verses." },
  { name: "Taittiriya", veda: "Krishna Yajurveda", teaching: "The five sheaths (koshas) and the bliss of Brahman." },
  { name: "Aitareya", veda: "Rigveda", teaching: "Creation, and 'Prajnanam Brahma': consciousness is Brahman." },
  { name: "Chandogya", veda: "Samaveda", teaching: "'Tat Tvam Asi': you are That, taught by Uddalaka to Shvetaketu." },
  { name: "Brihadaranyaka", veda: "Shukla Yajurveda", teaching: "Yajnavalkya's dialogues; 'Aham Brahmasmi'." },
];

export const MAHAVAKYAS = [
  { text: "प्रज्ञानं ब्रह्म", iast: "prajñānaṃ brahma", meaning: "Consciousness is Brahman", ref: "Aitareya Upanishad 3.3, Rigveda" },
  { text: "अहं ब्रह्मास्मि", iast: "ahaṃ brahmāsmi", meaning: "I am Brahman", ref: "Brihadaranyaka Upanishad 1.4.10, Yajurveda" },
  { text: "तत्त्वमसि", iast: "tat tvam asi", meaning: "You are That", ref: "Chandogya Upanishad 6.8.7, Samaveda" },
  { text: "अयमात्मा ब्रह्म", iast: "ayam ātmā brahma", meaning: "This Self is Brahman", ref: "Mandukya Upanishad 2, Atharvaveda" },
];
