/**
 * Karmakand: samskaras and puja vidhis. These are general outlines drawn from
 * the Grihya Sutras and common household practice. Family and regional
 * traditions differ; the pages say so and suggest consulting a purohit.
 */

export interface Samskara {
  n: number;
  name: string;
  hi: string;
  stage: "Before birth" | "Childhood" | "Education" | "Household" | "Life's end";
  what: string;
  when: string;
  vidhi?: string; // slug of a vidhi page
  muhurat?: boolean;
}

/** The sixteen samskaras (Shodasha Samskara), in life order. */
export const SAMSKARAS: Samskara[] = [
  { n: 1, name: "Garbhadhana", hi: "गर्भाधान", stage: "Before birth", what: "Prayer by the couple for a healthy, virtuous child.", when: "After marriage, on an auspicious night" },
  { n: 2, name: "Pumsavana", hi: "पुंसवन", stage: "Before birth", what: "Blessing for the healthy growth of the child in the womb.", when: "Third month of pregnancy" },
  { n: 3, name: "Simantonnayana", hi: "सीमन्तोन्नयन", stage: "Before birth", what: "Parting of the mother's hair; prayers for her well-being and calm. Today often merged with Godh Bharai or Valaikappu.", when: "Sixth to eighth month" },
  { n: 4, name: "Jatakarma", hi: "जातकर्म", stage: "Childhood", what: "Welcoming the newborn: the father whispers a blessing and touches honey and ghee to the baby's lips.", when: "At birth" },
  { n: 5, name: "Namakarana", hi: "नामकरण", stage: "Childhood", what: "Naming ceremony; the first syllable is often chosen from the birth nakshatra.", when: "11th or 12th day after birth", muhurat: true },
  { n: 6, name: "Nishkramana", hi: "निष्क्रमण", stage: "Childhood", what: "The baby's first outing, shown the Sun and Moon.", when: "Fourth month" },
  { n: 7, name: "Annaprashana", hi: "अन्नप्राशन", stage: "Childhood", what: "First feeding of solid food, usually rice kheer.", when: "Sixth month (boys) or fifth/seventh (girls)", muhurat: true },
  { n: 8, name: "Chudakarana (Mundan)", hi: "चूडाकरण (मुंडन)", stage: "Childhood", what: "First haircut, removing the birth hair, for health and a fresh start.", when: "First or third year", muhurat: true },
  { n: 9, name: "Karnavedha", hi: "कर्णवेध", stage: "Childhood", what: "Ear piercing.", when: "Third or fifth year" },
  { n: 10, name: "Vidyarambha", hi: "विद्यारम्भ", stage: "Education", what: "Beginning of learning: the child writes the first letters, often 'Om', in rice or sand.", when: "Fifth year; Vijayadashami or Vasant Panchami", muhurat: true },
  { n: 11, name: "Upanayana", hi: "उपनयन", stage: "Education", what: "Sacred thread ceremony and initiation into the Gayatri Mantra; the student is 'brought near' the teacher.", when: "Age 8 to 12 by tradition", muhurat: true, vidhi: "sandhya-vandan" },
  { n: 12, name: "Vedarambha", hi: "वेदारम्भ", stage: "Education", what: "Formal start of Vedic study with the guru.", when: "Soon after Upanayana" },
  { n: 13, name: "Keshanta", hi: "केशान्त", stage: "Education", what: "First shave, marking youth's arrival; gift to the teacher.", when: "Around 16 years" },
  { n: 14, name: "Samavartana", hi: "समावर्तन", stage: "Education", what: "Graduation: the ritual bath and return home after studies, ready for household life.", when: "End of studies" },
  { n: 15, name: "Vivaha", hi: "विवाह", stage: "Household", what: "Marriage: Kanyadaan, Panigrahan, Saptapadi (seven steps around Agni) and the vows of household dharma.", when: "Chosen with Kundli matching and Vivah Muhurat", muhurat: true },
  { n: 16, name: "Antyeshti", hi: "अन्त्येष्टि", stage: "Life's end", what: "The last rites, offering the body to Agni, followed by Shraddha for the departed.", when: "At death; Shraddha on the tithi each year and in Pitru Paksha" },
];

export const KARMA_TYPES = [
  { name: "Nitya karma", hi: "नित्य कर्म", text: "Daily duties: sandhya, prayer, offering water to the Sun, reading scripture." },
  { name: "Naimittika karma", hi: "नैमित्तिक कर्म", text: "Duties prompted by an occasion: festivals, eclipses, samskaras, Shraddha." },
  { name: "Kamya karma", hi: "काम्य कर्म", text: "Rituals done for a specific wish: prosperity, health, success in a venture." },
];

export const PANCHA_MAHAYAJNA = [
  { name: "Brahma Yajna", hi: "ब्रह्म यज्ञ", text: "Study and teaching of scripture; debt to the sages." },
  { name: "Deva Yajna", hi: "देव यज्ञ", text: "Offerings into fire and worship; debt to the gods." },
  { name: "Pitri Yajna", hi: "पितृ यज्ञ", text: "Tarpana and Shraddha; debt to the ancestors." },
  { name: "Bhuta Yajna", hi: "भूत यज्ञ", text: "Feeding animals and birds; care for all beings." },
  { name: "Manushya Yajna", hi: "मनुष्य यज्ञ", text: "Hospitality to guests and the needy." },
];

export interface VidhiStep {
  title: string;
  detail: string;
  mantra?: string;
  iast?: string;
}

export interface Vidhi {
  slug: string;
  title: string;
  hi: string;
  summary: string;
  occasion: string;
  duration: string;
  deity: string;
  samagri: string[];
  steps: VidhiStep[];
  notes: string[];
  related?: { label: string; href: string }[];
}

export const VIDHIS: Vidhi[] = [
  {
    slug: "shodashopachara-puja", title: "Shodashopachara Puja", hi: "षोडशोपचार पूजा",
    summary: "The classical sixteen-step worship used for almost every deity. Each step is an act of hospitality offered to the divine guest.",
    occasion: "Any major puja; festivals; Satyanarayan; Ganesh Chaturthi",
    duration: "45 to 90 minutes", deity: "Any (the deity's name is placed in each mantra)",
    samagri: ["Idol or picture on a clean red or yellow cloth", "Kalash with water, mango leaves and coconut", "Roli, kumkum, haldi, akshat (unbroken rice)", "Sandalwood paste", "Flowers and a garland", "Incense (dhoop/agarbatti)", "Ghee lamp (diya) and camphor", "Panchamrit: milk, curd, ghee, honey, sugar", "New cloth or mauli (sacred thread)", "Janeu (sacred thread) for male deities", "Naivedya: fruit and sweets", "Betel leaves, betel nut, cloves, cardamom", "Dakshina (coins)", "Bell, conch, aarti plate"],
    steps: [
      { title: "Dhyana and Avahana", detail: "Meditate on the deity's form and invite them into the image or kalash.", mantra: "ॐ [देवता] नमः । आवाहयामि ।", iast: "oṃ [devatā] namaḥ, āvāhayāmi" },
      { title: "Asana", detail: "Offer a seat: a flower or akshat placed at the deity's feet.", mantra: "आसनं समर्पयामि ।", iast: "āsanaṃ samarpayāmi" },
      { title: "Padya", detail: "Offer water to wash the feet.", mantra: "पाद्यं समर्पयामि ।", iast: "pādyaṃ samarpayāmi" },
      { title: "Arghya", detail: "Offer water with flowers, rice and sandal for the hands.", mantra: "अर्घ्यं समर्पयामि ।", iast: "arghyaṃ samarpayāmi" },
      { title: "Achamaniya", detail: "Offer water for sipping.", mantra: "आचमनीयं समर्पयामि ।", iast: "ācamanīyaṃ samarpayāmi" },
      { title: "Snana", detail: "Bathe the deity with water, then panchamrit, then clean water again.", mantra: "स्नानं समर्पयामि ।", iast: "snānaṃ samarpayāmi" },
      { title: "Vastra", detail: "Offer new cloth or mauli thread.", mantra: "वस्त्रं समर्पयामि ।", iast: "vastraṃ samarpayāmi" },
      { title: "Yajnopavita / Abhushana", detail: "Offer the sacred thread (male deities) or ornaments.", mantra: "यज्ञोपवीतं समर्पयामि ।", iast: "yajñopavītaṃ samarpayāmi" },
      { title: "Gandha", detail: "Apply sandalwood paste, kumkum and haldi.", mantra: "गन्धं समर्पयामि ।", iast: "gandhaṃ samarpayāmi" },
      { title: "Pushpa", detail: "Offer flowers and the garland.", mantra: "पुष्पाणि समर्पयामि ।", iast: "puṣpāṇi samarpayāmi" },
      { title: "Dhupa", detail: "Wave incense before the deity.", mantra: "धूपं आघ्रापयामि ।", iast: "dhūpaṃ āghrāpayāmi" },
      { title: "Dipa", detail: "Show the ghee lamp.", mantra: "दीपं दर्शयामि ।", iast: "dīpaṃ darśayāmi" },
      { title: "Naivedya", detail: "Offer food, sprinkling water around it, then a little water for sipping afterwards.", mantra: "नैवेद्यं निवेदयामि ।", iast: "naivedyaṃ nivedayāmi" },
      { title: "Tambula and Dakshina", detail: "Offer betel leaf with nut and spices, and dakshina.", mantra: "ताम्बूलं समर्पयामि ।", iast: "tāmbūlaṃ samarpayāmi" },
      { title: "Nirajana (Aarti)", detail: "Wave the camphor or ghee lamp clockwise while singing the aarti and ringing the bell.", mantra: "नीराजनं समर्पयामि ।", iast: "nīrājanaṃ samarpayāmi" },
      { title: "Pradakshina, Namaskara and Kshama", detail: "Circle the deity (or turn in place) clockwise, offer flowers with both hands (pushpanjali), bow, and ask forgiveness for any mistakes.", mantra: "आवाहनं न जानामि न जानामि विसर्जनम् । पूजां चैव न जानामि क्षमस्व परमेश्वर ॥", iast: "āvāhanaṃ na jānāmi na jānāmi visarjanam, pūjāṃ caiva na jānāmi kṣamasva parameśvara" },
    ],
    notes: ["The list of sixteen varies slightly between texts; some count Achamana twice or add Mantra Pushpa.", "If an item is unavailable, offer akshat (rice) in its place with the same words; this is accepted in every tradition.", "Begin every puja with Ganesh smarana and a sankalpa (statement of name, gotra, place, date and purpose)."],
    related: [{ label: "Vakratunda Mahakaya", href: "/mantras/vakratunda-mahakaya" }, { label: "Om Jai Jagdish Hare", href: "/mantras/om-jai-jagdish-hare" }],
  },
  {
    slug: "daily-ganesh-puja", title: "Daily Ganesh Puja", hi: "दैनिक गणेश पूजा",
    summary: "A short morning worship that fits into ten minutes, suitable for any home shrine.",
    occasion: "Every morning; Wednesdays; Chaturthi", duration: "10 minutes", deity: "Ganesha",
    samagri: ["Ganesha image", "Water in a small kalash", "Roli and akshat", "Red flower or durva grass (21 blades on Chaturthi)", "Diya and incense", "Modak, laddoo or jaggery", "Bell"],
    steps: [
      { title: "Purify", detail: "Bathe, sit facing east or north, sip water three times (achamana) and sprinkle water around you." },
      { title: "Light the lamp", detail: "Light the diya and incense.", mantra: "शुभं करोति कल्याणम् आरोग्यं धनसम्पदा ।", iast: "śubhaṃ karoti kalyāṇam ārogyaṃ dhanasampadā" },
      { title: "Invoke Ganesha", detail: "Fold your hands and recite the dhyana shloka.", mantra: "वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ । निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा ॥", iast: "vakratuṇḍa mahākāya sūryakoṭi samaprabha, nirvighnaṃ kuru me deva sarvakāryeṣu sarvadā" },
      { title: "Offer", detail: "Apply roli and akshat, offer the flower or durva, then the sweet." },
      { title: "Japa", detail: "Chant the bija mantra 11, 21 or 108 times.", mantra: "ॐ गं गणपतये नमः ।", iast: "oṃ gaṃ gaṇapataye namaḥ" },
      { title: "Aarti and prayer", detail: "Wave the diya, bow, and state the day's intention." },
    ],
    notes: ["Tulsi is not offered to Ganesha by tradition; durva grass is his favourite.", "On Sankashti Chaturthi, the fast ends after sighting the moon."],
    related: [{ label: "Om Gam Ganapataye Namah", href: "/mantras/om-gam-ganapataye-namah" }, { label: "Festival calendar", href: "/festivals" }],
  },
  {
    slug: "diwali-lakshmi-puja", title: "Diwali Lakshmi Puja", hi: "दीपावली लक्ष्मी पूजा",
    summary: "The evening worship of Lakshmi and Ganesha on Amavasya, performed during Pradosh Kaal and ideally in the fixed (Sthira) lagna of Vrishabha.",
    occasion: "Diwali, Kartika Amavasya (Purnimanta) / Ashwin Amavasya (Amanta)", duration: "1 to 1.5 hours", deity: "Lakshmi, Ganesha, Kubera, Saraswati",
    samagri: ["Lakshmi and Ganesha idols (Ganesha on Lakshmi's right)", "Red cloth on a chowki; rangoli at the entrance", "Kalash with water, coin, betel nut, mango leaves, coconut", "Silver coins or new account books (bahi-khata)", "Kumkum, haldi, akshat, sandalwood", "Lotus or red flowers, marigold garland", "11 or 21 earthen diyas with ghee or oil", "Puffed rice (kheel), batashe, sweets", "Panchamrit and Ganga jal", "Dhoop, camphor, bell, conch"],
    steps: [
      { title: "Prepare the home", detail: "Clean the house, draw rangoli and footprints of Lakshmi entering, and keep the doors open." },
      { title: "Set the altar", detail: "Place the chowki in the north-east or north, Ganesha on the left and Lakshmi on the right as you face them, with the kalash in front." },
      { title: "Sankalpa", detail: "Holding water, rice and a flower, state your name, gotra, place, date and the purpose of the puja, then release them." },
      { title: "Ganesha puja", detail: "Worship Ganesha first with the short sequence of offerings.", mantra: "ॐ गं गणपतये नमः ।", iast: "oṃ gaṃ gaṇapataye namaḥ" },
      { title: "Kalash and Navagraha", detail: "Worship the kalash (Varuna) and offer akshat to the nine planets." },
      { title: "Lakshmi puja", detail: "Perform shodashopachara puja of Lakshmi with lotus, kumkum, panchamrit and sweets.", mantra: "ॐ श्रीं महालक्ष्म्यै नमः ।", iast: "oṃ śrīṃ mahālakṣmyai namaḥ" },
      { title: "Kubera and account books", detail: "Worship Kubera, the treasury, and new account books with swastika and 'Shubh Labh'." },
      { title: "Deepa daan", detail: "Light the diyas, keep one with the deities, and place the rest at doors, windows, the kitchen and water sources." },
      { title: "Aarti", detail: "Sing the Lakshmi aarti, offer flowers, and distribute prasad." },
    ],
    notes: ["Exact puja muhurat depends on your city's sunset and lagna; see the festival calendar for the Amavasya timings.", "Many families keep one ghee diya burning through the night."],
    related: [{ label: "Om Shreem Mahalakshmyai Namah", href: "/mantras/om-shreem-mahalakshmyai-namah" }, { label: "Diwali date and Amavasya timings", href: "/festivals" }],
  },
  {
    slug: "satyanarayan-puja", title: "Satyanarayan Puja", hi: "सत्यनारायण पूजा",
    summary: "Worship of Vishnu as Satyanarayan, the Lord of truth, with the reading of the five chapters of the katha. Common on Purnima and for new beginnings.",
    occasion: "Purnima, Ekadashi, housewarming, after a wish is fulfilled", duration: "2 to 3 hours", deity: "Vishnu as Satyanarayan",
    samagri: ["Satyanarayan picture or shaligram", "Banana stems or leaves to form a mandap", "Kalash and coconut", "Tulsi leaves (essential)", "Panchamrit", "Prasad: sheera (sooji, ghee, sugar, banana) in the measure of 1.25 units", "Fruits, especially bananas", "Yellow cloth, flowers, akshat, roli", "Diya, dhoop, camphor"],
    steps: [
      { title: "Mandap and sankalpa", detail: "Build the banana-leaf mandap, establish the kalash and take the sankalpa." },
      { title: "Ganesh and Navagraha puja", detail: "Worship Ganesha, Gauri, Varuna and the nine planets." },
      { title: "Satyanarayan puja", detail: "Perform shodashopachara puja, offering tulsi with every naivedya.", mantra: "ॐ नमो भगवते वासुदेवाय ।", iast: "oṃ namo bhagavate vāsudevāya" },
      { title: "Katha", detail: "Read or listen to the five chapters (adhyayas) of the Satyanarayan Vrat Katha from the Skanda Purana (Reva Khanda), with the family seated together." },
      { title: "Havan (optional)", detail: "Offer ahutis into a small fire with the Vishnu mantra." },
      { title: "Aarti and prasad", detail: "Sing Om Jai Jagdish Hare and distribute prasad to everyone present; refusing prasad is considered inauspicious in the katha itself." },
    ],
    notes: ["Prasad is traditionally prepared in sava (1.25) measures of each ingredient."],
    related: [{ label: "Om Jai Jagdish Hare", href: "/mantras/om-jai-jagdish-hare" }, { label: "Shantakaram", href: "/mantras/shantakaram" }],
  },
  {
    slug: "griha-pravesh", title: "Griha Pravesh", hi: "गृह प्रवेश",
    summary: "The ceremony for entering a new home, purifying it and inviting prosperity, done on a muhurat chosen for the family.",
    occasion: "First entry into a new or renovated home", duration: "2 to 4 hours", deity: "Ganesha, Vastu Purusha, Navagraha, Lakshmi",
    samagri: ["Kalash with water, coconut and mango leaves", "Toran of mango leaves for the main door", "Rangoli colours", "Milk and a new vessel for boiling it", "Havan kund, samidha (wood), ghee, havan samagri", "Turmeric, kumkum, akshat, flowers", "Coconut to break at the threshold", "Idols or pictures of Ganesha and Lakshmi"],
    steps: [
      { title: "Choose the muhurat", detail: "A Griha Pravesh muhurat avoids Adhik masa, Kharmas and Chaturmas in many traditions, and favours fixed nakshatras." },
      { title: "Prepare the door", detail: "Hang the toran, draw rangoli, and draw a swastika with kumkum on the door." },
      { title: "Enter with the kalash", detail: "The lady of the house carries the kalash and enters with the right foot first, after breaking a coconut at the threshold." },
      { title: "Ganesh, Navagraha and Vastu puja", detail: "Worship Ganesha, the nine planets and the Vastu Purusha for harmony with the space." },
      { title: "Havan", detail: "Perform a havan to purify the home, with Gayatri and Navagraha ahutis.", mantra: "ॐ भूर्भुवः स्वः । तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि । धियो यो नः प्रचोदयात् ॥ स्वाहा ॥", iast: "oṃ bhūr bhuvaḥ svaḥ ... pracodayāt svāhā" },
      { title: "Boil milk", detail: "Boil milk in the new kitchen until it overflows, a sign of abundance, and offer kheer as prasad." },
      { title: "Feed and stay", detail: "Feed the priest and guests, and sleep in the new home that night; tradition asks that it not be left empty." },
    ],
    notes: ["Many families also perform a Vastu Shanti before moving in."],
    related: [{ label: "Gayatri Mantra", href: "/mantras/gayatri-mantra" }, { label: "Today's Panchang", href: "/panchang" }],
  },
  {
    slug: "rudrabhishek", title: "Rudrabhishek", hi: "रुद्राभिषेक",
    summary: "Ritual bathing of the Shivalinga while the Shri Rudram is chanted, for peace, health and removal of obstacles.",
    occasion: "Mondays, Shravan month, Maha Shivaratri, Pradosh", duration: "1 to 2 hours", deity: "Shiva",
    samagri: ["Shivalinga (or visit a temple)", "Water or Ganga jal", "Milk, curd, ghee, honey, sugar (panchamrit), each separately", "Sugarcane juice, coconut water (optional)", "Bilva (bel) leaves, preferably three-leaved", "Datura and aak flowers, white flowers", "Bhasma (vibhuti), sandalwood", "Rudraksha mala"],
    steps: [
      { title: "Sankalpa and Ganesha smarana", detail: "Begin with Ganesha and state your purpose." },
      { title: "Abhishek with water", detail: "Pour water steadily over the linga.", mantra: "ॐ नमः शिवाय ।", iast: "oṃ namaḥ śivāya" },
      { title: "Panchamrit abhishek", detail: "Offer milk, curd, ghee, honey and sugar in turn, rinsing with water between each." },
      { title: "Rudram chanting", detail: "Chant the Shri Rudram (Namakam and Chamakam) while the abhishek continues, or chant Om Namah Shivaya 108 times." },
      { title: "Decorate", detail: "Apply bhasma and sandal, offer bilva leaves with the smooth side down, and flowers." },
      { title: "Aarti and Mahamrityunjaya", detail: "Perform aarti and recite the Mahamrityunjaya mantra.", mantra: "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम् ।", iast: "oṃ tryambakaṃ yajāmahe sugandhiṃ puṣṭivardhanam" },
    ],
    notes: ["Tulsi, kumkum and ketaki flowers are traditionally not offered to Shiva.", "Do a half circumambulation (do not cross the water outlet of the linga)."],
    related: [{ label: "Mahamrityunjaya Mantra", href: "/mantras/mahamrityunjaya-mantra" }, { label: "Om Namah Shivaya", href: "/mantras/om-namah-shivaya" }],
  },
  {
    slug: "sandhya-vandan", title: "Sandhya Vandan (simplified)", hi: "संध्या वन्दन",
    summary: "The daily Vedic worship at the junctions of the day, centred on offering water to the Sun and chanting the Gayatri. This is a short household form.",
    occasion: "Daily at sunrise, noon and sunset", duration: "15 to 20 minutes", deity: "Savitr (Surya), through the Gayatri",
    samagri: ["Copper vessel (lota) of clean water", "Spoon (achamani) and plate", "Seat (asana) of wool or kusha", "Mala for counting"],
    steps: [
      { title: "Achamana", detail: "Sip water three times from the right palm, saying 'Om Keshavaya Namah', 'Om Narayanaya Namah', 'Om Madhavaya Namah'." },
      { title: "Pranayama", detail: "Breathe in and out slowly three times, mentally reciting the Gayatri." },
      { title: "Marjana", detail: "Sprinkle water on the head to purify.", mantra: "ॐ आपो हि ष्ठा मयोभुवः ।", iast: "oṃ āpo hi ṣṭhā mayobhuvaḥ (Rigveda 10.9.1)" },
      { title: "Arghya to the Sun", detail: "Facing the Sun, pour water from cupped hands three times while reciting the Gayatri." },
      { title: "Gayatri japa", detail: "Chant the Gayatri 10, 28 or 108 times on the mala.", mantra: "ॐ भूर्भुवः स्वः । तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि । धियो यो नः प्रचोदयात् ॥", iast: "oṃ bhūr bhuvaḥ svaḥ, tat savitur vareṇyaṃ bhargo devasya dhīmahi, dhiyo yo naḥ pracodayāt" },
      { title: "Upasthana and namaskara", detail: "Stand, offer salutations to the Sun and the four directions, and bow." },
    ],
    notes: ["The full rite differs by Veda shakha; learn it from a teacher or family elder.", "Sunrise and sunset times for your city are on the Panchang page."],
    related: [{ label: "Gayatri Mantra", href: "/mantras/gayatri-mantra" }, { label: "Sunrise today", href: "/panchang" }],
  },
  {
    slug: "navagraha-shanti", title: "Navagraha Shanti", hi: "नवग्रह शान्ति",
    summary: "Worship of the nine planets to balance difficult placements, dashas or Sade Sati.",
    occasion: "Difficult dasha or transit; before major life events; Sankranti", duration: "2 to 3 hours with havan", deity: "Surya, Chandra, Mangal, Budh, Guru, Shukra, Shani, Rahu, Ketu",
    samagri: ["Navagraha mandala of nine grains (wheat, rice, toor dal, moong, chana dal, white beans, black sesame, urad, horse gram)", "Nine coloured cloths", "Nine kinds of samidha (arka, palasha, khadira, apamarga, pippala, udumbara, shami, durva, kusha)", "Ghee, havan samagri", "Flowers in the planets' colours"],
    steps: [
      { title: "Mandala", detail: "Arrange the nine grain heaps in the traditional pattern with Surya at the centre." },
      { title: "Invocation", detail: "Invoke each graha in turn with its name mantra.", mantra: "ॐ सूर्याय नमः । ॐ चन्द्राय नमः । ॐ भौमाय नमः । ...", iast: "oṃ sūryāya namaḥ, oṃ candrāya namaḥ, oṃ bhaumāya namaḥ ..." },
      { title: "Puja", detail: "Offer cloth, flowers and grain to each planet." },
      { title: "Havan", detail: "Offer 108 or 28 ahutis per graha with its samidha." },
      { title: "Navagraha stotra and daan", detail: "Recite the Navagraha shloka and give donations linked to the troubling planet (for example, black sesame and oil for Saturn on Saturdays).", mantra: "ब्रह्मा मुरारिस्त्रिपुरान्तकारी भानुः शशी भूमिसुतो बुधश्च ।", iast: "brahmā murāris tripurāntakārī bhānuḥ śaśī bhūmisuto budhaś ca" },
    ],
    notes: ["Your Kundli shows which planet's dasha or transit is active; that graha is usually given extra emphasis."],
    related: [{ label: "Navagraha Shanti Shloka", href: "/mantras/navagraha-stotra" }, { label: "Check your dasha", href: "/kundli" }],
  },
];

export const findVidhi = (slug: string) => VIDHIS.find((v) => v.slug === slug);
