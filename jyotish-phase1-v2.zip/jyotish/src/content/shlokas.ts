/** Shloka library — public-domain scripture with our own translations. */

export type ShlokaSource = "Bhagavad Gita" | "Upanishads" | "Rigveda" | "Devi Mahatmya" | "Subhashita";

export interface Shloka {
  id: string;
  ref: string;
  source: ShlokaSource;
  theme: string;
  lines: string[];
  iast: string[];
  meaningHi: string;
  meaningEn: string;
  reflection: string;
}

export const SHLOKAS: Shloka[] = [
  {
    id: "gita-2-47", ref: "Bhagavad Gita 2.47", source: "Bhagavad Gita", theme: "Duty",
    lines: ["कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।", "मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥"],
    iast: ["karmaṇy evādhikāras te mā phaleṣu kadācana", "mā karmaphalahetur bhūr mā te saṅgo 'stv akarmaṇi"],
    meaningHi: "तुम्हारा अधिकार केवल कर्म करने में है, उसके फलों में कभी नहीं। तुम कर्मफल के कारण मत बनो, और कर्म न करने में भी तुम्हारी आसक्ति न हो।",
    meaningEn: "You have a right to your actions alone, never to their fruits. Do not let the fruit be your motive, and do not cling to inaction either.",
    reflection: "Give the work your full attention and let the outcome be what it will.",
  },
  {
    id: "gita-4-7", ref: "Bhagavad Gita 4.7", source: "Bhagavad Gita", theme: "Dharma",
    lines: ["यदा यदा हि धर्मस्य ग्लानिर्भवति भारत ।", "अभ्युत्थानमधर्मस्य तदात्मानं सृजाम्यहम् ॥"],
    iast: ["yadā yadā hi dharmasya glānir bhavati bhārata", "abhyutthānam adharmasya tadātmānaṃ sṛjāmy aham"],
    meaningHi: "हे भारत! जब-जब धर्म की हानि होती है और अधर्म बढ़ता है, तब-तब मैं स्वयं को प्रकट करता हूँ।",
    meaningEn: "Whenever dharma declines and adharma rises, O Bharata, I manifest myself.",
    reflection: "Order is restored whenever it is truly needed.",
  },
  {
    id: "gita-4-8", ref: "Bhagavad Gita 4.8", source: "Bhagavad Gita", theme: "Dharma",
    lines: ["परित्राणाय साधूनां विनाशाय च दुष्कृताम् ।", "धर्मसंस्थापनार्थाय सम्भवामि युगे युगे ॥"],
    iast: ["paritrāṇāya sādhūnāṃ vināśāya ca duṣkṛtām", "dharmasaṃsthāpanārthāya sambhavāmi yuge yuge"],
    meaningHi: "सज्जनों की रक्षा, दुष्टों के विनाश और धर्म की स्थापना के लिए मैं युग-युग में प्रकट होता हूँ।",
    meaningEn: "To protect the good, to end wrongdoing and to establish dharma, I come into being age after age.",
    reflection: "Protecting what is good is itself an act of devotion.",
  },
  {
    id: "gita-2-20", ref: "Bhagavad Gita 2.20", source: "Bhagavad Gita", theme: "The Self",
    lines: ["न जायते म्रियते वा कदाचिन्", "नायं भूत्वा भविता वा न भूयः ।", "अजो नित्यः शाश्वतोऽयं पुराणो", "न हन्यते हन्यमाने शरीरे ॥"],
    iast: ["na jāyate mriyate vā kadācin", "nāyaṃ bhūtvā bhavitā vā na bhūyaḥ", "ajo nityaḥ śāśvato 'yaṃ purāṇo", "na hanyate hanyamāne śarīre"],
    meaningHi: "आत्मा न कभी जन्म लेती है, न कभी मरती है। यह न पहले कभी न होकर उत्पन्न हुई है, न आगे फिर होगी। यह अजन्मा, नित्य, शाश्वत और पुरातन है; शरीर के मारे जाने पर भी यह नहीं मारी जाती।",
    meaningEn: "The Self is never born and never dies. It did not come into being, nor will it cease to be. Unborn, eternal, everlasting and ancient, it is not slain when the body is slain.",
    reflection: "What you truly are cannot be lost.",
  },
  {
    id: "gita-2-14", ref: "Bhagavad Gita 2.14", source: "Bhagavad Gita", theme: "Equanimity",
    lines: ["मात्रास्पर्शास्तु कौन्तेय शीतोष्णसुखदुःखदाः ।", "आगमापायिनोऽनित्यास्तांस्तितिक्षस्व भारत ॥"],
    iast: ["mātrāsparśās tu kaunteya śītoṣṇasukhaduḥkhadāḥ", "āgamāpāyino 'nityās tāṃs titikṣasva bhārata"],
    meaningHi: "हे कौन्तेय! इंद्रियों और विषयों के संयोग से सर्दी-गर्मी, सुख-दुःख होते हैं। ये आते-जाते रहते हैं और अनित्य हैं, इन्हें सहन करो।",
    meaningEn: "Contact of the senses with their objects brings cold and heat, pleasure and pain. They come and go and do not last; bear them patiently, O Bharata.",
    reflection: "Today's discomfort is a passing season.",
  },
  {
    id: "gita-6-5", ref: "Bhagavad Gita 6.5", source: "Bhagavad Gita", theme: "Self-reliance",
    lines: ["उद्धरेदात्मनात्मानं नात्मानमवसादयेत् ।", "आत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः ॥"],
    iast: ["uddhared ātmanātmānaṃ nātmānam avasādayet", "ātmaiva hy ātmano bandhur ātmaiva ripur ātmanaḥ"],
    meaningHi: "मनुष्य स्वयं अपना उद्धार करे, स्वयं को नीचे न गिराए। मनुष्य स्वयं ही अपना मित्र है और स्वयं ही अपना शत्रु।",
    meaningEn: "Lift yourself by your own effort; do not let yourself sink. You are your own friend, and you are your own enemy.",
    reflection: "Be the friend to yourself that you would be to others.",
  },
  {
    id: "gita-9-22", ref: "Bhagavad Gita 9.22", source: "Bhagavad Gita", theme: "Devotion",
    lines: ["अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते ।", "तेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम् ॥"],
    iast: ["ananyāś cintayanto māṃ ye janāḥ paryupāsate", "teṣāṃ nityābhiyuktānāṃ yogakṣemaṃ vahāmy aham"],
    meaningHi: "जो लोग अनन्य भाव से मेरा चिंतन करते हुए मेरी उपासना करते हैं, उन सदा मुझमें लगे हुए भक्तों का योगक्षेम (प्राप्ति और रक्षा) मैं स्वयं वहन करता हूँ।",
    meaningEn: "To those who worship me with undivided minds, ever devoted, I bring what they lack and preserve what they have.",
    reflection: "Steady devotion brings its own security.",
  },
  {
    id: "gita-4-24", ref: "Bhagavad Gita 4.24", source: "Bhagavad Gita", theme: "Before meals",
    lines: ["ब्रह्मार्पणं ब्रह्म हविर्ब्रह्माग्नौ ब्रह्मणा हुतम् ।", "ब्रह्मैव तेन गन्तव्यं ब्रह्मकर्मसमाधिना ॥"],
    iast: ["brahmārpaṇaṃ brahma havir brahmāgnau brahmaṇā hutam", "brahmaiva tena gantavyaṃ brahmakarmasamādhinā"],
    meaningHi: "अर्पण ब्रह्म है, हवि ब्रह्म है, ब्रह्मरूपी अग्नि में ब्रह्म द्वारा आहुति दी जाती है। जो सब कर्मों में ब्रह्म को देखता है, वह ब्रह्म को ही प्राप्त होता है।",
    meaningEn: "The offering is Brahman, the oblation is Brahman, poured by Brahman into the fire of Brahman. One who sees Brahman in every act reaches Brahman.",
    reflection: "Recited before meals: eating, too, can be an offering.",
  },
  {
    id: "gita-18-66", ref: "Bhagavad Gita 18.66", source: "Bhagavad Gita", theme: "Surrender",
    lines: ["सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज ।", "अहं त्वा सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः ॥"],
    iast: ["sarvadharmān parityajya mām ekaṃ śaraṇaṃ vraja", "ahaṃ tvā sarvapāpebhyo mokṣayiṣyāmi mā śucaḥ"],
    meaningHi: "सब धर्मों को छोड़कर केवल मेरी शरण में आ जाओ। मैं तुम्हें सब पापों से मुक्त कर दूँगा, शोक मत करो।",
    meaningEn: "Set aside all other duties and take refuge in me alone. I will free you from all wrongs; do not grieve.",
    reflection: "Krishna's last teaching to Arjuna: trust, and let go of worry.",
  },
  {
    id: "isha-1", ref: "Isha Upanishad 1", source: "Upanishads", theme: "Contentment",
    lines: ["ईशा वास्यमिदं सर्वं यत्किञ्च जगत्यां जगत् ।", "तेन त्यक्तेन भुञ्जीथा मा गृधः कस्यस्विद्धनम् ॥"],
    iast: ["īśā vāsyam idaṃ sarvaṃ yat kiñca jagatyāṃ jagat", "tena tyaktena bhuñjīthā mā gṛdhaḥ kasya svid dhanam"],
    meaningHi: "इस जगत में जो कुछ भी है, वह सब ईश्वर से व्याप्त है। त्यागपूर्वक उसका उपभोग करो; किसी के धन का लोभ मत करो।",
    meaningEn: "All this, whatever moves in this moving world, is pervaded by the Lord. Enjoy it through renunciation; do not covet anyone's wealth.",
    reflection: "Enjoy without grasping; nothing is truly ours to hoard.",
  },
  {
    id: "taittiriya-1-11", ref: "Taittiriya Upanishad 1.11.2", source: "Upanishads", theme: "Gratitude",
    lines: ["मातृदेवो भव । पितृदेवो भव ।", "आचार्यदेवो भव । अतिथिदेवो भव ॥"],
    iast: ["mātṛdevo bhava, pitṛdevo bhava", "ācāryadevo bhava, atithidevo bhava"],
    meaningHi: "माता को देवता मानो, पिता को देवता मानो, आचार्य को देवता मानो, अतिथि को देवता मानो।",
    meaningEn: "Treat your mother as divine, your father as divine, your teacher as divine, your guest as divine.",
    reflection: "The parting advice given to students at the end of their Vedic studies.",
  },
  {
    id: "brihadaranyaka-1-3-28", ref: "Brihadaranyaka Upanishad 1.3.28", source: "Upanishads", theme: "Aspiration",
    lines: ["असतो मा सद्गमय । तमसो मा ज्योतिर्गमय ।", "मृत्योर्मा अमृतं गमय ॥"],
    iast: ["asato mā sad gamaya, tamaso mā jyotir gamaya", "mṛtyor mā amṛtaṃ gamaya"],
    meaningHi: "मुझे असत्य से सत्य की ओर, अंधकार से प्रकाश की ओर, मृत्यु से अमरत्व की ओर ले चलो।",
    meaningEn: "Lead me from the unreal to the real, from darkness to light, from death to immortality.",
    reflection: "Three steps, one journey.",
  },
  {
    id: "rigveda-10-191-2", ref: "Rigveda 10.191.2", source: "Rigveda", theme: "Unity",
    lines: ["सं गच्छध्वं सं वदध्वं सं वो मनांसि जानताम् ।", "देवा भागं यथा पूर्वे सञ्जानाना उपासते ॥"],
    iast: ["saṃ gacchadhvaṃ saṃ vadadhvaṃ saṃ vo manāṃsi jānatām", "devā bhāgaṃ yathā pūrve sañjānānā upāsate"],
    meaningHi: "साथ चलो, साथ बोलो, तुम्हारे मन एक समान जानें; जैसे पूर्वकाल के देवता एकमत होकर अपना भाग ग्रहण करते थे।",
    meaningEn: "Walk together, speak together, let your minds be of one accord, as the gods of old, in harmony, shared their portion.",
    reflection: "The closing hymn of the Rigveda is a prayer for harmony.",
  },
  {
    id: "devi-mahatmya-5", ref: "Devi Mahatmya 5 (Aparajita Stuti)", source: "Devi Mahatmya", theme: "Shakti",
    lines: ["या देवी सर्वभूतेषु शक्तिरूपेण संस्थिता ।", "नमस्तस्यै नमस्तस्यै नमस्तस्यै नमो नमः ॥"],
    iast: ["yā devī sarvabhūteṣu śaktirūpeṇa saṃsthitā", "namas tasyai namas tasyai namas tasyai namo namaḥ"],
    meaningHi: "जो देवी सभी प्राणियों में शक्ति रूप से स्थित हैं, उन्हें बारंबार नमस्कार।",
    meaningEn: "To the Goddess who dwells in all beings as power: salutations, salutations, salutations again and again.",
    reflection: "The same verse repeats with mother, peace, compassion and more in place of power.",
  },
  {
    id: "maha-upanishad-6-71", ref: "Maha Upanishad 6.71–72", source: "Upanishads", theme: "Universal family",
    lines: ["अयं निजः परो वेति गणना लघुचेतसाम् ।", "उदारचरितानां तु वसुधैव कुटुम्बकम् ॥"],
    iast: ["ayaṃ nijaḥ paro veti gaṇanā laghucetasām", "udāracaritānāṃ tu vasudhaiva kuṭumbakam"],
    meaningHi: "यह अपना है, वह पराया है, ऐसी गणना छोटे मन वाले करते हैं। उदार चरित्र वालों के लिए तो सम्पूर्ण पृथ्वी ही परिवार है।",
    meaningEn: "'This is mine, that is another's': so count the narrow-minded. For the large-hearted, the whole earth is one family.",
    reflection: "Vasudhaiva kutumbakam: widen the circle you call your own.",
  },
  {
    id: "sarve-bhavantu-sukhinah", ref: "Shanti Path (traditional)", source: "Subhashita", theme: "Universal welfare",
    lines: ["सर्वे भवन्तु सुखिनः सर्वे सन्तु निरामयाः ।", "सर्वे भद्राणि पश्यन्तु मा कश्चिद्दुःखभाग्भवेत् ॥"],
    iast: ["sarve bhavantu sukhinaḥ sarve santu nirāmayāḥ", "sarve bhadrāṇi paśyantu mā kaścid duḥkhabhāg bhavet"],
    meaningHi: "सभी सुखी हों, सभी रोग-मुक्त हों, सभी शुभ देखें, कोई भी दुःख का भागी न हो।",
    meaningEn: "May all be happy, may all be free from illness, may all see what is good, may no one suffer.",
    reflection: "A prayer that asks nothing for oneself alone.",
  },
];

export const SHLOKA_SOURCES = [...new Set(SHLOKAS.map((s) => s.source))];

/** Deterministic "shloka of the day" from the calendar date. */
export function shlokaOfDay(isoDate: string) {
  const n = isoDate.split("-").reduce((a, b) => a * 31 + Number(b), 7);
  return SHLOKAS[n % SHLOKAS.length];
}
