import type { Metadata } from "next";
import { NumerologyApp } from "@/components/NumerologyApp";
import { PageHeader, Faq, Disclaimer } from "@/components/ui";

export const metadata: Metadata = {
  title: "Numerology Calculator — Life Path, Destiny & Name Number",
  description: "Calculate your Birth number, Life Path, Destiny, Soul Urge, Personality and Personal Year numbers in Pythagorean or Chaldean numerology, with a letter-by-letter breakdown.",
  alternates: { canonical: "/numerology" },
};

export default function Page() {
  return (
    <>
      <PageHeader title="Numerology" intro="Every number is shown with the arithmetic behind it, so you can check the working." crumbs={[{ name: "Numerology", href: "/numerology" }]} />
      <NumerologyApp />
      <div className="container no-print">
        <h2 className="section-title mt-6">The two systems</h2>
        <div className="mt-5"><Faq items={[
          { q: "Pythagorean or Chaldean?", a: "Pythagorean numerology assigns 1–9 to the alphabet in order (A=1 … I=9, J=1 …). Chaldean numerology, popular in India, assigns values 1–8 by the sound of each letter and never uses 9 for a letter." },
          { q: "What are master numbers?", a: "In the Pythagorean system, totals of 11, 22 and 33 are kept unreduced for Life Path, Destiny, Soul Urge and Personality, as they are read as intensified forms of 2, 4 and 6." },
          { q: "Which planet rules each number?", a: "Indian numerology links 1 to the Sun, 2 Moon, 3 Jupiter, 4 Rahu, 5 Mercury, 6 Venus, 7 Ketu, 8 Saturn and 9 Mars. Lucky colours, days and gemstones follow the ruling planet." },
        ]} /></div>
        <Disclaimer />
      </div>
    </>
  );
}
