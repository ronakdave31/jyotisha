import type { Metadata } from "next";
import Link from "next/link";
import { VEDAS, LAYERS, VEDANGAS, PRINCIPAL_UPANISHADS, MAHAVAKYAS } from "@/content/vedas";
import { PageHeader, Faq, JsonLd } from "@/components/ui";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "The Four Vedas — Rigveda, Samaveda, Yajurveda, Atharvaveda",
  description: "A guide to the four Vedas: their hymns, priests, branches and Upanishads, the four layers from Samhita to Upanishad, the six Vedangas and the Mahavakyas.",
  alternates: { canonical: "/vedas" },
};

export default function Page() {
  return (
    <>
      <PageHeader title="The Vedas" intro="Shruti, 'that which was heard': the oldest scriptures of Sanatan Dharma, preserved by oral recitation for over three thousand years." crumbs={[{ name: "Vedas", href: "/vedas" }]}>
        <p className="mt-5 font-deva text-2xl text-maroon">वेदोऽखिलो धर्ममूलम्</p>
        <p className="text-sm text-ink-faint">The whole Veda is the root of dharma (Manusmriti 2.6)</p>
      </PageHeader>

      <div className="container space-y-16 py-12">
        <section aria-labelledby="four">
          <h2 id="four" className="section-title">The four Vedas</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {VEDAS.map((v) => (
              <article key={v.slug} id={v.slug} className="lift reveal leaf relative overflow-hidden p-6">
                <span className="absolute inset-x-0 top-0 h-1" style={{ background: v.color }} aria-hidden />
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="font-display text-3xl font-bold text-maroon">{v.name}</h3>
                  <span className="font-deva text-2xl" style={{ color: v.color }}>{v.nameHi}</span>
                </div>
                <p className="text-sm text-ink-faint">{v.meaning}</p>
                <p className="mt-3 text-ink-soft">{v.essence}</p>
                <blockquote className="mt-4 rounded-xl bg-ivory-deep/70 p-4">
                  <p className="font-deva text-xl text-maroon">{v.opening.text}</p>
                  <p className="text-sm italic text-ink-soft">{v.opening.iast}</p>
                  <p className="mt-1 text-sm">{v.opening.meaning} <span className="text-ink-faint">({v.opening.ref})</span></p>
                </blockquote>
                <dl className="mt-4 grid gap-x-4 gap-y-2 text-sm sm:grid-cols-2">
                  {[["Priest", v.priest], ["Extent", v.size], ["Surviving shakhas", v.shakhas], ["Upaveda", v.upaveda], ["Upanishads", v.upanishads.join(", ")]].map(([k, val]) => (
                    <div key={k}><dt className="text-ink-faint">{k}</dt><dd>{val}</dd></div>
                  ))}
                </dl>
              </article>
            ))}
          </div>
        </section>

        <section aria-labelledby="layers" className="reveal">
          <h2 id="layers" className="section-title">From hymn to philosophy</h2>
          <p className="mt-2 max-w-2xl text-ink-soft">Each Veda has four layers. The first two form the Karma-kanda, the portion on ritual action; the Upanishads form the Jnana-kanda, the portion on knowledge.</p>
          <ol className="mt-6 grid gap-4 md:grid-cols-4">
            {LAYERS.map((l, i) => (
              <li key={l.name} className="relative rounded-2xl bg-midnight p-5 text-ivory">
                <span className="text-xs text-gold-light">{l.kanda}</span>
                <p className="mt-1 font-display text-2xl font-semibold text-gold-pale">{l.name} <span className="font-deva text-lg text-ivory/70">{l.hi}</span></p>
                <p className="mt-2 text-sm text-ivory/80">{l.text}</p>
                {i < LAYERS.length - 1 && <span className="absolute -right-3 top-1/2 hidden -translate-y-1/2 text-2xl text-saffron md:block" aria-hidden>›</span>}
              </li>
            ))}
          </ol>
          <p className="mt-4 text-sm"><Link className="text-maroon underline" href="/karmkand">Read about Karmakand and the sixteen samskaras</Link></p>
        </section>

        <section aria-labelledby="vedangas" className="reveal">
          <h2 id="vedangas" className="section-title">The six Vedangas</h2>
          <p className="mt-2 max-w-2xl text-ink-soft">The 'limbs of the Veda': six sciences needed to recite, understand and perform it correctly.</p>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {VEDANGAS.map((v) => (
              <li key={v.name} className={`lift leaf p-5 ${v.href ? "ring-1 ring-saffron/40" : ""}`}>
                <p className="flex items-baseline justify-between"><span className="font-display text-2xl font-semibold text-maroon">{v.name}</span><span className="font-deva text-ink-faint">{v.hi}</span></p>
                <p className="text-sm text-saffron-dark">{v.role}</p>
                <p className="mt-2 text-[15px] text-ink-soft">{v.text}</p>
                {v.href && <Link className="mt-2 inline-block text-sm text-maroon underline" href={v.href}>See today&apos;s Panchang</Link>}
              </li>
            ))}
          </ul>
        </section>

        <section aria-labelledby="upanishads" className="reveal">
          <h2 id="upanishads" className="section-title">The ten principal Upanishads</h2>
          <div className="mt-6 overflow-x-auto">
            <table className="w-full min-w-[560px] text-[15px]">
              <thead><tr className="border-b border-gold/30 text-left text-ink-faint"><th className="py-2 font-normal">Upanishad</th><th className="font-normal">Veda</th><th className="font-normal">Central teaching</th></tr></thead>
              <tbody>{PRINCIPAL_UPANISHADS.map((u) => (
                <tr key={u.name} className="border-b border-gold/10 transition-colors hover:bg-gold-pale/30"><td className="py-2.5 font-medium text-maroon">{u.name}</td><td className="text-ink-soft">{u.veda}</td><td>{u.teaching}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </section>

        <section aria-labelledby="maha" className="reveal">
          <h2 id="maha" className="section-title">The four Mahavakyas</h2>
          <p className="mt-2 max-w-2xl text-ink-soft">One 'great saying' from an Upanishad of each Veda, each pointing to the unity of Atman and Brahman.</p>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {MAHAVAKYAS.map((m) => (
              <li key={m.iast} className="lift rounded-2xl border border-gold/30 bg-maroon p-6 text-center text-ivory">
                <p className="font-deva text-3xl text-gold-pale">{m.text}</p>
                <p className="mt-1 text-sm italic text-ivory/70">{m.iast}</p>
                <p className="mt-3 font-display text-xl">{m.meaning}</p>
                <p className="mt-1 text-xs text-ivory/60">{m.ref}</p>
              </li>
            ))}
          </ul>
        </section>

        <section className="reveal">
          <h2 className="section-title">Questions</h2>
          <div className="mt-5"><Faq items={[
            { q: "What is the difference between Shruti and Smriti?", a: "Shruti ('heard') is the revealed Veda, including the Upanishads, and is the highest authority. Smriti ('remembered') covers texts composed by sages, such as the Itihasas (Ramayana, Mahabharata with the Bhagavad Gita), Puranas and Dharma Shastras." },
            { q: "How were the Vedas preserved without writing?", a: "Through recitation techniques called pathas. Beyond the plain text (samhita patha), students learnt word-by-word (pada), interlocked (krama) and elaborate patterns such as jata and ghana, which make any error immediately audible. UNESCO recognises Vedic chanting as an intangible cultural heritage." },
            { q: "Who compiled the Vedas into four?", a: "Tradition credits Krishna Dvaipayana, called Veda Vyasa, 'the one who divided', with arranging the Veda into four collections and teaching each to a disciple." },
          ]} /></div>
        </section>
      </div>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "Article", headline: "The Four Vedas", author: { "@type": "Organization", name: SITE.name }, about: VEDAS.map((v) => v.name) }} />
    </>
  );
}
