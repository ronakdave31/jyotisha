import Link from "next/link";
export default function NotFound() {
  return (
    <div className="container grid min-h-[50vh] place-items-center py-16 text-center">
      <div><h1 className="font-display text-5xl font-bold text-maroon">Page not found</h1><p className="mt-3 text-ink-soft">The page may have moved. Try today&apos;s Panchang or generate a Kundli.</p>
      <div className="mt-6 flex justify-center gap-3"><Link className="btn-primary" href="/panchang">Today&apos;s Panchang</Link><Link className="btn-ghost" href="/kundli">Generate Kundli</Link></div></div>
    </div>
  );
}
