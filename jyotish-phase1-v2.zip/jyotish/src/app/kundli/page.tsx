import type { Metadata } from "next";
import { Suspense } from "react";
import { KundliApp } from "@/components/KundliApp";
import { PageHeader, Faq, Disclaimer } from "@/components/ui";
import { getUser } from "@/lib/supabase/server";
import { supabaseEnabled } from "@/lib/supabase/config";

export const metadata: Metadata = {
  title: "Free Kundli — Vedic Birth Chart with Dasha, Navamsa & Doshas",
  description: "Generate your Janam Kundli: Lagna, planets with nakshatra and pada, North and South Indian charts, 16 divisional charts, Vimshottari Dasha, yogas, Manglik, Kaal Sarp and Sade Sati.",
  alternates: { canonical: "/kundli" },
};

const FAQ = [
  { q: "Why does the exact birth time matter?", a: "The Lagna moves through a whole sign in about two hours, and divisional charts such as D9, D10 and D60 change in minutes. A ten-minute error can change the Navamsa Lagna and the dasha balance." },
  { q: "Which house system is used?", a: "Whole-sign houses from the Lagna, the most common practice in Parashari astrology. Bhava Chalit (cusp-based) houses are planned." },
  { q: "How is the Dasha calculated?", a: "Vimshottari Dasha starts from the lord of the Moon's nakshatra. The unelapsed portion of that nakshatra at birth gives the balance of the first Mahadasha; years are 365.25 days." },
  { q: "What if my birthplace is not listed?", a: "Search finds most towns worldwide through OpenStreetMap. You can also switch to manual coordinates and enter latitude, longitude and the IANA time zone (for example Asia/Kolkata). Daylight saving is applied automatically from the time zone database." },
];

export default async function KundliPage() {
  const { user } = await getUser();
  return (
    <>
      <PageHeader title="Kundli" intro="Enter the birth details as precisely as you can. Nothing is stored unless you choose to save it." crumbs={[{ name: "Kundli", href: "/kundli" }]} />
      <Suspense><KundliApp signedIn={!!user} accountsEnabled={supabaseEnabled} /></Suspense>
      <div className="container no-print">
        <h2 className="section-title mt-6">About your Kundli</h2>
        <div className="mt-5"><Faq items={FAQ} /></div>
        <Disclaimer extra="Health-related indications are traditional and are not medical advice." />
      </div>
    </>
  );
}
