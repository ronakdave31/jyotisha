import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { horoscopeFor, ordinal } from "@/lib/astro/horoscope";
import { RASHIS, ZODIAC_GLYPH } from "@/lib/astro/constants";
import { PageHeader, Disclaimer } from "@/components/ui";

export const revalidate = 1800;
export function generateStaticParams() { return RASHIS.map((_, i) => ({ sign: String(i) })); }
export function generateMetadata({ params }: { params: { sign: string } }): Metadata {
  const r = RASHIS[Number(params.sign)];
  return r ? { title: `${r.en} (${r.western}) Horoscope Today`, description: `Today's Vedic horoscope for ${r.en} Rashi from current planetary transits.`, alternates: { canonical: `/horoscope/${params.sign}` } } : {};
}

export default function Page({ params }: { params: { sign: string } }) {
  const i = Number(params.sign);
  if (!Number.isInteger(i) || i < 0 || i > 11) notFound();
  const h = horoscopeFor(i, new Date());
  return (
    <>
      <PageHeader title={`${ZODIAC_GLYPH[i]} ${h.sign} horoscope`} intro={`${h.western} · ${RASHIS[i].hi} · ruled by ${RASHIS[i].lord}`} crumbs={[{ name: "Horoscope", href: "/horoscope" }, { name: h.sign, href: `/horoscope/${i}` }]} />
      <div className="container grid gap-8 py-10 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          <section className="leaf p-6"><h2 className="font-display text-2xl font-semibold text-maroon">Today</h2><p className="mt-2 text-lg">{h.daily}</p>{h.chandrashtama && <p className="mt-2 text-maroon">Chandrashtama: the Moon transits your 8th house.</p>}</section>
          <section className="leaf p-6"><h2 className="font-display text-2xl font-semibold text-maroon">This week and month</h2><p className="mt-2">{h.weekly}</p></section>
          <section className="leaf p-6"><h2 className="font-display text-2xl font-semibold text-maroon">The year&apos;s slower influences</h2><p className="mt-2">{h.yearly}</p></section>
        </div>
        <aside className="leaf h-fit p-6">
          <h2 className="font-display text-xl font-semibold text-maroon">Transits from {h.sign}</h2>
          <ul className="mt-3 space-y-1.5 text-[15px]">{h.positions.map((p) => (
            <li key={p.planet} className="flex justify-between"><span>{p.planet} in {p.sign}</span><span className={p.favourable ? "text-emerald-800" : "text-maroon"}>{ordinal(p.house)}</span></li>
          ))}</ul>
          <p className="mt-4 text-sm text-ink-faint">Green houses are classically favourable for that planet&apos;s transit (Gochara).</p>
          <Link href="/kundli" className="btn-primary mt-5 w-full">Get a reading from your full chart</Link>
        </aside>
      </div>
      <div className="container"><Disclaimer /></div>
    </>
  );
}
