import type { Metadata } from "next";
import Link from "next/link";
import { horoscopeFor } from "@/lib/astro/horoscope";
import { RASHIS, ZODIAC_GLYPH } from "@/lib/astro/constants";
import { PageHeader, Disclaimer } from "@/components/ui";

export const revalidate = 1800;
export const metadata: Metadata = { title: "Daily Horoscope by Rashi (Moon sign)", description: "Today's Vedic horoscope for all 12 Moon signs, read from the current transits of the Moon, Sun, Mars, Mercury, Jupiter, Venus and Saturn.", alternates: { canonical: "/horoscope" } };

export default function Page() {
  const now = new Date();
  return (
    <>
      <PageHeader title="Daily horoscope" intro="Vedic horoscopes are read from your Moon sign (Rashi), not your Sun sign. Not sure of yours? Your Kundli shows it." crumbs={[{ name: "Horoscope", href: "/horoscope" }]} />
      <div className="container grid gap-4 py-10 sm:grid-cols-2 lg:grid-cols-3">
        {RASHIS.map((r, i) => {
          const h = horoscopeFor(i, now);
          return (
            <Link key={r.en} href={`/horoscope/${i}`} className="leaf block p-5 hover:border-saffron">
              <p className="flex items-center justify-between"><span className="font-display text-2xl font-semibold text-maroon">{ZODIAC_GLYPH[i]} {r.en}</span><span className="text-sm text-ink-faint">{r.western}</span></p>
              {h.chandrashtama && <p className="mt-1 text-sm font-medium text-maroon">Chandrashtama today</p>}
              <p className="mt-2 text-[15px] text-ink-soft">{h.daily}</p>
            </Link>
          );
        })}
      </div>
      <div className="container"><Disclaimer /></div>
    </>
  );
}
