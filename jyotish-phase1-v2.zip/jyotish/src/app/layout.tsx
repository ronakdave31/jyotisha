import type { Metadata, Viewport } from "next";
import { cookies } from "next/headers";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { JsonLd } from "@/components/ui";
import { SITE } from "@/lib/site";
import { resolveLocation } from "@/lib/location";
import { getUser } from "@/lib/supabase/server";

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: `${SITE.name} — Panchang, Kundli & Vedic Astrology`, template: `%s | ${SITE.name}` },
  description: "Accurate daily Panchang for your city, free Vedic Kundli with Vimshottari Dasha, Gun Milan, festival dates and numerology — calculated from real astronomy.",
  openGraph: { type: "website", siteName: SITE.name, locale: "en_IN" },
  twitter: { card: "summary_large_image" },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = { themeColor: "#6B1E2A", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const c = cookies();
  const loc = resolveLocation({}, c.get("loc")?.value);
  const lang = c.get("lang")?.value === "hi" ? "hi" : "en";
  const { user } = await getUser();
  return (
    <html lang={lang === "hi" ? "hi" : "en-IN"}>
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2">Skip to content</a>
        <Header location={loc.name} lang={lang} signedIn={!!user} />
        <main id="main">{children}</main>
        <Footer />
        <JsonLd data={{ "@context": "https://schema.org", "@type": "Organization", name: SITE.name, url: SITE.url, email: SITE.email, parentOrganization: { "@type": "Organization", name: SITE.publisher } }} />
      </body>
    </html>
  );
}
