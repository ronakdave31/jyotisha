import type { Metadata } from "next";
import { Upcoming } from "@/components/Upcoming";
export const metadata: Metadata = { title: "Muhurat Finder", robots: { index: false } };
export default function Page() {
  return <Upcoming title="Muhurat finder" href="/muhurat" intro="Search auspicious windows for marriage, Griha Pravesh, vehicle purchase and more, using documented classical criteria."
    planned={["Rules engine for 16 activities with criteria drawn from Muhurta Chintamani, editable by your astrologer", "Lagna shuddhi, Tara and Chandra bala, Panchaka and Bhadra exclusions", "Exact start and end times with the reason each window qualifies", "Export to PDF and calendar (.ics)"]}
    meanwhile={[{ label: "Today's Choghadiya and Abhijit Muhurat", href: "/panchang#choghadiya" }, { label: "Festival & vrat calendar", href: "/festivals" }]} />;
}
