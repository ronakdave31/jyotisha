import type { Metadata } from "next";
import Link from "next/link";
import { DateTime } from "luxon";
import { sunriseSnapshot } from "@/lib/astro/panchang";
import { NAKSHATRAS, TITHIS } from "@/lib/astro/constants";
import { fmtTime, todayIn } from "@/lib/astro/time";
import { festivalCalendar } from "@/lib/astro/festivals";
import { getLocation } from "@/lib/request";
import { PageHeader, Disclaimer } from "@/components/ui";

export const metadata: Metadata = { title: "Monthly Panchang Calendar", description: "Month view of tithi and nakshatra at sunrise with festivals and vrat days for your city.", alternates: { canonical: "/panchang/month" } };

export default function MonthPage({ searchParams }: { searchParams: Record<string, string | undefined> }) {
  const loc = getLocation(searchParams);
  const month = /^\d{4}-\d{2}$/.test(searchParams.month ?? "") ? searchParams.month! : todayIn(loc.tz).slice(0, 7);
  const first = DateTime.fromISO(`${month}-01`, { zone: "UTC" });
  const dates = Array.from({ length: first.daysInMonth! }, (_, i) => first.plus({ days: i }).toISODate()!);
  const snaps = dates.map((d) => sunriseSnapshot(d, loc.lat, loc.lon, loc.tz));
  const events = festivalCalendar(dates[0], dates[dates.length - 1], loc.lat, loc.lon, loc.tz);
  const lead = first.weekday % 7;
  const today = todayIn(loc.tz);
  const extra: Record<string, string> = loc.slug ? { city: loc.slug } : { lat: String(loc.lat), lon: String(loc.lon), tz: loc.tz, name: loc.name };
  const nav = (m: DateTime) => `/panchang/month?${new URLSearchParams({ ...extra, month: m.toFormat("yyyy-MM") })}`;
  const dayLink = (d: string) => `/panchang?${new URLSearchParams({ ...extra, date: d })}`;

  return (
    <>
      <PageHeader title={`${first.toFormat("LLLL yyyy")} Panchang`} intro={`Tithi and nakshatra prevailing at sunrise in ${loc.name}, with festival and vrat days.`} crumbs={[{ name: "Daily Panchang", href: "/panchang" }, { name: "Month", href: "/panchang/month" }]}>
        <div className="mt-5 flex gap-2">
          <Link className="btn-ghost !py-2" href={nav(first.minus({ months: 1 }))}>‹ {first.minus({ months: 1 }).toFormat("LLLL")}</Link>
          <Link className="btn-ghost !py-2" href={nav(first.plus({ months: 1 }))}>{first.plus({ months: 1 }).toFormat("LLLL")} ›</Link>
        </div>
      </PageHeader>
      <div className="container py-10">
        <div className="grid grid-cols-7 gap-px overflow-hidden rounded-2xl border border-gold/30 bg-gold/30 text-sm" role="grid" aria-label={`${first.toFormat("LLLL yyyy")} calendar`}>
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => <div key={d} role="columnheader" className="bg-maroon py-2 text-center text-ivory">{d}</div>)}
          {Array.from({ length: lead }, (_, i) => <div key={`e${i}`} className="bg-ivory-deep/50" />)}
          {dates.map((d, i) => {
            const s = snaps[i];
            const ev = events.filter((e) => e.date === d);
            return (
              <Link key={d} href={dayLink(d)} role="gridcell" className={`min-h-[6.5rem] bg-white p-1.5 hover:bg-gold-pale/40 sm:p-2 ${d === today ? "ring-2 ring-inset ring-saffron" : ""}`}>
                <span className="font-display text-lg font-semibold text-maroon">{+d.slice(8)}</span>
                {s && (
                  <>
                    <span className="block text-[12px] leading-tight text-ink">{TITHIS[s.tithiAtSunrise].paksha[0]}. {TITHIS[s.tithiAtSunrise].en}</span>
                    <span className="hidden text-[11px] leading-tight text-ink-faint sm:block">{NAKSHATRAS[s.nakshatraAtSunrise].en}</span>
                    <span className="hidden text-[11px] text-ink-faint md:block">↑ {fmtTime(s.sunrise, loc.tz)}</span>
                  </>
                )}
                {ev.slice(0, 2).map((e) => <span key={e.id} className={`mt-0.5 block truncate rounded px-1 text-[11px] ${e.category === "festival" ? "bg-saffron/15 text-saffron-dark" : "bg-midnight/5 text-midnight"}`}>{e.name}</span>)}
              </Link>
            );
          })}
        </div>
        <Disclaimer />
      </div>
    </>
  );
}
