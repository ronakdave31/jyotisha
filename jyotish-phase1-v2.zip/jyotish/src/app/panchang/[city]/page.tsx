import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { computePanchang } from "@/lib/astro/panchang";
import { fmtDate, fmtTime, todayIn } from "@/lib/astro/time";
import { CITIES, findCity } from "@/lib/cities";
import { getLang } from "@/lib/request";
import { PageHeader, Faq, Disclaimer, JsonLd } from "@/components/ui";
import { PanchangFull, PANCHANG_GLOSSARY } from "@/components/PanchangLeaf";
import { DateNav } from "@/components/DateNav";
import { SITE } from "@/lib/site";

export const revalidate = 3600;
export function generateStaticParams() {
  return CITIES.filter((c) => c.featured).map((c) => ({ city: c.slug }));
}

export function generateMetadata({ params }: { params: { city: string } }): Metadata {
  const c = findCity(params.city);
  if (!c) return {};
  return {
    title: `Today's Panchang ${c.name} — Tithi, Rahu Kaal, Sunrise`,
    description: `Daily Panchang for ${c.name}, ${c.state || c.country}: today's Tithi, Nakshatra, sunrise and sunset, Rahu Kaal, Abhijit Muhurat and Choghadiya, calculated for ${c.name}'s coordinates.`,
    alternates: { canonical: `/panchang/${c.slug}` },
  };
}

export default function CityPanchang({ params, searchParams }: { params: { city: string }; searchParams: { date?: string } }) {
  const c = findCity(params.city);
  if (!c) notFound();
  const date = /^\d{4}-\d{2}-\d{2}$/.test(searchParams.date ?? "") ? searchParams.date! : todayIn(c.tz);
  const p = computePanchang({ date, lat: c.lat, lon: c.lon, tz: c.tz });
  const nearby = CITIES.filter((x) => x.featured && x.slug !== c.slug).slice(0, 8);
  return (
    <>
      <PageHeader title={`Panchang for ${c.name}`} intro={`${fmtDate(date, c.tz)}. Sunrise in ${c.name} is at ${fmtTime(p.sun.sunrise, c.tz)}; ${p.tithi[0].name} tithi runs until ${fmtTime(p.tithi[0].end, c.tz, date)}.`}
        crumbs={[{ name: "Daily Panchang", href: "/panchang" }, { name: c.name, href: `/panchang/${c.slug}` }]}>
        <DateNav date={date} basePath={`/panchang/${c.slug}`} />
      </PageHeader>
      <div className="container py-10">
        <PanchangFull p={p} place={`${c.name}, ${c.state || c.country}`} lang={getLang()} />
        <section className="mt-12">
          <h2 className="section-title">Panchang for other cities</h2>
          <p className="mt-3 flex flex-wrap gap-2">
            {nearby.map((n) => <Link key={n.slug} href={`/panchang/${n.slug}`} className="btn-ghost !py-1.5 text-sm">{n.name}</Link>)}
          </p>
        </section>
        <h2 className="section-title mt-14">Understanding the Panchang</h2>
        <div className="mt-5"><Faq items={PANCHANG_GLOSSARY} /></div>
        <Disclaimer />
      </div>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "WebPage", name: `Panchang for ${c.name}`, url: `${SITE.url}/panchang/${c.slug}`, about: { "@type": "Place", name: c.name, geo: { "@type": "GeoCoordinates", latitude: c.lat, longitude: c.lon } } }} />
    </>
  );
}
