import type { Metadata } from "next";
import Link from "next/link";
import { computePanchang } from "@/lib/astro/panchang";
import { todayIn } from "@/lib/astro/time";
import { getLang, getLocation } from "@/lib/request";
import { PageHeader, Faq, Disclaimer } from "@/components/ui";
import { PanchangFull, PANCHANG_GLOSSARY } from "@/components/PanchangLeaf";
import { DateNav } from "@/components/DateNav";
import { PlaceChooser } from "@/components/PlaceChooser";

export const metadata: Metadata = {
  title: "Today's Panchang — Tithi, Nakshatra, Rahu Kaal, Choghadiya",
  description: "Daily Panchang for your city: Tithi and Nakshatra with exact end times, Yoga, Karana, sunrise, Rahu Kaal, Abhijit Muhurat, Choghadiya and Hora.",
  alternates: { canonical: "/panchang" },
};

export default function PanchangPage({ searchParams }: { searchParams: Record<string, string | undefined> }) {
  const loc = getLocation(searchParams);
  const date = /^\d{4}-\d{2}-\d{2}$/.test(searchParams.date ?? "") ? searchParams.date! : todayIn(loc.tz);
  const lang = getLang();
  let p: ReturnType<typeof computePanchang> | null = null;
  let error = "";
  try { p = computePanchang({ date, lat: loc.lat, lon: loc.lon, tz: loc.tz }); } catch (e) { error = (e as Error).message; }
  const extra: Record<string, string> = loc.slug ? { city: loc.slug } : { lat: String(loc.lat), lon: String(loc.lon), tz: loc.tz, name: loc.name };

  return (
    <>
      <PageHeader title={`Panchang for ${loc.name}`} intro="Every timing below is calculated for this place and date from the positions of the Sun and Moon." crumbs={[{ name: "Daily Panchang", href: "/panchang" }]}>
        <DateNav date={date} basePath="/panchang" extra={extra} />
        <div className="mt-4 max-w-md"><PlaceChooser basePath="/panchang" date={date} /></div>
        <p className="mt-3 text-sm"><Link className="text-maroon underline" href={`/panchang/month?${new URLSearchParams({ ...extra, month: date.slice(0, 7) })}`}>Monthly calendar view</Link></p>
      </PageHeader>
      <div className="container py-10">
        {p ? <PanchangFull p={p} place={loc.name} lang={lang} /> : <p className="leaf p-5 text-maroon">{error}</p>}
        <h2 className="section-title mt-14">Understanding the Panchang</h2>
        <div className="mt-5"><Faq items={PANCHANG_GLOSSARY} /></div>
        <Disclaimer />
      </div>
    </>
  );
}
