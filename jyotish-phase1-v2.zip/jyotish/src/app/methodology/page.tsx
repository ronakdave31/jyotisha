import type { Metadata } from "next";
import { PageHeader } from "@/components/ui";
import { Prose } from "@/components/Prose";
import { ENGINE_VERSION } from "@/lib/astro/ephemeris";

export const metadata: Metadata = { title: "How We Calculate", description: "The astronomy, ayanamsa, sunrise definition and traditional rules behind our Panchang, Kundli and festival dates.", alternates: { canonical: "/methodology" } };

export default function Page() {
  return (
    <>
      <PageHeader title="How we calculate" intro="Astronomy and tradition are kept in separate layers, and both are documented here." crumbs={[{ name: "Methodology", href: "/methodology" }]} />
      <Prose>
        <h2>Astronomy</h2>
        <p>Planetary positions come from <strong>{ENGINE_VERSION}</strong> (MIT licence), which implements VSOP87 for the planets and a truncated ELP model for the Moon. Over 1800–2200 its positions agree with NASA JPL ephemerides to within an arcminute, which corresponds to a few seconds in tithi or nakshatra timings.</p>
        <p>Sidereal (nirayana) longitudes are found by removing nutation and subtracting the ayanamsa. The default is <strong>Lahiri (Chitrapaksha)</strong>, defined by the Indian Calendar Reform Committee as 23°15′00.658″ on 21 March 1956 and carried forward with the IAU 2006 precession model. Raman and Krishnamurti are available.</p>
        <p>Rahu and Ketu use the <strong>mean node</strong> by default, as most Indian almanacs do; the true node can be selected.</p>
        <h2>Sunrise and the Hindu day</h2>
        <p>Sunrise and sunset are the moments the Sun&apos;s upper limb touches the horizon with standard atmospheric refraction, at the chosen coordinates. The Hindu day runs from one sunrise to the next, so the tithi or nakshatra &quot;of the day&quot; is the one prevailing at sunrise.</p>
        <h2>Panchang rules</h2>
        <ul>
          <li>Tithi: each 12° of Moon–Sun elongation. Nakshatra: each 13°20′ of the Moon. Yoga: each 13°20′ of Sun + Moon. Karana: each 6° of elongation.</li>
          <li>Rahu Kaal, Yamaganda and Gulika: fixed eighths of daytime by weekday. Abhijit: the 8th of 15 daytime muhurtas. Brahma Muhurat: the 14th night muhurta before sunrise.</li>
          <li>Varjyam and Amrit Kaal: 4 ghatis beginning at the classical ghati offset for each nakshatra, scaled to that nakshatra&apos;s actual length.</li>
          <li>Lunar month (Amanta): named by the Sun&apos;s sign at the new moon that starts it; a month with no solar ingress is Adhik.</li>
        </ul>
        <h2>Festivals</h2>
        <p>Each festival is a rule: a lunar month, a tithi, and the time of day (karmakala) when that tithi must prevail — sunrise, midday, afternoon, Pradosh or midnight. Dates are computed for your coordinates. Where traditions disagree, the rule and a note are shown.</p>
        <h2>Kundli</h2>
        <p>Lagna from local sidereal time and true obliquity; whole-sign houses; Parashari divisional charts; Vimshottari Dasha with 365.25-day years. Interpretations come from documented Parashari rules and name the chart factor behind each statement.</p>
        <h2>Calculation records</h2>
        <p>Every saved chart stores the birth instant in UTC, coordinates, time zone, ayanamsa and its value, node type, house system and engine version, so it can be reproduced exactly.</p>
      </Prose>
    </>
  );
}
