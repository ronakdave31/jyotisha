import type { Metadata } from "next";
import Link from "next/link";
import { SAMSKARAS, KARMA_TYPES, PANCHA_MAHAYAJNA, VIDHIS } from "@/content/karmkand";
import { PageHeader, Faq } from "@/components/ui";
import { Diya } from "@/components/fx/Diya";

export const metadata: Metadata = {
  title: "Karmakand — 16 Samskaras, Daily Karma and Puja Vidhis",
  description: "Karmakand explained: the sixteen samskaras from Garbhadhana to Antyeshti, nitya, naimittika and kamya karma, the Pancha Mahayajna and step-by-step puja vidhis.",
  alternates: { canonical: "/karmkand" },
};

const STAGES = ["Before birth", "Childhood", "Education", "Household", "Life's end"] as const;

export default function Page() {
  return (
    <>
      <PageHeader title="Karmakand" intro="The ritual portion of the Veda (karma-kanda): the rites that mark each stage of life and the daily duties that sustain it." crumbs={[{ name: "Karmakand", href: "/karmkand" }]} />
      <div className="container space-y-16 py-12">
        <section aria-labelledby="samskaras">
          <h2 id="samskaras" className="section-title">The sixteen samskaras</h2>
          <p className="mt-2 max-w-2xl text-ink-soft">Shodasha samskara: sacraments that refine a person from conception to the last rites, as set out in the Grihya Sutras.</p>
          <div className="mt-8 space-y-10">
            {STAGES.map((stage) => (
              <div key={stage} className="reveal">
                <h3 className="font-display text-2xl font-semibold text-saffron-dark">{stage}</h3>
                <ol className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {SAMSKARAS.filter((s) => s.stage === stage).map((s) => (
                    <li key={s.n} className="lift leaf relative p-5">
                      <span className="absolute right-4 top-4 grid h-8 w-8 place-items-center rounded-full bg-maroon font-display text-sm font-semibold text-ivory" aria-label={`Samskara ${s.n} of 16`}>{s.n}</span>
                      <p className="pr-10 font-display text-xl font-semibold text-maroon">{s.name}</p>
                      <p className="font-deva text-ink-faint">{s.hi}</p>
                      <p className="mt-2 text-[15px] text-ink-soft">{s.what}</p>
                      <p className="mt-2 text-sm"><span className="text-ink-faint">When: </span>{s.when}</p>
                      <p className="mt-2 flex flex-wrap gap-3 text-sm">
                        {s.muhurat && <Link className="text-maroon underline" href="/muhurat">Find a muhurat</Link>}
                        {s.vidhi && <Link className="text-maroon underline" href={`/vidhi/${s.vidhi}`}>Vidhi</Link>}
                        {s.n === 15 && <Link className="text-maroon underline" href="/matching">Kundli matching</Link>}
                      </p>
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
        </section>

        <section aria-labelledby="types" className="reveal grid gap-8 lg:grid-cols-2">
          <div>
            <h2 id="types" className="section-title">Three kinds of karma</h2>
            <ul className="mt-5 space-y-3">
              {KARMA_TYPES.map((k) => (
                <li key={k.name} className="leaf p-4"><p className="font-display text-xl font-semibold text-maroon">{k.name} <span className="font-deva text-base text-ink-faint">{k.hi}</span></p><p className="text-ink-soft">{k.text}</p></li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl bg-midnight p-6 text-ivory">
            <div className="flex items-center gap-3"><Diya size={48} /><h2 className="font-display text-3xl font-semibold text-gold-pale">Pancha Mahayajna</h2></div>
            <p className="mt-2 text-ivory/75">Five daily offerings every householder owes, repaying the debts of life.</p>
            <ul className="mt-4 space-y-3">
              {PANCHA_MAHAYAJNA.map((y) => (
                <li key={y.name} className="flex gap-3 border-b border-ivory/10 pb-3 last:border-0"><span className="mt-1 text-saffron" aria-hidden>✦</span><span><span className="font-medium text-gold-pale">{y.name}</span> <span className="font-deva text-sm text-ivory/60">{y.hi}</span><span className="block text-sm text-ivory/80">{y.text}</span></span></li>
              ))}
            </ul>
          </div>
        </section>

        <section aria-labelledby="vidhis" className="reveal">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 id="vidhis" className="section-title">Puja vidhis</h2>
            <Link href="/vidhi" className="text-maroon underline">All vidhis</Link>
          </div>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {VIDHIS.map((v) => (
              <li key={v.slug}><Link href={`/vidhi/${v.slug}`} className="lift leaf block h-full p-5"><p className="font-display text-xl font-semibold text-maroon">{v.title}</p><p className="font-deva text-sm text-ink-faint">{v.hi}</p><p className="mt-2 text-sm text-ink-soft">{v.duration} · {v.steps.length} steps</p></Link></li>
            ))}
          </ul>
        </section>

        <section className="reveal">
          <h2 className="section-title">Questions</h2>
          <div className="mt-5"><Faq items={[
            { q: "Do I need a priest for these rituals?", a: "Major samskaras such as Upanayana and Vivaha are traditionally conducted by a purohit. Daily puja, sandhya and many festival pujas are done by the family itself; the vidhis here are written for that." },
            { q: "Why do vidhis differ between families?", a: "Rituals follow the Grihya Sutra of one's Veda shakha, plus regional and family custom (kula-achara). Where your family's practice differs from what is written here, follow your family." },
            { q: "How do I choose a date?", a: "Samskaras are timed by Muhurat, using tithi, nakshatra, weekday and lagna. Today's Panchang shows these, and the Muhurat finder will rank dates automatically." },
          ]} /></div>
        </section>
      </div>
    </>
  );
}
