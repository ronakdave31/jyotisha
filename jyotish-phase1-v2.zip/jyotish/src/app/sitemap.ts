import type { MetadataRoute } from "next";
import { CITIES } from "@/lib/cities";
import { SITE } from "@/lib/site";
import { MANTRAS } from "@/content/mantras";
import { VIDHIS } from "@/content/karmkand";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const core = ["", "/panchang", "/panchang/month", "/kundli", "/matching", "/numerology", "/festivals", "/horoscope", "/transits", "/astrology", "/vedas", "/shlokas", "/mantras", "/karmkand", "/vidhi", "/methodology", "/disclaimer", "/privacy", "/terms"];
  return [
    ...core.map((p) => ({ url: SITE.url + p, lastModified: now, changeFrequency: p.includes("panchang") || p === "" ? "daily" as const : "weekly" as const, priority: p === "" ? 1 : 0.8 })),
    // Curated cities only, to avoid thin duplicate pages
    ...CITIES.filter((c) => c.featured).map((c) => ({ url: `${SITE.url}/panchang/${c.slug}`, lastModified: now, changeFrequency: "daily" as const, priority: 0.7 })),
    ...MANTRAS.map((m) => ({ url: `${SITE.url}/mantras/${m.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.6 })),
    ...VIDHIS.map((v) => ({ url: `${SITE.url}/vidhi/${v.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.6 })),
    ...Array.from({ length: 12 }, (_, i) => ({ url: `${SITE.url}/horoscope/${i}`, lastModified: now, changeFrequency: "daily" as const, priority: 0.6 })),
  ];
}
