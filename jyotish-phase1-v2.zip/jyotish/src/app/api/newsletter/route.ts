import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, rateLimit } from "@/lib/api";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: NextRequest) {
  const limited = rateLimit(req, 5);
  if (limited) return limited;
  const parsed = z.object({ email: z.string().email().max(200) }).safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Please enter a valid email address.");
  const sb = createClient();
  if (!sb) return NextResponse.json({ error: "Newsletter is not configured yet." }, { status: 503 });
  const { error } = await sb.from("newsletter_subscribers").insert({ email: parsed.data.email, source: "website" });
  if (error && error.code !== "23505") return NextResponse.json({ error: "Could not subscribe right now." }, { status: 500 });
  return NextResponse.json({ ok: true });
}
