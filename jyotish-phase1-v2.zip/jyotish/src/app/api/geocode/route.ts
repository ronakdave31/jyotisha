import { NextResponse, type NextRequest } from "next/server";
import tzlookup from "@photostructure/tz-lookup";
import { rateLimit } from "@/lib/api";
import { searchCities } from "@/lib/cities";

/**
 * GET /api/geocode?q=place
 * Curated cities first; then OpenStreetMap Nominatim when GEOCODER=nominatim.
 * Nominatim usage policy: max 1 req/s, identify the app via User-Agent, cache results.
 */
export async function GET(req: NextRequest) {
  const limited = rateLimit(req, 30);
  if (limited) return limited;
  const q = (req.nextUrl.searchParams.get("q") ?? "").trim().slice(0, 100);
  const local = searchCities(q).map((c) => ({ name: c.name, region: [c.state, c.country].filter(Boolean).join(", "), lat: c.lat, lon: c.lon, tz: c.tz, slug: c.slug, source: "curated" }));
  if (q.length < 3 || local.length >= 5 || process.env.GEOCODER !== "nominatim") return NextResponse.json({ results: local });
  try {
    const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&addressdetails=1&q=${encodeURIComponent(q)}`;
    const res = await fetch(url, {
      headers: { "User-Agent": process.env.GEOCODER_USER_AGENT || "JyotishPlatform/1.0", "Accept-Language": "en" },
      next: { revalidate: 60 * 60 * 24 * 30 },
    });
    if (!res.ok) throw new Error(`Nominatim ${res.status}`);
    const rows = (await res.json()) as { display_name: string; lat: string; lon: string; name?: string }[];
    const remote = rows.map((r) => {
      const lat = Number(r.lat), lon = Number(r.lon);
      return { name: r.name || r.display_name.split(",")[0], region: r.display_name.split(",").slice(1, 3).join(",").trim(), lat, lon, tz: tzlookup(lat, lon), source: "nominatim" };
    });
    return NextResponse.json({ results: [...local, ...remote].slice(0, 8) });
  } catch (e) {
    console.error("[geocode]", e);
    return NextResponse.json({ results: local, warning: "External geocoder unavailable; showing curated cities only." });
  }
}
