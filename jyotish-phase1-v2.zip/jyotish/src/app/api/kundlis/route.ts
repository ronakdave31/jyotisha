import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, rateLimit, zBirth } from "@/lib/api";
import { computeKundli } from "@/lib/astro/kundli";
import { getUser } from "@/lib/supabase/server";

/** GET /api/kundlis — list saved charts. */
export async function GET() {
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const { data, error } = await sb.from("saved_kundlis").select("id,title,summary,created_at,birth_profile_id").order("created_at", { ascending: false });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ kundlis: data });
}

/**
 * POST /api/kundlis — recompute on the server (never trust a client-supplied chart)
 * and store it with full calculation metadata.
 */
export async function POST(req: NextRequest) {
  const limited = rateLimit(req, 20);
  if (limited) return limited;
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const parsed = z.object({ birth: zBirth, birth_profile_id: z.string().uuid().optional() }).safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad(parsed.error);
  const k = computeKundli(parsed.data.birth);

  const { data: run, error: runErr } = await sb.from("calculation_runs").insert({
    kind: "kundli", input_utc: k.meta.birth.utc, lat: k.meta.birth.lat, lon: k.meta.birth.lon, tz: k.meta.birth.tz,
    ayanamsa: k.meta.ayanamsa, ayanamsa_value_deg: k.meta.ayanamsaValue, node_type: k.meta.node, house_system: "whole_sign", engine: k.meta.engine,
  }).select("id").single();
  if (runErr) return NextResponse.json({ error: runErr.message }, { status: 500 });

  const { data, error } = await sb.from("saved_kundlis").insert({
    user_id: user.id,
    birth_profile_id: parsed.data.birth_profile_id ?? null,
    calculation_run_id: run.id,
    title: parsed.data.birth.name || `Chart ${parsed.data.birth.date}`,
    summary: k.summary,
    chart: k,
  }).select("id").single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await sb.from("planetary_positions").insert([
    { calculation_run_id: run.id, body: "Ascendant", longitude_deg: k.ascendant.lon, sign: k.ascendant.sign, nakshatra: k.ascendant.nakshatraIndex, pada: k.ascendant.pada, house: 1 },
    ...k.planets.map((p) => ({
      calculation_run_id: run.id, body: p.planet, longitude_deg: p.lon, sign: p.sign, nakshatra: p.nakshatraIndex, pada: p.pada,
      house: p.house, speed_deg_day: p.speed, retrograde: p.retrograde, combust: p.combust, dignity: p.dignity,
    })),
  ]);
  return NextResponse.json({ id: data.id }, { status: 201 });
}
