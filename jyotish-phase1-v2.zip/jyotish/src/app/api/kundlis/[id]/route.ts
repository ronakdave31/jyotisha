import { NextResponse } from "next/server";
import { getUser } from "@/lib/supabase/server";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const { data, error } = await sb.from("saved_kundlis").select("*").eq("id", params.id).single();
  if (error) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(data);
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const { error } = await sb.from("saved_kundlis").delete().eq("id", params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
