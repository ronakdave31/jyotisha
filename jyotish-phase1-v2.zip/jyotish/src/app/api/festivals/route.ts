import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, cached, rateLimit, serverError, zDate, zLat, zLon, zTz } from "@/lib/api";
import { festivalCalendar } from "@/lib/astro/festivals";
import { addDays, todayIn } from "@/lib/astro/time";
import { findCity } from "@/lib/cities";

const schema = z.object({ from: zDate.optional(), days: z.coerce.number().int().min(1).max(400).default(90), lat: zLat, lon: zLon, tz: zTz });

/** GET /api/festivals?city=| lat,lon,tz [&from=YYYY-MM-DD&days=90] */
export async function GET(req: NextRequest) {
  const limited = rateLimit(req, 30);
  if (limited) return limited;
  const sp = Object.fromEntries(req.nextUrl.searchParams);
  const city = findCity(sp.city);
  const parsed = schema.safeParse(city ? { ...sp, lat: city.lat, lon: city.lon, tz: city.tz } : sp);
  if (!parsed.success) return bad(parsed.error);
  const { lat, lon, tz, days } = parsed.data;
  const from = parsed.data.from ?? todayIn(tz);
  try {
    const events = cached(`f:${from}:${days}:${lat}:${lon}:${tz}`, 24 * 3600e3, () => festivalCalendar(from, addDays(from, days - 1), lat, lon, tz));
    return NextResponse.json({ from, days, events }, { headers: { "Cache-Control": "public, s-maxage=21600" } });
  } catch (e) {
    return serverError(e);
  }
}
