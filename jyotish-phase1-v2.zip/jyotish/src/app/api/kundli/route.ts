import { NextResponse, type NextRequest } from "next/server";
import { bad, cached, rateLimit, serverError, zBirth } from "@/lib/api";
import { computeKundli } from "@/lib/astro/kundli";
import { interpret } from "@/lib/astro/interpretations";

/** POST /api/kundli  body: { name?, date, time, tz, lat, lon, place?, gender?, ayanamsa?, node? } */
export async function POST(req: NextRequest) {
  const limited = rateLimit(req, 30);
  if (limited) return limited;
  const parsed = zBirth.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad(parsed.error);
  try {
    const key = `k:${JSON.stringify(parsed.data)}:${new Date().toISOString().slice(0, 10)}`;
    const result = cached(key, 3600e3, () => {
      const k = computeKundli(parsed.data);
      return { ...k, interpretation: interpret(k) };
    });
    return NextResponse.json(result, { headers: { "Cache-Control": "private, no-store" } });
  } catch (e) {
    return serverError(e);
  }
}
