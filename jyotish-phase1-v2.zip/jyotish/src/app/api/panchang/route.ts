import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, cached, rateLimit, serverError, zAyanamsa, zDate, zLat, zLon, zTz } from "@/lib/api";
import { computePanchang } from "@/lib/astro/panchang";
import { addDays, todayIn } from "@/lib/astro/time";
import { findCity } from "@/lib/cities";

const schema = z.object({
  date: zDate.optional(),
  lat: zLat, lon: zLon, tz: zTz,
  ayanamsa: zAyanamsa,
  days: z.coerce.number().int().min(1).max(31).default(1),
});

/** GET /api/panchang?city=mumbai | ?lat=&lon=&tz=  [&date=YYYY-MM-DD&days=1..31&ayanamsa=lahiri] */
export async function GET(req: NextRequest) {
  const limited = rateLimit(req, 120);
  if (limited) return limited;
  const sp = Object.fromEntries(req.nextUrl.searchParams);
  const city = findCity(sp.city);
  const parsed = schema.safeParse(city ? { ...sp, lat: city.lat, lon: city.lon, tz: city.tz } : sp);
  if (!parsed.success) return bad(parsed.error);
  const { lat, lon, tz, ayanamsa, days } = parsed.data;
  const start = parsed.data.date ?? todayIn(tz);
  try {
    const results = Array.from({ length: days }, (_, i) => {
      const date = addDays(start, i);
      return cached(`p:${date}:${lat}:${lon}:${tz}:${ayanamsa}`, 6 * 3600e3, () => computePanchang({ date, lat, lon, tz, ayanamsa }));
    });
    return NextResponse.json(days === 1 ? results[0] : { days: results }, {
      headers: { "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400" },
    });
  } catch (e) {
    return serverError(e);
  }
}
