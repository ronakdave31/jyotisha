import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, rateLimit, serverError, zBirth } from "@/lib/api";
import { matchProfiles } from "@/lib/astro/matching";

const schema = z.object({ boy: zBirth, girl: zBirth });

/** POST /api/matching  body: { boy: BirthInput, girl: BirthInput } */
export async function POST(req: NextRequest) {
  const limited = rateLimit(req, 30);
  if (limited) return limited;
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad(parsed.error);
  try {
    return NextResponse.json(matchProfiles(parsed.data.boy, parsed.data.girl), { headers: { "Cache-Control": "private, no-store" } });
  } catch (e) {
    return serverError(e);
  }
}
