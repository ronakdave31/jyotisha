import { NextResponse } from "next/server";
import { getUser } from "@/lib/supabase/server";

/** DELETE /api/profiles/:id — RLS guarantees users can only delete their own rows. */
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const { error } = await sb.from("birth_profiles").delete().eq("id", params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
