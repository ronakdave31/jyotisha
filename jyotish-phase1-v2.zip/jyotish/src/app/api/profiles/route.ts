import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, rateLimit, zDate, zLat, zLon, zTime, zTz } from "@/lib/api";
import { getUser } from "@/lib/supabase/server";

const profileSchema = z.object({
  label: z.string().trim().min(1).max(40),
  relation: z.string().max(40).optional(),
  full_name: z.string().trim().min(1).max(80),
  gender: z.enum(["male", "female", "other"]).optional(),
  birth_date: zDate,
  birth_time: zTime,
  time_accuracy: z.enum(["exact", "approximate", "unknown"]).default("exact"),
  place_name: z.string().max(160).optional(),
  lat: zLat, lon: zLon, tz: zTz,
  is_primary: z.boolean().default(false),
});

/** GET /api/profiles — the signed-in user's birth profiles (family members included). */
export async function GET() {
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const { data, error } = await sb.from("birth_profiles").select("*").order("is_primary", { ascending: false }).order("created_at");
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ profiles: data });
}

/** POST /api/profiles — create a birth profile. */
export async function POST(req: NextRequest) {
  const limited = rateLimit(req, 20);
  if (limited) return limited;
  const { sb, user } = await getUser();
  if (!sb || !user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const parsed = profileSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad(parsed.error);
  if (parsed.data.is_primary) await sb.from("birth_profiles").update({ is_primary: false }).eq("user_id", user.id);
  const { data, error } = await sb.from("birth_profiles").insert({ ...parsed.data, user_id: user.id }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ profile: data }, { status: 201 });
}
