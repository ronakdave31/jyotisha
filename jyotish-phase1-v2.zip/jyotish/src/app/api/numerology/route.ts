import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { bad, rateLimit, zDate } from "@/lib/api";
import { nameNumber, numerologyReport } from "@/lib/numerology";

const schema = z.object({
  name: z.string().trim().min(1).max(120),
  dob: zDate.optional(),
  system: z.enum(["pythagorean", "chaldean"]).default("pythagorean"),
  type: z.enum(["personal", "name", "business", "baby"]).default("personal"),
});

/** POST /api/numerology  body: { name, dob?, system?, type? } */
export async function POST(req: NextRequest) {
  const limited = rateLimit(req, 60);
  if (limited) return limited;
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad(parsed.error);
  const { name, dob, system, type } = parsed.data;
  if (type === "personal") {
    if (!dob) return bad("dob is required for a personal report");
    return NextResponse.json(numerologyReport(name, dob, system));
  }
  return NextResponse.json(nameNumber(name, system));
}
