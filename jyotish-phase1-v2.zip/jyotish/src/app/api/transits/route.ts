import { NextResponse, type NextRequest } from "next/server";
import { gochar } from "@/lib/astro/kundli";
import { rateLimit } from "@/lib/api";

/** GET /api/transits?moon=0..11&lagna=0..11 — current sidereal positions with houses from Moon/Lagna. */
export async function GET(req: NextRequest) {
  const limited = rateLimit(req, 60);
  if (limited) return limited;
  const moon = Number(req.nextUrl.searchParams.get("moon") ?? 0);
  const lagna = Number(req.nextUrl.searchParams.get("lagna") ?? moon);
  if (![moon, lagna].every((n) => Number.isInteger(n) && n >= 0 && n < 12)) return NextResponse.json({ error: "moon/lagna must be 0–11" }, { status: 400 });
  return NextResponse.json({ at: new Date().toISOString(), transits: gochar(moon, lagna) });
}
