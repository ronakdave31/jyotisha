import { NextResponse, type NextRequest } from "next/server";
import { horoscopeFor } from "@/lib/astro/horoscope";
import { rateLimit } from "@/lib/api";

/** GET /api/horoscope?sign=0..11 — transit-based reading for the current moment (all 12 signs if omitted). */
export async function GET(req: NextRequest) {
  const limited = rateLimit(req, 120);
  if (limited) return limited;
  const s = req.nextUrl.searchParams.get("sign");
  const now = new Date();
  if (s !== null) {
    const n = Number(s);
    if (!Number.isInteger(n) || n < 0 || n > 11) return NextResponse.json({ error: "sign must be 0–11" }, { status: 400 });
    return NextResponse.json(horoscopeFor(n, now));
  }
  return NextResponse.json({ at: now.toISOString(), signs: Array.from({ length: 12 }, (_, i) => horoscopeFor(i, now)) }, {
    headers: { "Cache-Control": "public, s-maxage=1800" },
  });
}
