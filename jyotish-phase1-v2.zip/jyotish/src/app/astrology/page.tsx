import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui";

export const metadata: Metadata = { title: "Vedic Astrology Tools", description: "All free Vedic astrology calculators: Kundli, Rashi and Nakshatra finder, Lagna, Dasha, Manglik, Kaal Sarp, Sade Sati, transits, matching and horoscope.", alternates: { canonical: "/astrology" } };

const TOOLS = [
  { h: "Kundli (birth chart)", p: "North and South Indian charts with 16 divisional charts.", href: "/kundli" },
  { h: "Rashi, Nakshatra & Lagna finder", p: "Your Moon sign, birth star with pada, and ascendant — shown at the top of every Kundli.", href: "/kundli" },
  { h: "Vimshottari Dasha calculator", p: "Mahadasha, Antardasha and Pratyantardasha with exact dates.", href: "/kundli" },
  { h: "Manglik Dosha check", p: "Mars from Lagna, Moon and Venus, with classical mitigations.", href: "/kundli" },
  { h: "Kaal Sarp Dosha check", p: "Whether all planets fall between Rahu and Ketu, and which type.", href: "/kundli" },
  { h: "Sade Sati calculator", p: "Every Sade Sati cycle of your life, phase by phase.", href: "/kundli" },
  { h: "Kundli matching", p: "Ashta Koota Gun Milan with dosha analysis.", href: "/matching" },
  { h: "Daily horoscope", p: "Transit-based readings for the 12 Rashis.", href: "/horoscope" },
  { h: "Planetary transit tracker", p: "Positions, retrogrades and sign changes.", href: "/transits" },
  { h: "Numerology", p: "Pythagorean and Chaldean reports, name and compatibility numbers.", href: "/numerology" },
];

export default function Page() {
  return (
    <>
      <PageHeader title="Astrology tools" intro="Every personalised result is calculated from your actual birth details." crumbs={[{ name: "Astrology", href: "/astrology" }]} />
      <ul className="container grid gap-4 py-10 sm:grid-cols-2 lg:grid-cols-3">
        {TOOLS.map((t) => (
          <li key={t.h}><Link href={t.href} className="leaf block h-full p-5 hover:border-saffron"><h2 className="font-display text-xl font-semibold text-maroon">{t.h}</h2><p className="mt-1 text-ink-soft">{t.p}</p></Link></li>
        ))}
      </ul>
    </>
  );
}
