import type { Metadata } from "next";
import { PageHeader } from "@/components/ui";
import { Prose } from "@/components/Prose";
export const metadata: Metadata = { title: "Terms of Use", alternates: { canonical: "/terms" } };
export default function Page() {
  return (<><PageHeader title="Terms of use" intro="Template for legal review before launch." crumbs={[{ name: "Terms", href: "/terms" }]} /><Prose>
    <p>The calculators are provided for personal, cultural and educational use. Results are offered as traditional guidance without warranty of any outcome.</p>
    <p>You may not scrape the site or use the API beyond its published rate limits. Content, design and code remain the property of the site owner.</p>
    <p>Paid reports and consultations, when available, will carry their own refund terms shown at checkout.</p>
  </Prose></>);
}
