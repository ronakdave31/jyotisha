import type { Metadata } from "next";
import { LoginForm } from "@/components/LoginForm";
export const metadata: Metadata = { title: "Sign in", robots: { index: false } };
export default function Page({ searchParams }: { searchParams: { next?: string } }) {
  const next = searchParams.next?.startsWith("/") && !searchParams.next.startsWith("//") ? searchParams.next : "/dashboard";
  return (
    <div className="container grid min-h-[60vh] place-items-center py-14">
      <div className="leaf w-full max-w-md p-7">
        <h1 className="font-display text-4xl font-bold text-maroon">Sign in</h1>
        <p className="mb-6 mt-1 text-ink-soft">Save birth profiles for your family and keep your Kundlis in one place.</p>
        <LoginForm next={next} />
      </div>
    </div>
  );
}
