import Link from "next/link";
import { computePanchang } from "@/lib/astro/panchang";
import { siderealLongitude } from "@/lib/astro/ephemeris";
import { PLANETS, RASHIS, ZODIAC_GLYPH } from "@/lib/astro/constants";
import { horoscopeFor } from "@/lib/astro/horoscope";
import { festivalCalendar } from "@/lib/astro/festivals";
import { addDays, fmtDate, fmtTime, todayIn } from "@/lib/astro/time";
import { getLang, getLocation } from "@/lib/request";
import { cached } from "@/lib/api";
import { SkyDial } from "@/components/SkyDial";
import { PanchangSummary } from "@/components/PanchangLeaf";
import { QuickKundli } from "@/components/forms/QuickKundli";
import { ChantCounter } from "@/components/forms/ChantCounter";
import { Newsletter } from "@/components/forms/Newsletter";
import { Faq, JsonLd } from "@/components/ui";
import { StarField } from "@/components/fx/StarField";
import { Ticker } from "@/components/fx/Ticker";
import { ShlokaDeck } from "@/components/fx/ShlokaDeck";
import { ReciteAlong } from "@/components/fx/ReciteAlong";
import { Diya } from "@/components/fx/Diya";
import { Mandala } from "@/components/fx/Mandala";
import { SHLOKAS, shlokaOfDay } from "@/content/shlokas";
import { findMantra } from "@/content/mantras";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

const FAQS = [
  { q: "How accurate are the Panchang timings?", a: "Positions come from Astronomy Engine, which tracks the Sun and Moon to well under an arcminute. Tithi and Nakshatra end times are found to the second and shown to the minute. Small differences from printed almanacs usually come from a different ayanamsa, sunrise definition or city coordinates." },
  { q: "Which ayanamsa do you use?", a: "Lahiri (Chitrapaksha), the Government of India standard, by default. Raman and Krishnamurti can be chosen for Kundli calculations." },
  { q: "Do I need an account?", a: "No. Every calculator works without signing in. An account lets you save birth profiles for your family and keep your Kundlis." },
  { q: "Is my birth data private?", a: "Saved birth details are visible only to you; the database enforces this with row-level security. Charts you do not save are not stored." },
];

export default function Home() {
  const loc = getLocation();
  const lang = getLang();
  const today = todayIn(loc.tz);
  const now = new Date();
  const p = cached(`p:${today}:${loc.lat}:${loc.lon}:${loc.tz}:lahiri`, 6 * 3600e3, () => computePanchang({ date: today, lat: loc.lat, lon: loc.lon, tz: loc.tz }));
  const positions = PLANETS.map((planet) => ({ planet, lon: siderealLongitude(planet, now) }));
  const moonNak = Math.floor(positions[1].lon / (360 / 27));
  const signs = Array.from({ length: 12 }, (_, i) => horoscopeFor(i, now));
  const events = cached(`home-f:${today}:${loc.lat}:${loc.lon}`, 6 * 3600e3, () => festivalCalendar(today, addDays(today, 45), loc.lat, loc.lon, loc.tz));
  const festivals = events.filter((e) => e.category === "festival").slice(0, 5);
  const vrats = events.filter((e) => e.category !== "festival").slice(0, 6);
  const goodChog = p.choghadiya.day.filter((c) => ["Amrit", "Shubh", "Labh"].includes(c.name));
  const gayatri = findMantra("gayatri-mantra")!;
  const nowChog = [...p.choghadiya.day, ...p.choghadiya.night].find((c) => now >= new Date(c.start) && now < new Date(c.end));

  return (
    <>
      {/* Hero: the live sky */}
      <section className="relative overflow-hidden bg-midnight text-ivory">
        <StarField />
        <div className="pointer-events-none absolute -left-40 bottom-[-12rem] text-gold/10" aria-hidden><Mandala size={520} /></div>
        <div className="container relative grid items-center gap-10 py-14 md:grid-cols-[1.05fr_1fr] md:py-20">
          <div className="stagger">
            <p className="font-deva text-lg text-gold-light">ज्योतिषं नेत्रमुच्यते</p>
            <h1 className="mt-3 font-display text-5xl font-bold leading-[1.05] md:text-6xl">Discover the Wisdom of Vedic Astrology</h1>
            <p className="mt-5 max-w-lg text-lg text-ivory/80">
              Panchang, Kundli and festival dates worked out from the real positions of the Sun, Moon and planets, for your city and your moment of birth.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/kundli" className="btn-primary">Generate Kundli</Link>
              <Link href="/panchang" className="btn border border-gold/50 text-gold-pale hover:bg-white/5">Today&apos;s Panchang</Link>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-2 gap-x-6 gap-y-3 text-sm">
              <div><dt className="text-ivory/60">Hindu date</dt><dd className="text-ivory">{p.masa.purnimanta.en} {p.paksha} {p.tithi[0].name}</dd></div>
              <div><dt className="text-ivory/60">Samvat</dt><dd className="text-ivory">Vikram {p.samvat.vikramChaitradi}, Shaka {p.samvat.shaka}</dd></div>
              <div><dt className="text-ivory/60">Lunar phase</dt><dd className="text-ivory">{p.moon.phaseName}, {(p.moon.illumination * 100).toFixed(0)}% lit</dd></div>
              <div><dt className="text-ivory/60">Choghadiya now</dt><dd className="text-ivory">{nowChog ? `${nowChog.name} until ${fmtTime(nowChog.end, loc.tz)}` : "—"}</dd></div>
            </dl>
          </div>
          <div className="floaty mx-auto w-full max-w-[460px]" style={{ animation: "rise 1s .2s both, floaty 6s 1.2s ease-in-out infinite" }}>
            <SkyDial positions={positions} moonNakshatra={moonNak} />
            <p className="mt-2 text-center text-xs text-ivory/50">The sidereal sky at {fmtTime(now, loc.tz)}, {loc.tz}. Hover a planet for its degree.</p>
          </div>
        </div>
      </section>

      <Ticker items={[
        { label: "Tithi", value: `${p.paksha} ${p.tithi[0].name} until ${fmtTime(p.tithi[0].end, loc.tz, today)}` },
        { label: "Nakshatra", value: `${p.nakshatra[0].name} until ${fmtTime(p.nakshatra[0].end, loc.tz, today)}` },
        { label: "Yoga", value: p.yoga[0].name },
        { label: "Sunrise", value: fmtTime(p.sun.sunrise, loc.tz) },
        { label: "Rahu Kaal", value: (() => { const r = p.inauspicious.find((w) => w.name === "Rahu Kaal")!; return `${fmtTime(r.start, loc.tz)} – ${fmtTime(r.end, loc.tz)}`; })() },
        { label: "Abhijit", value: (() => { const a = p.auspicious[0]; return `${fmtTime(a.start, loc.tz)} – ${fmtTime(a.end, loc.tz)}`; })() },
        ...(festivals[0] ? [{ label: "Next festival", value: `${festivals[0].name}, ${fmtDate(festivals[0].date, "UTC", "d LLL")}` }] : []),
        { label: loc.name, value: `${p.masa.amanta.en} ${p.paksha}, VS ${p.samvat.vikramChaitradi}` },
      ]} />

      {/* Today */}
      <section className="reveal container grid gap-8 py-14 lg:grid-cols-[1.5fr_1fr]">
        <div>
          <div className="mb-4 flex items-end justify-between gap-4">
            <h2 className="section-title">Today&apos;s Panchang</h2>
            <Link href="/panchang" className="text-maroon underline">Full Panchang</Link>
          </div>
          <PanchangSummary p={p} place={loc.name} lang={lang} />
        </div>
        <div>
          <h2 className="section-title mb-4">Auspicious today</h2>
          <div className="leaf p-5">
            <ul className="space-y-2 text-[15px]">
              {p.auspicious.map((w, i) => (
                <li key={i} className="flex justify-between gap-3"><span>{w.name}</span><span className="tabular-nums text-ink-soft">{fmtTime(w.start, loc.tz, today)} – {fmtTime(w.end, loc.tz, today)}</span></li>
              ))}
              {goodChog.map((c, i) => (
                <li key={`c${i}`} className="flex justify-between gap-3"><span>{c.name} Choghadiya</span><span className="tabular-nums text-ink-soft">{fmtTime(c.start, loc.tz)} – {fmtTime(c.end, loc.tz)}</span></li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Kundli quick form + festivals */}
      <section className="border-y border-gold/20 bg-ivory-deep/60 lotus-bg">
        <div className="container grid gap-10 py-14 lg:grid-cols-2">
          <div>
            <h2 className="section-title">Your birth chart in a minute</h2>
            <p className="mt-2 max-w-md text-ink-soft">Lagna, planets with nakshatra and pada, Navamsa and fifteen other divisional charts, Vimshottari Dasha, yogas, Manglik and Sade Sati.</p>
            <div className="leaf mt-6 p-5"><QuickKundli /></div>
          </div>
          <div>
            <div className="flex items-end justify-between"><h2 className="section-title">Coming up</h2><Link href="/festivals" className="text-maroon underline">Festival calendar</Link></div>
            <ol className="mt-6 space-y-3">
              {festivals.map((f) => (
                <li key={f.id} className="lift flex items-center gap-4 rounded-xl border border-gold/25 bg-white/70 p-3">
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-lg bg-maroon text-center leading-none text-ivory">
                    <span className="font-display text-2xl font-semibold">{+f.date.slice(8)}</span>
                    <span className="text-[11px]">{fmtDate(f.date, "UTC", "LLL")}</span>
                  </span>
                  <span><span className="block font-medium">{f.name}</span><span className="text-sm text-ink-faint">{fmtDate(f.date, "UTC", "cccc")} · {f.tithi}</span></span>
                </li>
              ))}
            </ol>
            <p className="mt-5 text-sm text-ink-soft">
              Vrat days: {vrats.map((v, i) => <span key={v.id}>{i > 0 && ", "}{v.name} {fmtDate(v.date, "UTC", "d LLL")}</span>)}
            </p>
          </div>
        </div>
      </section>

      {/* Horoscope */}
      <section className="reveal container py-14">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="section-title">Daily horoscope by Moon sign</h2>
            <p className="mt-1 text-ink-soft">Read from today&apos;s planetary transits counted from your Rashi.</p>
          </div>
          <Link href="/horoscope" className="text-maroon underline">All horoscopes</Link>
        </div>
        <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {signs.map((s, i) => (
            <li key={s.sign}>
              <Link href={`/horoscope/${i}`} className="lift flex h-full flex-col rounded-xl border border-gold/25 bg-white/70 p-4">
                <span className="flex items-center justify-between">
                  <span className="glyph inline-block text-2xl text-gold" aria-hidden>{ZODIAC_GLYPH[i]}</span>
                  <span className="text-xs text-ink-faint" aria-label={`${s.rating} of 5`}>{"●".repeat(s.rating)}{"○".repeat(5 - s.rating)}</span>
                </span>
                <span className="mt-2 font-display text-xl font-semibold text-maroon">{s.sign} <span className="font-deva text-base text-ink-faint">{RASHIS[i].hi}</span></span>
                <span className="text-xs text-ink-faint">{s.western}{s.chandrashtama && " · Chandrashtama"}</span>
                <span className="mt-2 line-clamp-3 text-sm text-ink-soft">{s.daily}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* Tools */}
      <section className="bg-maroon text-ivory">
        <div className="container grid gap-6 py-14 md:grid-cols-3">
          {[
            { h: "Kundli matching", p: "Ashta Koota Gun Milan out of 36, with Nadi and Bhakoot dosha checks and Manglik compatibility.", href: "/matching", cta: "Match two charts" },
            { h: "Numerology", p: "Life Path, Destiny, Soul Urge and name numbers in both the Pythagorean and Chaldean systems.", href: "/numerology", cta: "Calculate numbers" },
            { h: "Planet transits", p: "Where every graha is today, when it changes sign, and which planets are retrograde.", href: "/transits", cta: "See transits" },
          ].map((t) => (
            <div key={t.h} className="lift rounded-2xl border border-gold/30 p-6">
              <h3 className="font-display text-2xl font-semibold text-gold-pale">{t.h}</h3>
              <p className="mt-2 text-ivory/80">{t.p}</p>
              <Link href={t.href} className="mt-4 inline-block font-medium text-gold-light underline">{t.cta}</Link>
            </div>
          ))}
        </div>
      </section>

      {/* Spiritual library */}
      <section className="reveal border-y border-gold/20 bg-ivory-deep/60 lotus-bg">
        <div className="container py-14">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="section-title">Sanatan library</h2>
              <p className="mt-1 max-w-xl text-ink-soft">Vedas, shlokas, mantras, samskaras and puja vidhis, each with its source and meaning.</p>
            </div>
            <Diya size={60} />
          </div>
          <ul className="stagger mt-8 grid grid-cols-2 gap-4 md:grid-cols-5">
            {[
              { h: "Vedas", hi: "वेद", p: "Four Vedas, six Vedangas, ten Upanishads", href: "/vedas" },
              { h: "Shlokas", hi: "श्लोक", p: "Gita and Upanishads with meaning", href: "/shlokas" },
              { h: "Mantras", hi: "मन्त्र", p: "Recite along with a mala counter", href: "/mantras" },
              { h: "Karmakand", hi: "कर्मकाण्ड", p: "The sixteen samskaras of life", href: "/karmkand" },
              { h: "Puja vidhi", hi: "पूजा विधि", p: "Step-by-step puja mode", href: "/vidhi" },
            ].map((t) => (
              <li key={t.h}>
                <Link href={t.href} className="lift group flex h-full flex-col rounded-2xl border border-gold/30 bg-white/80 p-5">
                  <span className="font-deva text-3xl text-saffron transition-transform group-hover:scale-110">{t.hi}</span>
                  <span className="mt-2 font-display text-2xl font-semibold text-maroon">{t.h}</span>
                  <span className="mt-1 text-sm text-ink-soft">{t.p}</span>
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-12 grid items-start gap-10 lg:grid-cols-2">
            <div>
              <h3 className="font-display text-2xl font-semibold text-maroon">Shloka of the day</h3>
              <div className="mt-4"><ShlokaDeck shlokas={SHLOKAS} startIndex={SHLOKAS.indexOf(shlokaOfDay(today))} /></div>
            </div>
            <div>
              <h3 className="font-display text-2xl font-semibold text-maroon">Mantra of the day</h3>
              <p className="text-sm text-ink-faint">{gayatri.title}, {gayatri.source}</p>
              <div className="leaf mt-4 p-5"><ReciteAlong padas={gayatri.padas} iast={gayatri.iast} size="md" /></div>
              <div className="leaf mt-4 p-5"><ChantCounter id="gayatri" /></div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ + newsletter */}
      <section className="reveal container grid gap-10 py-14 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <h2 className="section-title">Questions</h2>
          <div className="mt-5"><Faq items={FAQS} /></div>
        </div>
        <div className="self-start rounded-2xl bg-midnight p-6 text-ivory">
          <h2 className="font-display text-2xl font-semibold text-gold-pale">Festival reminders</h2>
          <p className="mb-4 mt-1 text-sm text-ivory/75">Ekadashi, Purnima and major festival dates, by email.</p>
          <Newsletter />
        </div>
      </section>

      <JsonLd data={{ "@context": "https://schema.org", "@type": "WebSite", name: SITE.name, url: SITE.url }} />
      <JsonLd data={{ "@context": "https://schema.org", "@type": "WebApplication", name: `${SITE.name} Kundli & Panchang`, applicationCategory: "LifestyleApplication", operatingSystem: "Web", offers: { "@type": "Offer", price: "0", priceCurrency: "INR" } }} />
    </>
  );
}
