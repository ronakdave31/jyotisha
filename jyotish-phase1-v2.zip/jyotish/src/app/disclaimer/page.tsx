import type { Metadata } from "next";
import { PageHeader } from "@/components/ui";
import { Prose } from "@/components/Prose";
import { DISCLAIMER } from "@/lib/site";
export const metadata: Metadata = { title: "Disclaimer", alternates: { canonical: "/disclaimer" } };
export default function Page() {
  return (<><PageHeader title="Disclaimer" crumbs={[{ name: "Disclaimer", href: "/disclaimer" }]} /><Prose>
    <p>{DISCLAIMER}</p>
    <p>Astronomical values (sunrise, tithi end times, planetary positions) are calculated carefully and may still differ slightly from other almanacs because of differing conventions. Readings, yogas, doshas, compatibility scores and numerology describe traditional beliefs and should not be the sole basis for decisions about health, marriage, finance, education or legal matters.</p>
    <p>Health-related indications are never medical advice. Please consult qualified professionals.</p>
  </Prose></>);
}
