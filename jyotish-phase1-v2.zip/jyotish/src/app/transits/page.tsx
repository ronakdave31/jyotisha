import type { Metadata } from "next";
import { gochar } from "@/lib/astro/kundli";
import { getLocation } from "@/lib/request";
import { fmtTime } from "@/lib/astro/time";
import { PageHeader, Disclaimer } from "@/components/ui";

export const revalidate = 900;
export const metadata: Metadata = { title: "Planetary Transits Today — Gochar Tracker", description: "Current sidereal positions of all nine grahas, retrograde status and the date each planet next changes sign.", alternates: { canonical: "/transits" } };

export default function Page() {
  const loc = getLocation();
  const rows = gochar(0, 0);
  return (
    <>
      <PageHeader title="Planetary transits" intro="Where each graha stands in the sidereal zodiac right now (Lahiri ayanamsa) and when it moves into the next sign." crumbs={[{ name: "Transits", href: "/transits" }]} />
      <div className="container py-10">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-[15px]">
            <thead><tr className="border-b border-gold/30 text-left text-ink-faint">{["Planet", "Sign", "Degree", "Motion", "Enters next sign"].map((h) => <th key={h} className="py-2 font-normal">{h}</th>)}</tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.planet} className="border-b border-gold/10">
                <td className="py-2.5 font-medium">{r.planet}</td><td>{r.signName}</td><td className="tabular-nums">{r.degree.toFixed(2)}°</td>
                <td>{["Rahu", "Ketu"].includes(r.planet) ? "Always retrograde" : r.retrograde ? <span className="text-maroon">Retrograde</span> : "Direct"}</td>
                <td className="tabular-nums text-ink-soft">{r.nextSignChange ? `${new Date(r.nextSignChange).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: loc.tz })}, ${fmtTime(r.nextSignChange, loc.tz)}` : "—"}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        <p className="mt-3 text-sm text-ink-faint">Times shown for {loc.tz}. To see transits against your own chart, open the Transits tab of your Kundli.</p>
        <Disclaimer />
      </div>
    </>
  );
}
