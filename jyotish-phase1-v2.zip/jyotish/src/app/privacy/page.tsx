import type { Metadata } from "next";
import { PageHeader } from "@/components/ui";
import { Prose } from "@/components/Prose";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Privacy Policy", alternates: { canonical: "/privacy" } };
export default function Page() {
  return (<><PageHeader title="Privacy policy" intro="Template for legal review before launch." crumbs={[{ name: "Privacy", href: "/privacy" }]} /><Prose>
    <h2>What we collect</h2>
    <p>Birth details you enter are sent to our server only to calculate your chart and are not stored unless you sign in and choose to save them. Saved birth profiles, charts and reports are visible only to your account, enforced by database row-level security.</p>
    <p>Your chosen city and language are kept in cookies so pages are calculated for you. If you use &quot;my location&quot;, coordinates are read by your browser with your permission and are not stored on our servers unless you save them.</p>
    <h2>Third parties</h2>
    <p>Place search may query OpenStreetMap Nominatim with the place name you type. Accounts and data are hosted on Supabase. Payments, when introduced, are processed by Razorpay; we never see card details.</p>
    <h2>Your rights</h2>
    <p>You can delete any saved profile or chart from your dashboard, or ask us to delete your account under India&apos;s Digital Personal Data Protection Act, 2023, by writing to {SITE.email}.</p>
  </Prose></>);
}
