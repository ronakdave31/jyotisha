import type { Metadata } from "next";
import { festivalCalendar } from "@/lib/astro/festivals";
import { addDays, fmtDate, fmtTime, todayIn } from "@/lib/astro/time";
import { cached } from "@/lib/api";
import { getLocation } from "@/lib/request";
import { PageHeader, Disclaimer, JsonLd } from "@/components/ui";
import { PlaceChooser } from "@/components/PlaceChooser";

export const metadata: Metadata = {
  title: "Hindu Festival & Vrat Calendar — Ekadashi, Purnima, Diwali dates",
  description: "Festival and vrat dates for the next twelve months, calculated from tithi timings for your city: Diwali, Holi, Navratri, Ekadashi, Pradosh, Purnima, Amavasya and Sankranti.",
  alternates: { canonical: "/festivals" },
};

export default function Festivals({ searchParams }: { searchParams: Record<string, string | undefined> }) {
  const loc = getLocation(searchParams);
  const from = todayIn(loc.tz);
  const events = cached(`fy:${from}:${loc.lat}:${loc.lon}:${loc.tz}`, 24 * 3600e3, () => festivalCalendar(from, addDays(from, 364), loc.lat, loc.lon, loc.tz));
  const filter = searchParams.type;
  const shown = events.filter((e) => !filter || e.category === filter);
  const months = [...new Set(shown.map((e) => e.date.slice(0, 7)))];
  const qs = (t?: string) => "?" + new URLSearchParams({ ...(loc.slug ? { city: loc.slug } : { lat: String(loc.lat), lon: String(loc.lon), tz: loc.tz, name: loc.name }), ...(t ? { type: t } : {}) });

  return (
    <>
      <PageHeader title="Festival & vrat calendar" intro={`The next twelve months for ${loc.name}. Each date follows the tithi rule shown with it, so regional observance may differ by a day.`} crumbs={[{ name: "Festivals", href: "/festivals" }]}>
        <div className="mt-5 max-w-md"><PlaceChooser basePath="/festivals" /></div>
        <nav className="mt-4 flex flex-wrap gap-2" aria-label="Filter">
          {[[undefined, "Everything"], ["festival", "Festivals"], ["vrat", "Vrats"], ["sankranti", "Sankrantis"]].map(([t, l]) => (
            <a key={l} href={qs(t)} aria-current={filter === t ? "page" : undefined} className={`btn !py-1.5 text-sm ${filter === t ? "bg-maroon text-ivory" : "border border-maroon/25 text-maroon"}`}>{l}</a>
          ))}
        </nav>
      </PageHeader>
      <div className="container py-10">
        {months.map((m) => (
          <section key={m} className="mb-10">
            <h2 className="section-title">{fmtDate(`${m}-01`, "UTC", "LLLL yyyy")}</h2>
            <ul className="mt-4 divide-y divide-gold/20 rounded-2xl border border-gold/30 bg-white/60">
              {shown.filter((e) => e.date.startsWith(m)).map((e) => (
                <li key={e.id} className="grid gap-1 px-5 py-3 sm:grid-cols-[9rem_1fr_auto] sm:items-baseline sm:gap-4">
                  <span className="font-medium text-maroon">{fmtDate(e.date, "UTC", "ccc, d LLL")}</span>
                  <span>
                    <span className={e.category === "festival" ? "font-semibold" : ""}>{e.name}</span>
                    {e.tithi && <span className="ml-2 text-sm text-ink-faint">{e.masa ? `${e.masa} ` : ""}{e.tithi}</span>}
                    {e.note && <span className="block text-xs text-ink-faint">{e.note}</span>}
                  </span>
                  <span className="text-sm tabular-nums text-ink-soft">
                    {e.category === "sankranti" || e.name.includes("Sankranti") ? `at ${fmtTime(e.tithiStart, loc.tz, e.date)}` : e.tithiStart && e.tithiEnd ? `${fmtTime(e.tithiStart, loc.tz, e.date)} – ${fmtTime(e.tithiEnd, loc.tz, e.date)}` : ""}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ))}
        <Disclaimer extra="Vaishnava (ISKCON) Ekadashi and some regional festivals follow different rules; full festival pages with puja muhurat and vidhi arrive in the next phase." />
      </div>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "ItemList", name: `Hindu festivals for ${loc.name}`, itemListElement: events.filter((e) => e.category === "festival").slice(0, 20).map((e, i) => ({ "@type": "ListItem", position: i + 1, name: `${e.name} — ${e.date}` })) }} />
    </>
  );
}
