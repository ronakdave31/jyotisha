"use client";
export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="container py-16 text-center">
      <h1 className="font-display text-4xl font-bold text-maroon">Something went wrong</h1>
      <p className="mt-2 text-ink-soft">{error.message || "The calculation could not be completed."}</p>
      <button className="btn-primary mt-6" onClick={reset}>Try again</button>
    </div>
  );
}
