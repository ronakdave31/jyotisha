import type { Metadata } from "next";
import { MatchingApp } from "@/components/MatchingApp";
import { PageHeader, Faq, Disclaimer } from "@/components/ui";

export const metadata: Metadata = {
  title: "Kundli Matching — Ashta Koota Gun Milan out of 36",
  description: "Match two birth charts with the eight kootas (Varna, Vashya, Tara, Yoni, Graha Maitri, Gana, Bhakoot, Nadi), Nadi and Bhakoot dosha checks and Manglik compatibility.",
  alternates: { canonical: "/matching" },
};

export default function Page() {
  return (
    <>
      <PageHeader title="Kundli matching" intro="Gun Milan compares the Moon's sign and nakshatra in both charts across eight factors worth 36 points in total." crumbs={[{ name: "Kundli matching", href: "/matching" }]} />
      <MatchingApp />
      <div className="container no-print">
        <h2 className="section-title mt-6">How Gun Milan works</h2>
        <div className="mt-5"><Faq items={[
          { q: "What score is considered good?", a: "Tradition treats 18 of 36 as the minimum, 18–24 as average, 25–32 as very good and above 32 as excellent, while still giving weight to Nadi and Bhakoot doshas and the overall charts." },
          { q: "What are Nadi and Bhakoot dosha?", a: "Nadi dosha arises when both Moons fall in the same Nadi (8 points lost); Bhakoot dosha when the Moon signs sit 2/12, 5/9 or 6/8 apart (7 points lost). Classical texts list cancellations, which are shown with your result." },
          { q: "Why can other websites give a different score?", a: "Regional traditions score Vashya, Gana and Yoni slightly differently and some apply cancellations to the total. Our scoring tables are published with the result so the method is transparent." },
        ]} /></div>
        <Disclaimer />
      </div>
    </>
  );
}
