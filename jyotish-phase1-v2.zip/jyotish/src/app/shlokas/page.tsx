import type { Metadata } from "next";
import { SHLOKAS, SHLOKA_SOURCES, shlokaOfDay } from "@/content/shlokas";
import { todayIn } from "@/lib/astro/time";
import { PageHeader } from "@/components/ui";
import { ShlokaDeck } from "@/components/fx/ShlokaDeck";
import { LibraryFilter } from "@/components/fx/LibraryFilter";

export const metadata: Metadata = {
  title: "Sanskrit Shlokas with Meaning — Gita, Upanishads, Vedas",
  description: "Sanskrit shlokas from the Bhagavad Gita, Upanishads, Rigveda and Devi Mahatmya in Devanagari with transliteration and Hindi and English meaning.",
  alternates: { canonical: "/shlokas" },
};

export default function Page() {
  const today = shlokaOfDay(todayIn("Asia/Kolkata"));
  return (
    <>
      <PageHeader title="Shlokas" intro="Verses from the Gita, the Upanishads and the Vedas, each with its source and meaning." crumbs={[{ name: "Shlokas", href: "/shlokas" }]} />
      <div className="container space-y-14 py-12">
        <section className="grid items-start gap-8 lg:grid-cols-[1fr_1.3fr]">
          <div>
            <h2 className="section-title">Shloka of the day</h2>
            <p className="mt-2 text-ink-soft">Read the Sanskrit aloud once, then turn the card to see what it means. Draw another whenever you like.</p>
          </div>
          <ShlokaDeck shlokas={SHLOKAS} startIndex={SHLOKAS.indexOf(today)} />
        </section>
        <section>
          <h2 className="section-title">All shlokas</h2>
          <div className="mt-5">
            <LibraryFilter placeholder="Search by word, theme or verse" categories={SHLOKA_SOURCES} items={SHLOKAS.map((s) => ({ href: `/shlokas#${s.id}`, title: s.ref, category: s.source, preview: s.lines[0], sub: s.theme }))} />
          </div>
        </section>
        <section className="space-y-6">
          {SHLOKAS.map((s) => (
            <article key={s.id} id={s.id} className="reveal leaf scroll-mt-32 grid gap-4 p-6 md:grid-cols-[1.2fr_1fr]">
              <div>
                <p className="text-sm text-ink-faint">{s.ref} · {s.theme}</p>
                <p className="mt-2 font-deva text-2xl leading-relaxed text-maroon">{s.lines.map((l) => <span key={l} className="block">{l}</span>)}</p>
                <p className="mt-2 text-sm italic text-ink-soft">{s.iast.map((l) => <span key={l} className="block">{l}</span>)}</p>
              </div>
              <div className="space-y-2 border-gold/30 md:border-l md:pl-5">
                <p className="font-deva text-ink">{s.meaningHi}</p>
                <p className="text-ink-soft">{s.meaningEn}</p>
                <p className="text-sm text-saffron-dark">{s.reflection}</p>
              </div>
            </article>
          ))}
        </section>
      </div>
    </>
  );
}
