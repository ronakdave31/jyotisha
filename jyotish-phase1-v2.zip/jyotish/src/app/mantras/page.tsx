import type { Metadata } from "next";
import { MANTRAS, MANTRA_CATEGORIES } from "@/content/mantras";
import { PageHeader } from "@/components/ui";
import { LibraryFilter } from "@/components/fx/LibraryFilter";
import { Diya } from "@/components/fx/Diya";

export const metadata: Metadata = {
  title: "Hindu Mantras with Meaning — Gayatri, Mahamrityunjaya, Ganesh, Shiva",
  description: "Mantras in Devanagari with transliteration, Hindi and English meaning, chanting count and scriptural source, with a recite-along player and mala counter.",
  alternates: { canonical: "/mantras" },
};

export default function Page() {
  return (
    <>
      <PageHeader title="Mantras" intro="Each mantra comes with its scriptural source, meaning in Hindi and English, when to chant it, and a mala counter." crumbs={[{ name: "Mantras", href: "/mantras" }]}>
        <Diya size={56} className="mt-4" />
      </PageHeader>
      <div className="container py-12">
        <LibraryFilter placeholder="Search Ganesh, peace, Monday…" categories={MANTRA_CATEGORIES} items={MANTRAS.map((m) => ({ href: `/mantras/${m.slug}`, title: m.title, titleHi: m.titleHi, category: m.category, preview: m.padas[0], sub: m.source }))} />
      </div>
    </>
  );
}
