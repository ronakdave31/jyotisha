import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { MANTRAS, findMantra } from "@/content/mantras";
import { PageHeader, JsonLd } from "@/components/ui";
import { ReciteAlong } from "@/components/fx/ReciteAlong";
import { ChantCounter } from "@/components/forms/ChantCounter";
import { SITE } from "@/lib/site";

export function generateStaticParams() { return MANTRAS.map((m) => ({ slug: m.slug })); }
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const m = findMantra(params.slug);
  return m ? { title: `${m.title} — Meaning, Lyrics & Benefits`, description: `${m.title} (${m.titleHi}) in Sanskrit with transliteration, Hindi and English meaning. Source: ${m.source}. Chant ${m.count}.`, alternates: { canonical: `/mantras/${m.slug}` } } : {};
}

export default function Page({ params }: { params: { slug: string } }) {
  const m = findMantra(params.slug);
  if (!m) notFound();
  const related = (m.related ?? []).map(findMantra).filter(Boolean);
  const sameCat = MANTRAS.filter((x) => x.category === m.category && x.slug !== m.slug).slice(0, 3);
  return (
    <>
      <PageHeader title={m.title} intro={`${m.titleHi} · ${m.deity}`} crumbs={[{ name: "Mantras", href: "/mantras" }, { name: m.title, href: `/mantras/${m.slug}` }]} />
      <div className="container grid gap-10 py-12 lg:grid-cols-[1.5fr_1fr]">
        <div className="space-y-8">
          <section className="leaf p-6 md:p-8" aria-label="Mantra text">
            <ReciteAlong padas={m.padas} iast={m.iast} />
            <p className="mt-4 text-sm text-ink-faint">Source: {m.source}</p>
          </section>
          <section className="grid gap-5 md:grid-cols-2">
            <div className="reveal leaf p-5"><h2 className="font-display text-xl font-semibold text-maroon">अर्थ (Hindi)</h2><p className="mt-2 font-deva text-lg leading-relaxed">{m.meaningHi}</p></div>
            <div className="reveal leaf p-5"><h2 className="font-display text-xl font-semibold text-maroon">Meaning</h2><p className="mt-2 text-lg leading-relaxed text-ink-soft">{m.meaningEn}</p></div>
          </section>
          <section className="reveal">
            <h2 className="section-title">Significance</h2>
            <p className="mt-2 text-lg text-ink-soft">{m.significance}</p>
            <dl className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl bg-ivory-deep/70 p-4"><dt className="text-sm text-ink-faint">Chanting count</dt><dd className="font-medium">{m.count}</dd></div>
              <div className="rounded-xl bg-ivory-deep/70 p-4"><dt className="text-sm text-ink-faint">When to chant</dt><dd className="font-medium">{m.when}</dd></div>
              {m.festivals && <div className="rounded-xl bg-ivory-deep/70 p-4 sm:col-span-2"><dt className="text-sm text-ink-faint">Festivals</dt><dd className="font-medium">{m.festivals.join(", ")} · <Link className="text-maroon underline" href="/festivals">see dates</Link></dd></div>}
            </dl>
          </section>
        </div>
        <aside className="space-y-6">
          <section className="leaf p-6 lg:sticky lg:top-32">
            <h2 className="font-display text-2xl font-semibold text-maroon">Mala counter</h2>
            <p className="mb-4 text-sm text-ink-faint">Tap once for each recitation.</p>
            <ChantCounter id={m.slug} label={`Count one ${m.title}`} />
          </section>
          {[...related, ...sameCat].length > 0 && (
            <section>
              <h2 className="font-display text-xl font-semibold text-maroon">Related mantras</h2>
              <ul className="mt-3 space-y-2">
                {[...new Map([...related, ...sameCat].map((r) => [r!.slug, r!])).values()].slice(0, 4).map((r) => (
                  <li key={r.slug}><Link href={`/mantras/${r.slug}`} className="lift block rounded-xl border border-gold/25 bg-white/60 p-3"><span className="font-medium">{r.title}</span><span className="block font-deva text-sm text-ink-faint">{r.padas[0]}</span></Link></li>
                ))}
              </ul>
            </section>
          )}
          <p className="text-xs text-ink-faint">Recorded audio will be added only from licensed recordings. Recite-along and the bell are generated in your browser.</p>
        </aside>
      </div>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "CreativeWork", name: m.title, inLanguage: "sa", text: m.padas.join(" "), isBasedOn: m.source, url: `${SITE.url}/mantras/${m.slug}` }} />
    </>
  );
}
