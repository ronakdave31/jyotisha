import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getUser } from "@/lib/supabase/server";
import { PageHeader } from "@/components/ui";
import { Dashboard } from "@/components/Dashboard";

export const metadata: Metadata = { title: "My account", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function Page() {
  const { sb, user } = await getUser();
  if (!sb || !user) redirect("/login?next=/dashboard");
  const [{ data: profiles }, { data: kundlis }] = await Promise.all([
    sb.from("birth_profiles").select("*").order("is_primary", { ascending: false }).order("created_at"),
    sb.from("saved_kundlis").select("id,title,summary,created_at").order("created_at", { ascending: false }),
  ]);
  return (
    <>
      <PageHeader title="My account" intro="Your family's birth profiles and saved charts. Only you can see them." crumbs={[{ name: "My account", href: "/dashboard" }]} />
      <Dashboard profiles={profiles ?? []} kundlis={kundlis ?? []} email={user.email ?? ""} />
    </>
  );
}
