export default function Loading() {
  return (
    <div className="container py-16" role="status" aria-label="Loading">
      <div className="mx-auto h-16 w-16 animate-spin rounded-full border-2 border-gold/30 border-t-saffron" />
      <p className="mt-4 text-center text-ink-faint">Reading the sky…</p>
    </div>
  );
}
