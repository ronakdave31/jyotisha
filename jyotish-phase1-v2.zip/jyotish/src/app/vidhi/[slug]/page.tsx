import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { VIDHIS, findVidhi } from "@/content/karmkand";
import { PageHeader, Disclaimer, JsonLd } from "@/components/ui";
import { VidhiPlayer } from "@/components/fx/VidhiPlayer";
import { SITE } from "@/lib/site";

export function generateStaticParams() { return VIDHIS.map((v) => ({ slug: v.slug })); }
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const v = findVidhi(params.slug);
  return v ? { title: `${v.title} Vidhi — Samagri, Steps & Mantras`, description: v.summary, alternates: { canonical: `/vidhi/${v.slug}` } } : {};
}

export default function Page({ params }: { params: { slug: string } }) {
  const v = findVidhi(params.slug);
  if (!v) notFound();
  return (
    <>
      <PageHeader title={v.title} intro={v.summary} crumbs={[{ name: "Karmakand", href: "/karmkand" }, { name: "Puja vidhi", href: "/vidhi" }, { name: v.title, href: `/vidhi/${v.slug}` }]}>
        <dl className="mt-5 flex flex-wrap gap-x-8 gap-y-2 text-sm">
          {[["Occasion", v.occasion], ["Duration", v.duration], ["Deity", v.deity]].map(([k, val]) => <div key={k}><dt className="text-ink-faint">{k}</dt><dd className="font-medium">{val}</dd></div>)}
        </dl>
      </PageHeader>
      <div className="container py-12">
        <VidhiPlayer vidhi={v} />
        <section className="reveal mt-12 grid gap-6 md:grid-cols-2">
          <div className="leaf p-5">
            <h2 className="font-display text-xl font-semibold text-maroon">Good to know</h2>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-ink-soft">{v.notes.map((n) => <li key={n}>{n}</li>)}</ul>
          </div>
          {v.related && (
            <div className="leaf p-5">
              <h2 className="font-display text-xl font-semibold text-maroon">Related</h2>
              <ul className="mt-2 space-y-1.5">{v.related.map((r) => <li key={r.href + r.label}><Link className="text-maroon underline" href={r.href}>{r.label}</Link></li>)}</ul>
            </div>
          )}
        </section>
        <Disclaimer extra="This is a general outline. Rituals vary by Veda shakha, region and family; follow your family's tradition and purohit where they differ." />
      </div>
      <JsonLd data={{
        "@context": "https://schema.org", "@type": "HowTo", name: v.title, description: v.summary, url: `${SITE.url}/vidhi/${v.slug}`,
        supply: v.samagri.map((s) => ({ "@type": "HowToSupply", name: s })),
        step: v.steps.map((s, i) => ({ "@type": "HowToStep", position: i + 1, name: s.title, text: s.detail })),
      }} />
    </>
  );
}
