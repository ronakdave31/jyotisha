import type { Metadata } from "next";
import { VIDHIS } from "@/content/karmkand";
import { PageHeader } from "@/components/ui";
import { LibraryFilter } from "@/components/fx/LibraryFilter";

export const metadata: Metadata = {
  title: "Puja Vidhi — Step-by-step Hindu Puja at Home",
  description: "Step-by-step puja vidhis with samagri checklists and mantras: Shodashopachara, daily Ganesh puja, Diwali Lakshmi puja, Satyanarayan, Griha Pravesh, Rudrabhishek, Sandhya and Navagraha Shanti.",
  alternates: { canonical: "/vidhi" },
};

export default function Page() {
  const cats = ["Daily", "Festival", "Life event", "Planetary"];
  const catOf = (slug: string) => (["daily-ganesh-puja", "sandhya-vandan", "shodashopachara-puja"].includes(slug) ? "Daily" : ["diwali-lakshmi-puja", "satyanarayan-puja", "rudrabhishek"].includes(slug) ? "Festival" : slug === "griha-pravesh" ? "Life event" : "Planetary");
  return (
    <>
      <PageHeader title="Puja vidhi" intro="Check off your samagri, then follow along step by step in puja mode, with the mantra for each step on screen." crumbs={[{ name: "Karmakand", href: "/karmkand" }, { name: "Puja vidhi", href: "/vidhi" }]} />
      <div className="container py-12">
        <LibraryFilter placeholder="Search Diwali, Shiva, griha…" categories={cats} items={VIDHIS.map((v) => ({ href: `/vidhi/${v.slug}`, title: v.title, titleHi: v.hi, category: catOf(v.slug), preview: v.summary, sub: `${v.duration} · ${v.steps.length} steps` }))} />
      </div>
    </>
  );
}
