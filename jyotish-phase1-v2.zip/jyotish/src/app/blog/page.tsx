import type { Metadata } from "next";
import { Upcoming } from "@/components/Upcoming";
export const metadata: Metadata = { title: "Blog", robots: { index: false } };
export default function Page() {
  return <Upcoming title="Knowledge hub" href="/blog" intro="Articles on Vedic astrology, festivals and the Panchang, written and reviewed by practising astrologers."
    planned={["Rich-text editor with scheduled publishing, drafts and SEO fields", "Article, FAQ and breadcrumb structured data", "Author profiles with credentials", "Related articles and internal links to the calculators"]}
    meanwhile={[{ label: "Understanding the Panchang", href: "/panchang" }, { label: "How our calculations work", href: "/methodology" }]} />;
}
