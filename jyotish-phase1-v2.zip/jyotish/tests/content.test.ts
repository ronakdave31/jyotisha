import { describe, expect, it } from "vitest";
import { MANTRAS, findMantra } from "@/content/mantras";
import { SHLOKAS } from "@/content/shlokas";
import { VIDHIS, SAMSKARAS } from "@/content/karmkand";
import { VEDAS } from "@/content/vedas";

const deva = /[ऀ-ॿ]/;

describe("spiritual content integrity", () => {
  it("every mantra has matching Devanagari and transliteration lines, meanings and a source", () => {
    for (const m of MANTRAS) {
      expect(m.padas.length, m.slug).toBe(m.iast.length);
      expect(m.padas.every((p) => deva.test(p)), m.slug).toBe(true);
      expect(deva.test(m.meaningHi), m.slug).toBe(true);
      expect(m.source.length, m.slug).toBeGreaterThan(5);
      for (const r of m.related ?? []) expect(findMantra(r), `${m.slug} → ${r}`).toBeTruthy();
    }
  });
  it("slugs are unique", () => {
    expect(new Set(MANTRAS.map((m) => m.slug)).size).toBe(MANTRAS.length);
    expect(new Set(VIDHIS.map((v) => v.slug)).size).toBe(VIDHIS.length);
    expect(new Set(SHLOKAS.map((s) => s.id)).size).toBe(SHLOKAS.length);
  });
  it("every shloka has a reference and both meanings", () => {
    for (const s of SHLOKAS) {
      expect(s.lines.length, s.id).toBe(s.iast.length);
      expect(deva.test(s.meaningHi) && s.meaningEn.length > 10, s.id).toBe(true);
    }
  });
  it("there are exactly sixteen samskaras, numbered 1–16", () => {
    expect(SAMSKARAS.map((s) => s.n)).toEqual(Array.from({ length: 16 }, (_, i) => i + 1));
  });
  it("vidhi links to mantras point at real mantras, and samskara vidhi links exist", () => {
    for (const v of VIDHIS) for (const r of v.related ?? []) if (r.href.startsWith("/mantras/")) expect(findMantra(r.href.slice(9)), r.href).toBeTruthy();
    for (const s of SAMSKARAS) if (s.vidhi) expect(VIDHIS.some((v) => v.slug === s.vidhi)).toBe(true);
  });
  it("covers all four Vedas", () => expect(VEDAS.map((v) => v.name)).toEqual(["Rigveda", "Samaveda", "Yajurveda", "Atharvaveda"]));
});
