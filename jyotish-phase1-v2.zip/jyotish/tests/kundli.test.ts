import { describe, expect, it } from "vitest";
import { computeKundli } from "@/lib/astro/kundli";
import { VARGAS } from "@/lib/astro/divisional";
import { ashtaKoota } from "@/lib/astro/matching";
import { numerologyReport, nameNumber } from "@/lib/numerology";

describe("Kundli — M. K. Gandhi, 2 Oct 1869, 07:12 LMT Porbandar (published chart)", () => {
  // 07:12 LMT at 69.63°E = 02:33 UTC. (IANA's Asia/Kolkata applies historical local-mean-time offsets before 1906.)
  const k = computeKundli({ date: "1869-10-02", time: "02:33", tz: "UTC", lat: 21.6417, lon: 69.6293 });
  const sign = (p: string) => k.planets.find((x) => x.planet === p)!.signName;
  it("Lagna is Tula", () => expect(k.summary.lagna).toBe("Tula"));
  it("Moon in Karka, Ashlesha", () => { expect(sign("Moon")).toBe("Karka"); expect(k.summary.nakshatra).toMatch(/^Ashlesha/); });
  it("Sun in Kanya; Mars, Mercury, Venus in Tula", () => {
    expect(sign("Sun")).toBe("Kanya");
    expect([sign("Mars"), sign("Mercury"), sign("Venus")]).toEqual(["Tula", "Tula", "Tula"]);
  });
  it("Saturn in Vrishchika, Jupiter retrograde in Mesha, Rahu in Karka", () => {
    expect(sign("Saturn")).toBe("Vrishchika");
    expect(sign("Jupiter")).toBe("Mesha");
    expect(k.planets.find((p) => p.planet === "Jupiter")!.retrograde).toBe(true);
    expect(sign("Rahu")).toBe("Karka");
  });
  it("first dasha is Mercury (lord of Ashlesha) and the cycle is 120 years", () => {
    expect(k.dasha.balance.lord).toBe("Mercury");
    const total = k.dasha.mahadashas.reduce((s, m) => s + m.years, 0);
    expect(total).toBe(120);
  });
  it("Rahu and Ketu are exactly opposite", () => {
    const r = k.planets.find((p) => p.planet === "Rahu")!.lon, kt = k.planets.find((p) => p.planet === "Ketu")!.lon;
    expect(Math.abs(((kt - r + 360) % 360) - 180)).toBeLessThan(1e-9);
  });
});

describe("ascendant", () => {
  it("equals the Sun's longitude at sunrise (within refraction/semidiameter, < 1.5°)", async () => {
    const { ascendant, siderealLongitude, searchRiseSet } = await import("@/lib/astro/ephemeris");
    const r = searchRiseSet("Sun", "rise", new Date("2026-11-02T19:00:00Z"), 19.076, 72.8777)!;
    expect(Math.abs(ascendant(r, 19.076, 72.8777).ascendant - siderealLongitude("Sun", r))).toBeLessThan(1.5);
  });
});

describe("divisional charts", () => {
  it("Navamsa: Mesha 0° → Mesha, 3°20′ → Vrishabha, Vrishabha 0° → Makara, Mithuna 0° → Tula", () => {
    expect(VARGAS.D9.fn(0)).toBe(0);
    expect(VARGAS.D9.fn(3.34)).toBe(1);
    expect(VARGAS.D9.fn(30)).toBe(9);
    expect(VARGAS.D9.fn(60)).toBe(6);
  });
  it("Hora: odd sign first half → Simha, even sign first half → Karka", () => {
    expect(VARGAS.D2.fn(5)).toBe(4);
    expect(VARGAS.D2.fn(35)).toBe(3);
  });
  it("Drekkana: second decanate of Mesha is Simha", () => expect(VARGAS.D3.fn(12)).toBe(4));
  it("Dashamsa of an even sign starts from the 9th", () => expect(VARGAS.D10.fn(30.5)).toBe(9));
});

describe("Ashta Koota", () => {
  it("same nakshatra gives Nadi 0 and the maximum 36 is never exceeded", () => {
    const r = ashtaKoota(100, 100.5);
    expect(r.kootas.find((k) => k.koota === "Nadi")!.score).toBe(0);
    expect(r.total).toBeLessThanOrEqual(36);
  });
  it("max points per koota add to 36", () => {
    expect(ashtaKoota(10, 200).kootas.reduce((s, k) => s + k.max, 0)).toBe(36);
  });
  it("Moon signs 6/8 apart trigger Bhakoot dosha", () => {
    expect(ashtaKoota(5, 5 + 7 * 30).bhakootDosha.present).toBe(true);
  });
});

describe("numerology", () => {
  it("Pythagorean JOHN = 2", () => expect(nameNumber("John", "pythagorean").value).toBe(2));
  it("Chaldean JOHN = 1+7+5+5 = 18 → 9", () => expect(nameNumber("John", "chaldean").total).toBe(18));
  it("keeps master number 11 for Life Path 14 May 1990", () => expect(numerologyReport("A B", "1990-05-14").lifePath.value).toBe(11));
});
