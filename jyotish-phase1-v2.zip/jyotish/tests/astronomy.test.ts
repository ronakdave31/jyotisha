/**
 * Reference checks for the astronomical layer. Tolerances reflect published
 * almanac rounding (minutes) rather than engine precision (seconds).
 */
import { describe, expect, it } from "vitest";
import { ayanamsa, siderealLongitude, searchRiseSet } from "@/lib/astro/ephemeris";
import { elongation, computePanchang } from "@/lib/astro/panchang";
import { findCrossing } from "@/lib/astro/search";
import { fmtTime, localMidnight } from "@/lib/astro/time";

const minutesApart = (a: Date, b: Date) => Math.abs(a.getTime() - b.getTime()) / 60000;

describe("ayanamsa", () => {
  it("Lahiri at J2000 matches the Swiss Ephemeris value (23°51′25″)", () => {
    expect(ayanamsa(new Date("2000-01-01T12:00:00Z"))).toBeCloseTo(23.857, 2);
  });
  it("Lahiri on 21 March 1956 is the defining value 23°15′00.658″ (±1″)", () => {
    expect(Math.abs(ayanamsa(new Date("1956-03-21T00:00:00Z")) - 23.250183)).toBeLessThan(0.02);
  });
  it("precesses about 50.3″ per year", () => {
    const d = ayanamsa(new Date("2026-01-01T00:00:00Z")) - ayanamsa(new Date("2025-01-01T00:00:00Z"));
    expect(d * 3600).toBeGreaterThan(50);
    expect(d * 3600).toBeLessThan(50.6);
  });
  it("other ayanamsas are within a degree or two of Lahiri", () => {
    const d = new Date("2026-01-01T00:00:00Z");
    expect(Math.abs(ayanamsa(d, "krishnamurti") - ayanamsa(d))).toBeLessThan(0.2);
    expect(Math.abs(ayanamsa(d, "raman") - ayanamsa(d))).toBeLessThan(1.6);
  });
});

describe("sun and moon events", () => {
  it("New Delhi sunrise on 1 Jan 2026 is about 07:14 IST", () => {
    const rise = searchRiseSet("Sun", "rise", localMidnight("2026-01-01", "Asia/Kolkata"), 28.6139, 77.209)!;
    expect(minutesApart(rise, new Date("2026-01-01T07:14:00+05:30"))).toBeLessThan(3);
  });
  it("Mumbai sunset on 21 June 2026 is about 19:17 IST", () => {
    const set = searchRiseSet("Sun", "set", localMidnight("2026-06-21", "Asia/Kolkata"), 19.076, 72.8777)!;
    expect(minutesApart(set, new Date("2026-06-21T19:17:00+05:30"))).toBeLessThan(4);
  });
  it("elongation is ~0° at the new moon of 8 Apr 2024 18:21 UTC (total solar eclipse)", () => {
    const e = elongation(new Date("2024-04-08T18:21:00Z"));
    expect(Math.min(e, 360 - e)).toBeLessThan(0.05);
  });
  it("Makar Sankranti 2026 (Sun enters sidereal Capricorn) is on 14 Jan 2026 afternoon IST", () => {
    const t = findCrossing((d) => siderealLongitude("Sun", d), 270, new Date("2026-01-10T00:00:00Z"), 1, 24, 10)!;
    expect(fmtTime(t, "Asia/Kolkata", "2026-01-14")).toMatch(/PM$/);
    expect(t.toISOString().slice(0, 10)).toBe("2026-01-14");
  });
});

describe("panchang", () => {
  const p = computePanchang({ date: "2026-11-03", lat: 19.076, lon: 72.8777, tz: "Asia/Kolkata" });
  it("spans are contiguous and cover sunrise to next sunrise", () => {
    for (const key of ["tithi", "nakshatra", "yoga", "karana"] as const) {
      const s = p[key];
      expect(new Date(s[0].start!) <= new Date(p.sun.sunrise!)).toBe(true);
      expect(new Date(s[s.length - 1].end!) >= new Date(p.sun.nextSunrise!)).toBe(true);
      for (let i = 1; i < s.length; i++) expect(s[i].start).toBe(s[i - 1].end);
    }
  });
  it("a tithi lasts between 19 and 27 hours", () => {
    const t = p.tithi[1];
    const h = (Date.parse(t.end!) - Date.parse(t.start!)) / 3600e3;
    expect(h).toBeGreaterThan(19);
    expect(h).toBeLessThan(27);
  });
  it("uses the Tuesday tables (Rahu Kaal = 7th eighth of the day)", () => {
    expect(p.vara.english).toBe("Tuesday");
    const rahu = p.inauspicious.find((w) => w.name === "Rahu Kaal")!;
    const eighth = (Date.parse(p.sun.sunset!) - Date.parse(p.sun.sunrise!)) / 8;
    expect(Math.abs(Date.parse(rahu.start) - (Date.parse(p.sun.sunrise!) + 6 * eighth))).toBeLessThan(1000);
  });
  it("names the month and year correctly (Ashwin Krishna, VS 2083, Shaka 1948)", () => {
    expect(p.paksha).toBe("Krishna");
    expect(p.masa.amanta.en).toBe("Ashwin");
    expect(p.masa.purnimanta.en).toBe("Kartika");
    expect(p.samvat.vikramChaitradi).toBe(2083);
    expect(p.samvat.shaka).toBe(1948);
  });
  it("produces 8+8 choghadiyas and 24 horas starting with the weekday lord", () => {
    expect(p.choghadiya.day).toHaveLength(8);
    expect(p.choghadiya.night).toHaveLength(8);
    expect(p.hora).toHaveLength(24);
    expect(p.hora[0].lord).toBe("Mars");
  });
  it("detects Adhik masa in 2026 (Adhik Jyeshtha, May–June 2026)", () => {
    const q = computePanchang({ date: "2026-06-01", lat: 28.6139, lon: 77.209, tz: "Asia/Kolkata" });
    expect(q.masa.amanta.adhik).toBe(true);
  });
});
