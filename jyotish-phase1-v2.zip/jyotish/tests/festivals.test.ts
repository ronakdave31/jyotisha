import { describe, expect, it } from "vitest";
import { festivalCalendar } from "@/lib/astro/festivals";

const DELHI = [28.6139, 77.209, "Asia/Kolkata"] as const;
const find = (events: ReturnType<typeof festivalCalendar>, id: string) => events.find((e) => e.id.startsWith(id))?.date;

describe("festival rules (New Delhi, cross-checked with published 2026–27 calendars)", () => {
  const ev = festivalCalendar("2026-02-01", "2027-03-31", ...DELHI);
  it("Holika Dahan 2026 is 2 March, Purnima 17:55 IST 2 Mar to 17:07 IST 3 Mar (Drik Panchang via Aaj Tak)", () => {
    const h = ev.find((e) => e.id.startsWith("holika-dahan"))!;
    expect(h.date).toBe("2026-03-02");
    expect(Math.abs(Date.parse(h.tithiStart!) - Date.parse("2026-03-02T17:55:00+05:30"))).toBeLessThan(3 * 60e3);
    expect(Math.abs(Date.parse(h.tithiEnd!) - Date.parse("2026-03-03T17:07:00+05:30"))).toBeLessThan(3 * 60e3);
  });
  it("Diwali 2026 is 8 November", () => expect(find(ev, "diwali")).toBe("2026-11-08"));
  it("Makar Sankranti 2027 is 14 January", () => expect(ev.find((e) => e.name === "Makar Sankranti")?.date).toBe("2027-01-14"));
  it("Maha Shivaratri falls on 15 Feb 2026 and 6 Mar 2027", () => {
    expect(ev.filter((e) => e.id.startsWith("maha-shivaratri")).map((e) => e.date)).toEqual(["2026-02-15", "2027-03-06"]);
  });
  it("finds two Ekadashis in November 2026, including a kshaya (skipped-at-sunrise) one", () => {
    const n = ev.filter((e) => e.id.startsWith("ekadashi") && e.date.startsWith("2026-11")).length;
    expect(n).toBe(2);
  });
  it("every lunar month has one Shukla and one Krishna Ekadashi", () => {
    const s = ev.filter((e) => e.id.startsWith("ekadashi-shukla")).length;
    const k = ev.filter((e) => e.id.startsWith("ekadashi-krishna")).length;
    expect(Math.abs(s - k)).toBeLessThanOrEqual(1);
    expect(s).toBeGreaterThanOrEqual(13);
  });
  it("skips festivals in an Adhik month", () => {
    // 2026 has Adhik Jyeshtha; no festival rule is tied to Jyeshtha, and each rule fires at most once a year
    const raksha = ev.filter((e) => e.id.startsWith("raksha-bandhan") && e.date.startsWith("2026"));
    expect(raksha).toHaveLength(1);
  });
});
