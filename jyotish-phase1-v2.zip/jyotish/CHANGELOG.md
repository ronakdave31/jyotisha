# Changelog

## 2026-11-03 — Spiritual library and motion
New
- `src/content/` mantras.ts, shlokas.ts, vedas.ts, karmkand.ts (scripture texts with sources)
- Pages: /vedas, /shlokas, /mantras, /mantras/[slug], /karmkand, /vidhi, /vidhi/[slug]
- `src/components/fx/` StarField, Ticker, Diya, Mandala, ShlokaDeck, ReciteAlong, LibraryFilter, VidhiPlayer
- `src/lib/client/sound.ts` synthesised bell (no audio files)
- tests/content.test.ts

Changed (shared files: full re-upload needed)
- globals.css (motion), Header (Mantras dropdown), Footer (Spiritual column), ui.tsx (page header mandala)
- Homepage: starfield, ticker, Sanatan library section, shloka and mantra of the day
- ChantCounter (108-bead mala, bell, vibration), SkyDial (hover), SearchBox, sitemap
