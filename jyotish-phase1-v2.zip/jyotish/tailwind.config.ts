import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    container: { center: true, padding: "1rem", screens: { "2xl": "1240px" } },
    extend: {
      colors: {
        ivory: { DEFAULT: "#FBF6EC", deep: "#F3EAD7" },
        saffron: { DEFAULT: "#E07A1F", light: "#F4A35A", dark: "#B85E0E" },
        maroon: { DEFAULT: "#6B1E2A", dark: "#4A121C", light: "#8C3442" },
        gold: { DEFAULT: "#B8892E", light: "#D9B464", pale: "#EFDDB0" },
        midnight: { DEFAULT: "#141B33", light: "#1F2A4D", soft: "#2C3966" },
        ink: { DEFAULT: "#2A211C", soft: "#5B4F46", faint: "#8A7D72" },
      },
      fontFamily: {
        display: ["'Cormorant Garamond'", "'Tiro Devanagari Sanskrit'", "Georgia", "serif"],
        deva: ["'Tiro Devanagari Sanskrit'", "serif"],
        sans: ["Mukta", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(74,18,28,0.05), 0 8px 24px -12px rgba(74,18,28,0.18)",
      },
      keyframes: {
        "fade-up": { from: { opacity: "0", transform: "translateY(8px)" }, to: { opacity: "1", transform: "none" } },
        "slow-spin": { to: { transform: "rotate(360deg)" } },
        shimmer: { "100%": { transform: "translateX(100%)" } },
      },
      animation: {
        "fade-up": "fade-up .6s ease-out both",
        "slow-spin": "slow-spin 180s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;
