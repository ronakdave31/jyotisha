-- =============================================================================
-- Jyotish platform — core schema (Phase 1, forward-compatible with Phase 2/3)
-- PostgreSQL 15 / Supabase. Run with `supabase db push` or the SQL editor.
-- =============================================================================

create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- ---------------------------------------------------------------------------
-- Roles & users
-- ---------------------------------------------------------------------------
create type public.app_role as enum ('user', 'content_manager', 'editor', 'admin');

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  avatar_url text,
  role public.app_role not null default 'user',
  locale text not null default 'en' check (locale in ('en', 'hi')),
  default_location_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.profiles is 'One row per auth user. Role drives admin/editor permissions.';

create table public.user_preferences (
  user_id uuid primary key references auth.users (id) on delete cascade,
  ayanamsa text not null default 'lahiri' check (ayanamsa in ('lahiri', 'raman', 'krishnamurti')),
  node_type text not null default 'mean' check (node_type in ('mean', 'true')),
  month_system text not null default 'amanta' check (month_system in ('amanta', 'purnimanta')),
  chart_style text not null default 'north' check (chart_style in ('north', 'south')),
  horoscope_signs smallint[] not null default '{}',
  notify_email boolean not null default false,
  notify_festivals boolean not null default true,
  notify_daily_panchang boolean not null default false,
  updated_at timestamptz not null default now()
);

-- Helper: is the current user staff with at least the given role?
create or replace function public.has_role(min_role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid()
      and array_position(enum_range(null::public.app_role), p.role)
          >= array_position(enum_range(null::public.app_role), min_role)
  );
$$;

-- Auto-create profile + preferences on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)), new.raw_user_meta_data->>'avatar_url');
  insert into public.user_preferences (user_id) values (new.id);
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;

-- ---------------------------------------------------------------------------
-- Locations & time zones
-- ---------------------------------------------------------------------------
create table public.timezones (
  tz text primary key,                -- IANA identifier, e.g. Asia/Kolkata
  label text,
  tzdb_version text                   -- e.g. 2025b, recorded when synced
);

create table public.locations (
  id uuid primary key default gen_random_uuid(),
  slug text unique,                   -- set for curated SEO city pages
  name text not null,
  state text,
  country text not null,
  lat numeric(9, 6) not null check (lat between -90 and 90),
  lon numeric(9, 6) not null check (lon between -180 and 180),
  elevation_m integer default 0,
  tz text not null references public.timezones (tz),
  source text not null default 'curated' check (source in ('curated', 'nominatim', 'user')),
  featured boolean not null default false,
  created_at timestamptz not null default now()
);
create index locations_name_trgm on public.locations using gin (to_tsvector('simple', name || ' ' || coalesce(state, '')));

alter table public.profiles add constraint profiles_default_location_fk
  foreign key (default_location_id) references public.locations (id) on delete set null;

-- ---------------------------------------------------------------------------
-- Birth profiles & saved charts (PII — strictly owner-only)
-- ---------------------------------------------------------------------------
create table public.birth_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  label text not null,                -- "Me", "Mother", ...
  relation text,
  full_name text not null,
  gender text check (gender in ('male', 'female', 'other')),
  birth_date date not null,
  birth_time time not null,
  time_accuracy text not null default 'exact' check (time_accuracy in ('exact', 'approximate', 'unknown')),
  place_name text,
  lat numeric(9, 6) not null,
  lon numeric(9, 6) not null,
  tz text not null,
  is_primary boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index birth_profiles_user on public.birth_profiles (user_id);
create unique index birth_profiles_one_primary on public.birth_profiles (user_id) where is_primary;
create trigger birth_profiles_touch before update on public.birth_profiles for each row execute function public.touch_updated_at();

-- Calculation metadata shared by every stored computation
create table public.calculation_runs (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('kundli', 'panchang', 'matching', 'muhurat', 'numerology', 'transit')),
  input_utc timestamptz,
  lat numeric(9, 6),
  lon numeric(9, 6),
  tz text,
  ayanamsa text not null default 'lahiri',
  ayanamsa_value_deg numeric(10, 6),
  node_type text not null default 'mean',
  house_system text,
  month_system text,
  regional_rules text,
  engine text not null,               -- e.g. astronomy-engine@2.1.19
  ruleset_version text,
  created_at timestamptz not null default now()
);

create table public.saved_kundlis (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  birth_profile_id uuid references public.birth_profiles (id) on delete set null,
  calculation_run_id uuid not null references public.calculation_runs (id),
  title text not null,
  summary jsonb not null,             -- lagna, rashi, nakshatra
  chart jsonb not null,               -- full computed result (positions, vargas, dasha, yogas)
  is_premium boolean not null default false,
  share_token text unique,            -- set only when the owner shares it
  created_at timestamptz not null default now()
);
create index saved_kundlis_user on public.saved_kundlis (user_id, created_at desc);

create table public.planetary_positions (
  id bigint generated always as identity primary key,
  calculation_run_id uuid not null references public.calculation_runs (id) on delete cascade,
  body text not null check (body in ('Ascendant', 'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu')),
  longitude_deg numeric(10, 6) not null,
  sign smallint not null check (sign between 0 and 11),
  nakshatra smallint not null check (nakshatra between 0 and 26),
  pada smallint not null check (pada between 1 and 4),
  house smallint check (house between 1 and 12),
  speed_deg_day numeric(10, 6),
  retrograde boolean,
  combust boolean,
  dignity text
);
create index planetary_positions_run on public.planetary_positions (calculation_run_id);

create table public.compatibility_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  boy_profile_id uuid references public.birth_profiles (id) on delete set null,
  girl_profile_id uuid references public.birth_profiles (id) on delete set null,
  calculation_run_id uuid not null references public.calculation_runs (id),
  total_score numeric(4, 1) not null,
  result jsonb not null,
  created_at timestamptz not null default now()
);

create table public.numerology_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  full_name text not null,
  birth_date date,
  system text not null check (system in ('pythagorean', 'chaldean')),
  report_type text not null default 'personal' check (report_type in ('personal', 'name', 'business', 'baby', 'compatibility')),
  result jsonb not null,
  created_at timestamptz not null default now()
);

create table public.report_downloads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  report_kind text not null,
  report_id uuid not null,
  file_path text,                     -- Supabase Storage path when server-rendered
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Panchang cache & calendar records (public, written by service role/jobs)
-- ---------------------------------------------------------------------------
create table public.panchang_records (
  id uuid primary key default gen_random_uuid(),
  location_id uuid references public.locations (id) on delete cascade,
  lat numeric(9, 6) not null,
  lon numeric(9, 6) not null,
  tz text not null,
  civil_date date not null,
  ayanamsa text not null default 'lahiri',
  sunrise timestamptz,
  sunset timestamptz,
  data jsonb not null,
  calculation_run_id uuid references public.calculation_runs (id),
  created_at timestamptz not null default now(),
  unique (lat, lon, civil_date, ayanamsa)
);

create table public.tithi_records (
  id bigint generated always as identity primary key,
  tithi_index smallint not null check (tithi_index between 0 and 29),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  lunation_masa smallint check (lunation_masa between 0 and 11),
  adhik boolean not null default false,
  unique (starts_at)
);
create index tithi_records_range on public.tithi_records (starts_at, ends_at);

create table public.nakshatra_records (
  id bigint generated always as identity primary key,
  nakshatra_index smallint not null check (nakshatra_index between 0 and 26),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  unique (starts_at)
);
create index nakshatra_records_range on public.nakshatra_records (starts_at, ends_at);

-- ---------------------------------------------------------------------------
-- Rules engines (editable by admins)
-- ---------------------------------------------------------------------------
create table public.festival_rules (
  id text primary key,
  name text not null,
  name_hi text,
  masa smallint check (masa between 0 and 11),        -- Amanta, Chaitra = 0
  tithi smallint check (tithi between 0 and 29),
  karmakala text check (karmakala in ('sunrise', 'madhyahna', 'aparahna', 'pradosh', 'nishita', 'moonrise-evening')),
  solar_sign smallint check (solar_sign between 0 and 11),  -- for Sankranti-type festivals
  category text not null check (category in ('festival', 'vrat', 'sankranti', 'jayanti', 'regional')),
  regions text[] not null default '{all}',
  tradition text not null default 'smarta',
  note text,
  active boolean not null default true,
  version integer not null default 1,
  updated_at timestamptz not null default now()
);

create table public.festivals (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  rule_id text references public.festival_rules (id),
  title text not null,
  title_hi text,
  significance text,
  mythology text,
  puja_vidhi text,
  samagri text[],
  vrat_rules text,
  regional_variations text,
  faqs jsonb not null default '[]',
  seo_title text,
  seo_description text,
  status text not null default 'draft' check (status in ('draft', 'published')),
  is_sample boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.festival_calendar (
  id bigint generated always as identity primary key,
  festival_rule_id text not null references public.festival_rules (id) on delete cascade,
  location_id uuid references public.locations (id) on delete cascade,
  civil_date date not null,
  tithi_starts_at timestamptz,
  tithi_ends_at timestamptz,
  puja_muhurat_start timestamptz,
  puja_muhurat_end timestamptz,
  computed_at timestamptz not null default now(),
  calculation_run_id uuid references public.calculation_runs (id),
  unique (festival_rule_id, location_id, civil_date)
);

create table public.muhurat_rules (
  id uuid primary key default gen_random_uuid(),
  activity text not null,             -- vivah, griha_pravesh, vehicle, ...
  tradition text not null default 'north',
  allowed_tithis smallint[] not null default '{}',
  allowed_nakshatras smallint[] not null default '{}',
  allowed_varas smallint[] not null default '{}',
  allowed_lagnas smallint[] not null default '{}',
  excluded_yogas smallint[] not null default '{}',
  exclude_vishti boolean not null default true,
  exclude_rahu_kaal boolean not null default true,
  exclude_adhik_masa boolean not null default true,
  exclude_combust_venus_jupiter boolean not null default false,
  allowed_masas smallint[] not null default '{}',
  source_reference text not null,     -- text the rule is drawn from (e.g. Muhurta Chintamani)
  version integer not null default 1,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.saved_muhurats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  muhurat_rule_id uuid references public.muhurat_rules (id),
  activity text not null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  location_id uuid references public.locations (id),
  reasons jsonb not null default '[]',
  created_at timestamptz not null default now()
);

create table public.matching_rules (
  id text primary key,                -- e.g. north-ashtakoota-v1
  description text,
  tables jsonb not null,              -- vashya/yoni/gana matrices etc.
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.interpretations (
  id uuid primary key default gen_random_uuid(),
  topic text not null,                -- 'house_lord_in_house', 'yoga', 'dosha', 'moon_transit', ...
  key text not null,                  -- e.g. 'L10_in_H7'
  locale text not null default 'en',
  body text not null,
  source_reference text,
  reviewed_by uuid references auth.users (id),
  status text not null default 'draft' check (status in ('draft', 'published')),
  updated_at timestamptz not null default now(),
  unique (topic, key, locale)
);

create table public.calculation_settings (
  key text primary key,               -- 'default_ayanamsa', 'dasha_year_days', 'regional_vikram_new_year', ...
  value jsonb not null,
  description text,
  updated_by uuid references auth.users (id),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Content: mantras, blogs, authors, taxonomy
-- ---------------------------------------------------------------------------
create table public.deities (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  name_hi text
);

create table public.mantras (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  category text not null,
  deity_id uuid references public.deities (id),
  devanagari text not null,
  transliteration text not null,
  meaning_hi text,
  meaning_en text,
  significance text,
  chant_count text,
  source_reference text not null,     -- scripture & verse; required for authenticity
  related_festival_ids uuid[] not null default '{}',
  status text not null default 'draft' check (status in ('draft', 'published')),
  is_sample boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.mantra_audio (
  id uuid primary key default gen_random_uuid(),
  mantra_id uuid not null references public.mantras (id) on delete cascade,
  storage_path text not null,
  duration_seconds integer,
  artist text,
  license text not null,              -- licence name/terms; required
  license_url text,
  downloadable boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.favorite_mantras (
  user_id uuid not null references auth.users (id) on delete cascade,
  mantra_id uuid not null references public.mantras (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, mantra_id)
);

create table public.chant_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  mantra_id uuid references public.mantras (id),
  count integer not null check (count >= 0),
  target integer,
  created_at timestamptz not null default now()
);

create table public.authors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users (id),
  slug text unique not null,
  name text not null,
  bio text,
  credentials text,
  avatar_url text
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text
);

create table public.tags (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null
);

create table public.blogs (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  excerpt text,
  body jsonb not null,                -- rich-text document (TipTap/ProseMirror JSON)
  body_html text,
  featured_image text,
  author_id uuid references public.authors (id),
  category_id uuid references public.categories (id),
  seo_title text,
  seo_description text,
  canonical_url text,
  faqs jsonb not null default '[]',
  reading_minutes smallint,
  status text not null default 'draft' check (status in ('draft', 'scheduled', 'published')),
  publish_at timestamptz,
  is_sample boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index blogs_published on public.blogs (status, publish_at desc);

create table public.blog_tags (
  blog_id uuid references public.blogs (id) on delete cascade,
  tag_id uuid references public.tags (id) on delete cascade,
  primary key (blog_id, tag_id)
);

create table public.homepage_banners (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,
  cta_label text,
  cta_href text,
  image_url text,
  starts_at timestamptz,
  ends_at timestamptz,
  sort_order integer not null default 0,
  active boolean not null default true
);

create table public.seo_overrides (
  path text primary key,
  title text,
  description text,
  og_image text,
  noindex boolean not null default false,
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Engagement, commerce & ops
-- ---------------------------------------------------------------------------
create table public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email citext unique not null,
  locale text default 'en',
  source text,
  confirmed_at timestamptz,
  unsubscribed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users (id) on delete set null,
  page text,
  message text not null check (char_length(message) <= 4000),
  rating smallint check (rating between 1 and 5),
  status text not null default 'new' check (status in ('new', 'reviewed', 'closed')),
  created_at timestamptz not null default now()
);

create table public.recently_viewed (
  user_id uuid not null references auth.users (id) on delete cascade,
  path text not null,
  title text,
  viewed_at timestamptz not null default now(),
  primary key (user_id, path)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique not null,           -- 'kundli_premium', 'matching_premium', 'sub_monthly', ...
  name text not null,
  kind text not null check (kind in ('report', 'subscription', 'consultation', 'digital')),
  price_paise integer not null check (price_paise >= 0),
  currency text not null default 'INR',
  active boolean not null default true
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  product_id uuid not null references public.products (id),
  amount_paise integer not null,
  status text not null default 'created' check (status in ('created', 'paid', 'failed', 'refunded')),
  razorpay_order_id text unique,
  razorpay_payment_id text,
  razorpay_signature_verified boolean not null default false,
  subject_id uuid,                    -- e.g. saved_kundlis.id unlocked by this order
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  plan text not null,
  status text not null check (status in ('active', 'past_due', 'cancelled')),
  current_period_end timestamptz,
  razorpay_subscription_id text unique,
  created_at timestamptz not null default now()
);

create table public.api_integrations (
  id text primary key,                -- 'nominatim', 'resend', 'razorpay', ...
  enabled boolean not null default false,
  config jsonb not null default '{}', -- never store secrets here; secrets live in env vars
  notes text,
  updated_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor uuid references auth.users (id),
  action text not null,
  entity text not null,
  entity_id text,
  diff jsonb,
  created_at timestamptz not null default now()
);
