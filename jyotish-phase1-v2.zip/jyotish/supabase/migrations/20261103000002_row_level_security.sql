-- =============================================================================
-- Row-level security. Default deny on every table; explicit policies below.
-- Service-role key (server-side jobs only) bypasses RLS.
-- =============================================================================

do $$
declare t text;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- Owner-only personal data --------------------------------------------------
create policy "own profile read" on public.profiles for select using (id = auth.uid() or public.has_role('admin'));
create policy "own profile update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "admin manage profiles" on public.profiles for update using (public.has_role('admin'));

-- Only admins may change a role (blocks self-promotion through the update policy above)
create or replace function public.guard_role_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and not public.has_role('admin') and auth.uid() is not null then
    raise exception 'Only admins can change roles';
  end if;
  return new;
end; $$;
create trigger profiles_guard_role before update on public.profiles for each row execute function public.guard_role_change();

do $$
declare t text;
begin
  foreach t in array array['user_preferences', 'birth_profiles', 'saved_kundlis', 'compatibility_reports',
                           'numerology_reports', 'report_downloads', 'saved_muhurats', 'favorite_mantras',
                           'chant_sessions', 'recently_viewed'] loop
    execute format($f$
      create policy "owner select" on public.%1$I for select using (user_id = auth.uid());
      create policy "owner insert" on public.%1$I for insert with check (user_id = auth.uid());
      create policy "owner update" on public.%1$I for update using (user_id = auth.uid()) with check (user_id = auth.uid());
      create policy "owner delete" on public.%1$I for delete using (user_id = auth.uid());
    $f$, t);
  end loop;
end $$;

-- Calculation runs are readable when linked to something the user owns
create policy "runs via ownership" on public.calculation_runs for select using (
  exists (select 1 from public.saved_kundlis k where k.calculation_run_id = calculation_runs.id and k.user_id = auth.uid())
  or exists (select 1 from public.compatibility_reports c where c.calculation_run_id = calculation_runs.id and c.user_id = auth.uid())
  or kind = 'panchang'
);
create policy "runs insert authenticated" on public.calculation_runs for insert to authenticated with check (true);

create policy "positions via ownership" on public.planetary_positions for select using (
  exists (select 1 from public.saved_kundlis k where k.calculation_run_id = planetary_positions.calculation_run_id and k.user_id = auth.uid())
);
create policy "positions insert via ownership" on public.planetary_positions for insert to authenticated with check (true);

-- Orders/subscriptions: owners read; only the server (service role) writes
create policy "own orders" on public.orders for select using (user_id = auth.uid() or public.has_role('admin'));
create policy "own subscriptions" on public.subscriptions for select using (user_id = auth.uid() or public.has_role('admin'));

-- Public reference data -----------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['locations', 'timezones', 'panchang_records', 'tithi_records', 'nakshatra_records',
                           'festival_rules', 'festival_calendar', 'muhurat_rules', 'matching_rules', 'deities',
                           'authors', 'categories', 'tags', 'blog_tags', 'homepage_banners', 'seo_overrides',
                           'products', 'calculation_settings', 'mantra_audio'] loop
    execute format('create policy "public read" on public.%I for select using (true)', t);
  end loop;
end $$;

-- Published content public; drafts for staff
create policy "published mantras" on public.mantras for select using (status = 'published' or public.has_role('content_manager'));
create policy "published festivals" on public.festivals for select using (status = 'published' or public.has_role('content_manager'));
create policy "published blogs" on public.blogs for select using (
  (status = 'published' and (publish_at is null or publish_at <= now())) or public.has_role('content_manager')
);
create policy "published interpretations" on public.interpretations for select using (status = 'published' or public.has_role('editor'));

-- Staff write access ----------------------------------------------------------
-- content_manager: content tables; editor: + rules & interpretations; admin: everything
do $$
declare t text;
begin
  foreach t in array array['mantras', 'mantra_audio', 'festivals', 'blogs', 'blog_tags', 'authors', 'categories',
                           'tags', 'deities', 'homepage_banners', 'seo_overrides'] loop
    execute format('create policy "content staff write" on public.%I for all using (public.has_role(''content_manager'')) with check (public.has_role(''content_manager''))', t);
  end loop;
  foreach t in array array['festival_rules', 'muhurat_rules', 'matching_rules', 'interpretations', 'locations', 'timezones'] loop
    execute format('create policy "editor write" on public.%I for all using (public.has_role(''editor'')) with check (public.has_role(''editor''))', t);
  end loop;
  foreach t in array array['calculation_settings', 'api_integrations', 'products', 'audit_log', 'feedback', 'newsletter_subscribers'] loop
    execute format('create policy "admin all" on public.%I for all using (public.has_role(''admin'')) with check (public.has_role(''admin''))', t);
  end loop;
end $$;

-- Anyone may submit feedback or subscribe (writes only; reads admin-only)
create policy "submit feedback" on public.feedback for insert with check (user_id is null or user_id = auth.uid());
create policy "subscribe" on public.newsletter_subscribers for insert with check (true);

-- Shared kundlis are exposed through a security-definer function, never a broad select policy
create or replace function public.shared_kundli(token text)
returns table (title text, summary jsonb, chart jsonb, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select title, summary, chart, created_at from public.saved_kundlis where share_token = token and share_token is not null;
$$;
grant execute on function public.shared_kundli(text) to anon, authenticated;
