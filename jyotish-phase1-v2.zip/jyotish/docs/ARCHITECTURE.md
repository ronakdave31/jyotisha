# Architecture

```
Browser ──► Next.js App Router (SSR pages, client islands)
              │
              ├── src/app/api/*          Route handlers: validation (zod) → rate limit → cache → engine
              │
              ├── src/lib/astro/         CALCULATION LAYER (pure TypeScript, no I/O)
              │     ephemeris.ts         positions, ayanamsa, nodes, ascendant, rise/set   ← astronomy only
              │     search.ts            root finding for angle crossings (1-second precision)
              │     panchang.ts          five limbs, muhurtas, choghadiya, hora, month/year  ← rules
              │     kundli.ts            chart, dignity, aspects, yogas, doshas, sade sati, gochar
              │     divisional.ts        16 Parashari vargas
              │     dasha.ts             Vimshottari
              │     matching.ts          Ashta Koota tables (also stored in matching_rules)
              │     festivals.ts         festival rules engine (also stored in festival_rules)
              │     horoscope.ts         Gochara-phala daily readings
              │     interpretations.ts   wording for life-area reports (also `interpretations` table)
              │     constants.ts         reference data (names, lords, tables)
              │
              └── Supabase (Postgres + Auth + RLS)
                    user data, saved charts with calculation_runs metadata, editable rule tables, content
```

**Astronomy and tradition are separate.** `ephemeris.ts` knows nothing about tithis or yogas; every traditional rule lives in the files above it as data or small, documented functions. This is what lets an astrologer change a rule (via the rule tables) without touching astronomy.

## Accuracy

- Astronomy Engine 2.1.19: Sun/Moon/planets within ~1′ of JPL over 1800–2200. That is ~2 s for a tithi boundary and ~5 s for nakshatra.
- Ayanamsa: Lahiri defined at 23°15′00.658″ on 1956-03-21 with IAU 2006 precession (matches Swiss Ephemeris to < 1″). Raman and KP available.
- Sidereal positions remove nutation (mean equinox), as Swiss Ephemeris does.
- Sunrise: upper limb, standard refraction, sea level (elevation supported in the API).
- Time zones: IANA via Luxon, including DST and pre-1906 Indian local-time offsets. Births before 1906 in India are interpreted with the historical zone; users with an LMT birth time should enter it with `tz=UTC` after conversion, or use manual coordinates.
- Validated against: Drik Panchang tithi times for Holika Dahan 2026 (±3 min), published dates for Diwali 2026, Maha Shivaratri 2026/2027, Makar Sankranti 2027, Adhik Jyeshtha 2026, and the documented Gandhi chart. See `tests/`.

## Known limitations (Phase 1)

- Bhadra and eclipse adjustments for Holika Dahan / Raksha Bandhan muhurat are not yet applied (dates already agree; puja windows come in Phase 2).
- Vaishnava Ekadashi (arunodaya rule) not yet separate from Smarta.
- Shadbala, Ashtakavarga and Bhava Chalit are scheduled for Phase 2.
- Gun Milan Vashya/Gana tables follow one common North Indian convention; alternatives can be added as new `matching_rules` rows.
- Cache and rate limiter are in-memory per instance; use Redis (Upstash) when running more than one instance.
- Fonts load from Google Fonts at runtime.

## Roadmap

**Phase 2** — Muhurat rules engine (16 activities, Muhurta Chintamani criteria, .ics/PDF export); mantra library with licensed audio and saved chant sessions; festival pages (puja muhurat, vidhi, samagri, FAQs); blog CMS with rich-text editor and scheduling; admin dashboard over the rule/content tables; server-rendered PDF reports; Shadbala, Ashtakavarga, Bhava Chalit; Hindi UI throughout.

**Phase 3** — Razorpay payments (orders/subscriptions tables already exist), premium reports, consultations booking, email notifications (Resend) and daily Panchang digests, Redis cache, background jobs to pre-compute `panchang_records` / `festival_calendar` for featured cities, analytics.
