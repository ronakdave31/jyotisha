# Deployment

## 1. Supabase
1. Create a project (region: Mumbai `ap-south-1`).
2. SQL editor → run `supabase/migrations/20261103000001_core_schema.sql`, then `..._row_level_security.sql`, then `supabase/seed.sql`. (Or `supabase link` + `supabase db push`.)
3. Authentication → URL configuration: Site URL `https://your-domain`, redirect URL `https://your-domain/auth/callback`.
4. Google login: Authentication → Providers → Google; create an OAuth client in Google Cloud with redirect `https://<project>.supabase.co/auth/v1/callback`.
5. Make yourself admin: `update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'hello@krayonmedias.com');`
6. Enable Point-in-Time Recovery or daily backups (Settings → Database).

## 2. Vercel
1. Import the repository; framework Next.js; Node 20+.
2. Add the variables from `.env.example` (Production + Preview).
3. Deploy, then add the custom domain and set `NEXT_PUBLIC_SITE_URL` to it.
4. Submit `https://your-domain/sitemap.xml` in Google Search Console.

## 3. Scaling notes
- Panchang for a city/day costs ~50–100 ms CPU and is cached for 6 hours per instance; city pages revalidate hourly.
- With more than one instance, replace the Map-based cache and rate limiter in `src/lib/api.ts` with Upstash Redis (`UPSTASH_*` variables reserved).
- Nominatim allows 1 request/second; for heavy traffic switch `GEOCODER` to a paid provider (Google Places, Mapbox) in `src/app/api/geocode/route.ts`.

## 4. Before launch
- Have the privacy policy and terms reviewed (templates in `src/app/privacy`, `src/app/terms`).
- Have an astrologer review `src/lib/astro/interpretations.ts`, `horoscope.ts` wording and the matching tables.
- Replace the sample mantra rows (`is_sample = true`) after verification; add only licensed audio.
- Add genuine testimonials only once you have them.
