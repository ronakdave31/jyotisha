# API

All endpoints return JSON. Times are ISO-8601 UTC strings; format them in the response's `meta.tz`. Errors are `{ "error": "message" }` with status 400 (validation), 401 (sign-in), 429 (rate limit) or 500.

Locations: pass `city=<slug>` (see `src/lib/cities.ts`) **or** `lat`, `lon` and an IANA `tz`. Latitudes beyond ±66.5° are rejected (no daily sunrise).

## GET /api/panchang
`?city=mumbai&date=2026-11-03` or `?lat=19.076&lon=72.8777&tz=Asia/Kolkata`
Optional: `days=1..31` (returns `{ days: [...] }`), `ayanamsa=lahiri|raman|krishnamurti`.
Returns `meta`, `sun`, `moon`, `vara`, `tithi[]`, `nakshatra[]`, `yoga[]`, `karana[]` (each `{index,name,nameHi,start,end,extra}`), `paksha`, `masa.{amanta,purnimanta}`, `ritu`, `samvat`, `auspicious[]`, `inauspicious[]`, `choghadiya.{day,night}`, `hora[]`. Rate limit 120/min.

## POST /api/kundli
```json
{ "name": "Asha", "date": "1990-05-14", "time": "10:30", "tz": "Asia/Kolkata",
  "lat": 19.076, "lon": 72.8777, "place": "Mumbai", "ayanamsa": "lahiri", "node": "mean" }
```
Returns `meta`, `ascendant`, `planets[]`, `houses[]`, `divisional.{D1..D60}`, `aspects`, `conjunctions`, `dasha`, `yogas[]`, `doshas.{manglik,kaalSarp}`, `sadeSati`, `summary`, `interpretation`. Rate limit 30/min.

## POST /api/matching
`{ "boy": <birth>, "girl": <birth> }` → `kootas[]`, `total`, `verdict`, `nadiDosha`, `bhakootDosha`, `manglik`, `charts`, `rulesetVersion`.

## POST /api/numerology
`{ "name": "...", "dob": "YYYY-MM-DD", "system": "pythagorean|chaldean", "type": "personal|name|business|baby" }`

## GET /api/festivals
`?city=new-delhi&from=2026-11-01&days=90` (max 400) → `events[]` with `date`, `name`, `category`, `tithi`, `masa`, `tithiStart`, `tithiEnd`, `note`.

## GET /api/horoscope
`?sign=0..11` (Mesha = 0) or all twelve when omitted.

## GET /api/transits
`?moon=0..11&lagna=0..11` → current positions with houses from Moon/Lagna and next sign change.

## GET /api/geocode
`?q=porbandar` → `results[]` `{name, region, lat, lon, tz, source}`. Curated cities first, then OpenStreetMap when `GEOCODER=nominatim`.

## Authenticated (Supabase session cookie)
- `GET/POST /api/profiles`, `DELETE /api/profiles/:id` — birth profiles
- `GET/POST /api/kundlis`, `GET/DELETE /api/kundlis/:id` — saved charts. POST takes `{ birth, birth_profile_id? }`; the server recomputes the chart and stores it with a `calculation_runs` row and `planetary_positions`.
- `POST /api/newsletter` — `{ email }`
- `GET /auth/callback` — OAuth / magic-link code exchange
